# 📚 e-Katalog — Platform Katalog & Penjualan Buku Online

Aplikasi web full-stack modern, premium, dan responsif untuk katalog dan penjualan buku online berbahasa Indonesia. Dilengkapi dengan storefront publik yang elegan untuk pengunjung dan dashboard admin komprehensif untuk pemilik toko.

---

## 🌟 Fitur Utama

### 🛒 Halaman Publik (Toko Online)
* **Katalog Buku Responsif**: Tampilan grid buku dengan sampul jernih, rating, jumlah ulasan, harga jual, dan status stok.
* **Pencarian Cepat & Filter Kategori**: Cari buku berdasarkan judul, penulis, penerbit, atau ISBN. Filter instan berdasarkan kategori.
* **Detail Buku Interaktif**: Sinopsis lengkap, spesifikasi buku, nomor katalog resmi, dan kelompok usia sasaran.
* **Keranjang Belanja & Checkout Atomik**: Keranjang belanja interaktif dengan validasi ketersediaan stok fisik secara langsung (atomic deduction).
* **Integrasi WhatsApp**: Tombol konsultasi cepat mengarah ke WhatsApp penjual dengan template pesan otomatis.
* **Pelacakan Pesanan Real-Time**: Pelanggan dapat melacak status pesanan (`Menunggu Konfirmasi`, `Diproses`, `Dikirim`, dll.) menggunakan kode pesanan (contoh: `INV-20261020-001`) atau nomor HP tanpa perlu mendaftar akun.

### 🛡️ Dashboard Admin (Navy & Blue Accent)
* **Statistik & Analitik Penjualan**: Ringkasan total judul buku, unit stok fisik, pesanan masuk, total omzet, estimasi laba bersih, dan grafik tren penjualan.
* **Katalog & CRUD Buku Lengkap**: Tambah, edit, arsip (nonaktifkan), dan hapus buku. Dukungan nomor katalog stabil dan upload gambar sampul (file atau URL).
* **Manajemen Kategori**: Buat dan kelola kategori buku dengan penghitung jumlah buku otomatis.
* **Kontrol Stok Fisik & Kartu Stok**: Riwayat mutasi stok masuk, keluar, dan penyesuaian manual (stock adjustment).
* **Manajemen Pesanan & Cetak Invoice**: Kelola status pesanan, input nomor resi pengiriman kurir, dan cetak invoice/nota resmi toko.
* **Daftar Pelanggan**: Riwayat pelanggan setia, jumlah pesanan, dan total belanja.
* **Pengaturan Profil Toko**: Ubah nama toko, nomor WhatsApp penjual, alamat, jam operasional, rekening bank transfer, dan ongkos kirim flat.
* **Cadangan & Pemulihan (Backup & Restore JSON)**: Unduh salinan data seluruh sistem dan pulihkan kapan saja.

---

## 🛠️ Arsitektur Teknologi

* **Frontend**: React 19, TypeScript, Tailwind CSS, Lucide Icons, Canvas Confetti.
* **Backend**: Node.js, Express, TypeScript (`tsx`).
* **Database**: PostgreSQL eksternal (Supabase, Neon, atau Render Postgres) via driver `pg`. Dilengkapi fallback lokal JSON (`data/db.json`) untuk development tanpa koneksi internet.
* **Keamanan**: Password hashing dengan `bcryptjs`, proteksi token admin, pemisahan rute publik dan privat, serta CORS & preflight headers.
* **Deployment**: Siap deploy di [Render.com](https://render.com) menggunakan `render.yaml` (Free Web Service).

---

## 🚀 Panduan Menjalankan di Lokal (Development)

1. **Clone repository dan install dependensi**:
   ```bash
   git clone <URL_REPO_ANDA>
   cd ekatalog-buku
   npm install
   ```

2. **Jalankan server development**:
   ```bash
   npm run dev
   ```
   Aplikasi akan berjalan di `http://localhost:3000`.

3. **Login Admin Default**:
   * Akses URL: `http://localhost:3000/#admin`
   * **Username**: `admin`
   * **Password / PIN**: `admin123`

---

## 🗄️ Setup Database PostgreSQL Persisten di Supabase (Gratis)

Render Free Web Service memiliki filesystem yang bersifat sementara (ephemeral). Oleh karena itu, aplikasi menggunakan **PostgreSQL eksternal** yang persisten (misalnya Supabase).

1. Daftar akun gratis di [https://supabase.com](https://supabase.com).
2. Buat project baru (contoh: `ekatalog-db`), pilih region terdekat (misal: **Singapore**).
3. Setelah project dibuat, masuk ke menu **Project Settings** > **Database** > bagian **Connection string** > pilih tab **URI**.
4. Salin URL koneksi tersebut, formatnya:
   ```text
   postgresql://postgres.[REF_PROJECT]:[PASSWORD_ANDA]@aws-0-ap-southeast-1.pooler.supabase.com:6543/postgres
   ```
   *(Pastikan ganti `[PASSWORD_ANDA]` dengan password database yang Anda buat saat setup)*.
5. Simpan URL ini ke environment variable `DATABASE_URL`. Saat server dinyalakan, aplikasi akan **otomatis membuat seluruh tabel (auto-migration) dan mengisi data demo awal** ke PostgreSQL Anda!

*(Opsional: Anda juga dapat menjalankan file `supabase/migration.sql` di SQL Editor Supabase jika ingin memeriksa struktur tabel secara manual).*

---

## ☁️ Panduan Deployment ke Render.com (Gratis)

### Langkah 1: Hubungkan ke GitHub
1. Buat repository baru di [GitHub](https://github.com) (misal: `ekatalog-buku`).
2. Push seluruh kode proyek ini ke repository GitHub Anda:
   ```bash
   git init
   git add .
   git commit -m "feat: Initial commit e-Katalog fullstack"
   git branch -M main
   git remote add origin https://github.com/USERNAME/ekatalog-buku.git
   git push -u origin main
   ```

### Langkah 2: Buat Web Service di Render
1. Buka [https://render.com](https://render.com) dan login dengan akun GitHub Anda.
2. Klik tombol **New +** di pojok kanan atas > pilih **Web Service**.
3. Pilih repository `ekatalog-buku` yang baru saja Anda push.
4. Render akan membaca file `render.yaml` secara otomatis, atau Anda dapat mengisi formulir:
   * **Name**: `ekatalog-buku` (atau nama toko Anda)
   * **Region**: `Singapore`
   * **Branch**: `main`
   * **Runtime**: `Node`
   * **Build Command**: `npm install && npm run build`
   * **Start Command**: `node server.ts`
   * **Instance Type**: `Free`

### Langkah 3: Atur Environment Variables di Render
Di menu **Environment Variables**, masukkan variabel berikut:
* `NODE_ENV` = `production`
* `PORT` = `10000`
* `DATABASE_URL` = *(Tempelkan URL koneksi PostgreSQL Supabase Anda di sini)*
* `ADMIN_USERNAME` = `admin`
* `ADMIN_PIN` = `admin123` *(atau ganti dengan password yang Anda inginkan)*

### Langkah 4: Selesaikan Deployment
1. Klik **Deploy Web Service** (atau **Create Web Service**).
2. Render akan menjalankan proses build (`npm run build`) dan memulai server (`node server.ts`).
3. Setelah status berubah menjadi **Live**, Anda akan mendapatkan URL publik HTTPS resmi, contoh:
   `https://ekatalog-buku.onrender.com`
4. Buka URL tersebut di browser HP, tablet, atau laptop. Aplikasi dapat diakses oleh siapa saja secara publik tanpa perlu login Google!

---

## 🏥 Health Check Endpoint

Render akan memantau kesehatan server melalui endpoint:
```http
GET /health
```
Contoh respon:
```json
{
  "status": "ok",
  "service": "e-Katalog Penjualan Buku",
  "database": "postgres",
  "uptimeSeconds": 1420,
  "timestamp": "2026-10-20T17:10:00.000Z"
}
```

---

## 🔒 Keamanan & Kebijakan Akses

* **Password Hashing**: Password dan PIN admin dienkripsi menggunakan algoritma `bcrypt` (10 salt rounds).
* **Token Autentikasi**: Endpoint admin (`/api/books` [POST/PUT/DELETE], `/api/orders` [GET], `/api/stock-adjustments`, `/api/customers`, `/api/backup`) dilindungi verifikasi token.
* **Perlindungan Data Publik**: Pengunjung umum hanya dapat mengakses endpoint katalog publik (`/api/books` buku aktif, `/api/categories`, `/api/config`), membuat pesanan, dan melacak pesanan. PIN admin tidak pernah dikirim ke pengunjung umum.
