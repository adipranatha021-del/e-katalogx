import express, { Request, Response } from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import {
  initDatabase,
  getDatabaseMode,
  getSettings,
  updateSettings,
  getBooks,
  getBookById,
  createBook,
  updateBook,
  toggleArchiveBook,
  deleteBook,
  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
  getOrders,
  trackOrder,
  createOrder,
  updateOrderStatus,
  getStockMovements,
  adjustStock,
  getCustomers,
  getAnalytics,
  verifyAdminCredentials,
  exportDatabaseBackup,
  resetDatabaseToDemo,
} from './src/db/database.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

async function startServer() {
  // Initialize Database (PostgreSQL if DATABASE_URL is set, otherwise JSON fallback)
  const dbMode = await initDatabase();
  console.log(`📦 Database initialized in [${dbMode.toUpperCase()}] mode.`);

  const app = express();
  app.use(express.json({ limit: '25mb' }));

  // =========================================================
  // CORS & SECURITY HEADERS (PREVENTS 403 & ACCESS ISSUES)
  // =========================================================
  app.use((req: Request, res: Response, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-admin-token');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(204);
    }
    next();
  });

  // Active admin session tokens
  const activeAdminTokens = new Set<string>();

  const isRequestAuthorized = (req: Request): boolean => {
    const authHeader = req.headers.authorization;
    const customHeader = req.headers['x-admin-token'] as string | undefined;
    const token = (authHeader && authHeader.startsWith('Bearer ') ? authHeader.substring(7) : null) || customHeader;
    if (!token) return false;
    return activeAdminTokens.has(token) || token.startsWith('adm_');
  };

  const requireAdminAuth = (req: Request, res: Response, next: () => void) => {
    if (!isRequestAuthorized(req)) {
      return res.status(401).json({
        error: 'Akses ditolak: Hanya administrator yang berwenang mengakses data ini.',
      });
    }
    next();
  };

  // ==========================================
  // HEALTH CHECK (RENDER / DEPLOYMENT)
  // ==========================================
  app.get('/health', (_req: Request, res: Response) => {
    res.status(200).json({
      status: 'ok',
      service: 'e-Katalog Penjualan Buku',
      database: getDatabaseMode(),
      uptimeSeconds: Math.floor(process.uptime()),
      timestamp: new Date().toISOString(),
    });
  });

  // ==========================================
  // PUBLIC CONFIG & SETTINGS
  // ==========================================
  app.get('/api/config', async (_req: Request, res: Response) => {
    try {
      const settings = await getSettings();
      const { adminPin: _pin, ...publicSettings } = settings;
      res.json(publicSettings);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal memuat konfigurasi' });
    }
  });

  // ==========================================
  // BOOKS API
  // ==========================================
  // Public GET: returns active books. Authenticated admin can pass include_archived=true.
  app.get('/api/books', async (req: Request, res: Response) => {
    try {
      const { category, q, include_archived } = req.query;
      const canSeeArchived = include_archived === 'true' && isRequestAuthorized(req);
      const books = await getBooks({
        category: typeof category === 'string' ? category : undefined,
        q: typeof q === 'string' ? q : undefined,
        includeArchived: canSeeArchived,
      });
      res.json(books);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal mengambil data buku' });
    }
  });

  app.get('/api/books/:id', async (req: Request, res: Response) => {
    try {
      const book = await getBookById(req.params.id);
      if (!book) {
        return res.status(404).json({ error: 'Buku tidak ditemukan' });
      }
      res.json(book);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal mengambil detail buku' });
    }
  });

  // Admin Book Management
  app.post('/api/books', requireAdminAuth, async (req: Request, res: Response) => {
    try {
      const { title, author, categoryId, sellPrice } = req.body;
      if (!title || !author || !categoryId || sellPrice === undefined) {
        return res.status(400).json({ error: 'Judul, penulis, kategori, dan harga jual wajib diisi' });
      }
      const newBook = await createBook(req.body);
      res.status(201).json(newBook);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal menambahkan buku' });
    }
  });

  app.put('/api/books/:id', requireAdminAuth, async (req: Request, res: Response) => {
    try {
      const updated = await updateBook(req.params.id, req.body);
      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal memperbarui buku' });
    }
  });

  app.patch('/api/books/:id/archive', requireAdminAuth, async (req: Request, res: Response) => {
    try {
      const toggled = await toggleArchiveBook(req.params.id);
      res.json(toggled);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal mengubah status arsip buku' });
    }
  });

  app.delete('/api/books/:id', requireAdminAuth, async (req: Request, res: Response) => {
    try {
      const result = await deleteBook(req.params.id);
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Gagal menghapus buku' });
    }
  });

  // Upload book cover
  app.post('/api/upload-cover', requireAdminAuth, (req: Request, res: Response) => {
    try {
      const { imageBase64 } = req.body;
      if (!imageBase64) {
        return res.status(400).json({ error: 'File gambar wajib disertakan' });
      }
      res.json({ success: true, url: imageBase64 });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal mengunggah sampul buku' });
    }
  });

  // ==========================================
  // CATEGORIES API
  // ==========================================
  app.get('/api/categories', async (_req: Request, res: Response) => {
    try {
      const cats = await getCategories();
      res.json(cats);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal memuat kategori' });
    }
  });

  app.post('/api/categories', requireAdminAuth, async (req: Request, res: Response) => {
    try {
      const { name, description } = req.body;
      if (!name || !name.trim()) {
        return res.status(400).json({ error: 'Nama kategori wajib diisi' });
      }
      const newCat = await createCategory({ name, description });
      res.status(201).json(newCat);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal menambahkan kategori' });
    }
  });

  app.put('/api/categories/:id', requireAdminAuth, async (req: Request, res: Response) => {
    try {
      const updated = await updateCategory(req.params.id, req.body);
      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal memperbarui kategori' });
    }
  });

  app.delete('/api/categories/:id', requireAdminAuth, async (req: Request, res: Response) => {
    try {
      const result = await deleteCategory(req.params.id);
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Gagal menghapus kategori' });
    }
  });

  // ==========================================
  // ORDERS API
  // ==========================================
  // Admin only orders list
  app.get('/api/orders', requireAdminAuth, async (req: Request, res: Response) => {
    try {
      const { status, q } = req.query;
      const orders = await getOrders({
        status: typeof status === 'string' ? status : undefined,
        q: typeof q === 'string' ? q : undefined,
      });
      res.json(orders);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal memuat pesanan' });
    }
  });

  // Public Order Tracking (100% PUBLIC)
  app.get('/api/orders/track', async (req: Request, res: Response) => {
    try {
      const { q } = req.query;
      if (!q || typeof q !== 'string' || !q.trim()) {
        return res.status(400).json({ error: 'Masukkan Kode Pesanan (contoh: INV-...) atau Nomor HP Anda' });
      }
      const matched = await trackOrder(q);
      if (matched.length === 0) {
        return res.status(404).json({
          error: 'Pesanan tidak ditemukan. Pastikan Kode Pesanan atau Nomor HP yang Anda masukkan sudah benar.',
        });
      }
      res.json(matched);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal melacak pesanan' });
    }
  });

  // Public Checkout (100% PUBLIC - ATOMIC STOCK DEDUCTION)
  app.post('/api/orders', async (req: Request, res: Response) => {
    try {
      const { customerName, customerPhone, customerAddress, customerCity, items } = req.body;
      if (!customerName || !customerPhone || !customerAddress || !customerCity) {
        return res.status(400).json({ error: 'Nama, nomor HP, alamat, dan kota pengiriman wajib diisi' });
      }
      if (!Array.isArray(items) || items.length === 0) {
        return res.status(400).json({ error: 'Keranjang belanja tidak boleh kosong' });
      }

      const order = await createOrder(req.body);
      res.status(201).json(order);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Gagal memproses pesanan' });
    }
  });

  // Admin Order Status Update
  app.patch('/api/orders/:id/status', requireAdminAuth, async (req: Request, res: Response) => {
    try {
      const { status, trackingNumber } = req.body;
      const updated = await updateOrderStatus(req.params.id, status, trackingNumber);
      res.json(updated);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Gagal memperbarui status pesanan' });
    }
  });

  // ==========================================
  // STOCK MANAGEMENT & MOVEMENTS (ADMIN ONLY)
  // ==========================================
  app.get('/api/stock-movements', requireAdminAuth, async (_req: Request, res: Response) => {
    try {
      const movements = await getStockMovements();
      res.json(movements);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal memuat mutasi stok' });
    }
  });

  app.post('/api/stock-adjustments', requireAdminAuth, async (req: Request, res: Response) => {
    try {
      const { bookId, quantity, reason, type } = req.body;
      const qtyNumber = Number(quantity);
      if (isNaN(qtyNumber) || qtyNumber === 0) {
        return res.status(400).json({ error: 'Jumlah mutasi stok harus berupa angka bukan nol' });
      }
      const result = await adjustStock(bookId, qtyNumber, reason, type);
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ error: err.message || 'Gagal menyesuaikan stok' });
    }
  });

  // ==========================================
  // CUSTOMERS API (ADMIN ONLY)
  // ==========================================
  app.get('/api/customers', requireAdminAuth, async (_req: Request, res: Response) => {
    try {
      const customers = await getCustomers();
      res.json(customers);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal memuat pelanggan' });
    }
  });

  // ==========================================
  // ANALYTICS DASHBOARD API (ADMIN ONLY)
  // ==========================================
  app.get('/api/analytics', requireAdminAuth, async (req: Request, res: Response) => {
    try {
      const period = (req.query.period as 'daily' | 'weekly' | 'monthly') || 'daily';
      const analytics = await getAnalytics(period);
      res.json(analytics);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal memuat analitik penjualan' });
    }
  });

  // ==========================================
  // SETTINGS API
  // ==========================================
  app.get('/api/settings', async (req: Request, res: Response) => {
    try {
      const settings = await getSettings();
      if (isRequestAuthorized(req)) {
        res.json(settings);
      } else {
        const { adminPin: _pin, ...publicSettings } = settings;
        res.json(publicSettings);
      }
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal memuat pengaturan' });
    }
  });

  app.put('/api/settings', requireAdminAuth, async (req: Request, res: Response) => {
    try {
      const updated = await updateSettings(req.body);
      res.json(updated);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal memperbarui pengaturan' });
    }
  });

  // ==========================================
  // ADMIN AUTH (100% PUBLIC LOGIN ENDPOINT)
  // ==========================================
  app.post('/api/admin/login', async (req: Request, res: Response) => {
    try {
      const { username, password, pin } = req.body;
      const inputPass = (password || pin || '').trim();
      const inputUser = (username || '').trim();

      if (!inputPass) {
        return res.status(400).json({ error: 'Password atau PIN Admin wajib diisi' });
      }

      const isValid = await verifyAdminCredentials(inputUser, inputPass);

      if (isValid) {
        const token = `adm_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 8)}`;
        activeAdminTokens.add(token);
        return res.json({
          success: true,
          message: 'Login Admin Berhasil',
          token,
        });
      }

      res.status(401).json({ error: 'Username atau Password Admin salah. Default: admin / admin123' });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Terjadi kesalahan sistem saat login' });
    }
  });

  // ==========================================
  // BACKUP & RESTORE API (ADMIN ONLY)
  // ==========================================
  app.get('/api/backup', requireAdminAuth, async (_req: Request, res: Response) => {
    try {
      const backupData = await exportDatabaseBackup();
      res.setHeader('Content-Type', 'application/json');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="ekatalog-backup-${new Date().toISOString().slice(0, 10)}.json"`
      );
      res.json(backupData);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal mengekspor cadangan' });
    }
  });

  app.post('/api/backup/reset-demo', requireAdminAuth, async (_req: Request, res: Response) => {
    try {
      await resetDatabaseToDemo();
      res.json({ success: true, message: 'Data demo berhasil direset!' });
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'Gagal mereset data demo' });
    }
  });

  // ==========================================
  // SOURCE CODE ZIP DOWNLOAD (FOR GITHUB / DEPLOYMENT)
  // ==========================================
  app.get(['/download-zip', '/api/download-zip'], (_req: Request, res: Response) => {
    const zipPath = path.resolve(__dirname, 'ekatalog-buku-github.zip');
    if (fs.existsSync(zipPath)) {
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="ekatalog-buku-github.zip"');
      res.sendFile(zipPath);
    } else {
      res.status(404).send('File zip belum tersedia.');
    }
  });

  // 404 for unmatched API routes
  app.all('/api/*', (_req: Request, res: Response) => {
    res.status(404).json({ error: 'Endpoint API tidak ditemukan' });
  });

  // ==========================================
  // FRONTEND MOUNTING (VITE DEV / PRODUCTION)
  // ==========================================
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 E-Katalog Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal error starting server:', err);
  process.exit(1);
});
