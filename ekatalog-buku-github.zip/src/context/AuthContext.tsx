import React, { createContext, useContext, useState, useEffect } from 'react';
import { api } from '../services/api.ts';

interface AuthContextType {
  isAdminAuthenticated: boolean;
  login: (credentials: string | { username?: string; password?: string; pin?: string }) => Promise<boolean>;
  logout: () => void;
  isLoginModalOpen: boolean;
  openLoginModal: () => void;
  closeLoginModal: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isAdminAuthenticated, setIsAdminAuthenticated] = useState<boolean>(() => {
    try {
      const token = localStorage.getItem('ekatalog_admin_token');
      return Boolean(token);
    } catch {
      return false;
    }
  });

  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem('ekatalog_admin_token');
    setIsAdminAuthenticated(Boolean(token));
  }, []);

  const login = async (credentials: string | { username?: string; password?: string; pin?: string }): Promise<boolean> => {
    try {
      const res = await api.loginAdmin(credentials);
      if (res.success && res.token) {
        localStorage.setItem('ekatalog_admin_token', res.token);
        setIsAdminAuthenticated(true);
        setIsLoginModalOpen(false);
        return true;
      }
      return false;
    } catch (err) {
      throw err;
    }
  };

  const logout = () => {
    localStorage.removeItem('ekatalog_admin_token');
    setIsAdminAuthenticated(false);
  };

  return (
    <AuthContext.Provider
      value={{
        isAdminAuthenticated,
        login,
        logout,
        isLoginModalOpen,
        openLoginModal: () => setIsLoginModalOpen(true),
        closeLoginModal: () => setIsLoginModalOpen(false),
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
