import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import pg from 'pg';
import bcrypt from 'bcryptjs';
import {
  Book,
  Category,
  Customer,
  Order,
  OrderItem,
  StockMovement,
  AppSettings,
  SalesAnalytics,
} from '../types.ts';
import {
  INITIAL_BOOKS,
  INITIAL_CATEGORIES,
  INITIAL_CUSTOMERS,
  INITIAL_ORDERS,
  INITIAL_STOCK_MOVEMENTS,
  INITIAL_SETTINGS,
} from '../data/seedData.ts';

const { Pool } = pg;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.resolve(__dirname, '../../data');
const DB_FILE = path.resolve(DATA_DIR, 'db.json');

interface DatabaseSchema {
  books: Book[];
  categories: Category[];
  customers: Customer[];
  orders: Order[];
  stockMovements: StockMovement[];
  settings: AppSettings;
  catalogCounter?: number;
}

// Global state
let pool: pg.Pool | null = null;
let databaseMode: 'postgres' | 'json' = 'json';
let localDb: DatabaseSchema;

const generateId = (prefix: string) =>
  `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;

function ensureDataDirectory() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function loadLocalJsonDatabase(): DatabaseSchema {
  ensureDataDirectory();
  if (fs.existsSync(DB_FILE)) {
    try {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      const parsed = JSON.parse(content);
      if (
        Array.isArray(parsed.books) &&
        Array.isArray(parsed.categories) &&
        Array.isArray(parsed.orders) &&
        Array.isArray(parsed.customers) &&
        parsed.settings
      ) {
        return parsed;
      }
    } catch (err) {
      console.warn('Failed to parse db.json, falling back to seed:', err);
    }
  }

  const initialDb: DatabaseSchema = {
    books: INITIAL_BOOKS,
    categories: INITIAL_CATEGORIES,
    customers: INITIAL_CUSTOMERS,
    orders: INITIAL_ORDERS,
    stockMovements: INITIAL_STOCK_MOVEMENTS,
    settings: {
      ...INITIAL_SETTINGS,
      adminPin: bcrypt.hashSync(INITIAL_SETTINGS.adminPin || 'admin123', 10),
    },
    catalogCounter: 8,
  };

  saveLocalJsonDatabase(initialDb);
  return initialDb;
}

function saveLocalJsonDatabase(dataToSave: DatabaseSchema) {
  ensureDataDirectory();
  const tempFile = `${DB_FILE}.tmp`;
  fs.writeFileSync(tempFile, JSON.stringify(dataToSave, null, 2), 'utf-8');
  fs.renameSync(tempFile, DB_FILE);
}

// ============================================================================
// POSTGRESQL SCHEMA INITIALIZATION & MIGRATIONS
// ============================================================================
async function initPostgresSchema(client: pg.PoolClient) {
  console.log('🔄 Checking & initializing PostgreSQL schema...');

  await client.query(`
    CREATE TABLE IF NOT EXISTS app_settings (
      id VARCHAR(50) PRIMARY KEY,
      store_name TEXT NOT NULL,
      store_tagline TEXT,
      logo_url TEXT,
      banner_url TEXT,
      owner_name TEXT,
      whatsapp_number TEXT NOT NULL,
      store_address TEXT,
      store_email TEXT,
      operating_hours TEXT,
      bank_accounts JSONB DEFAULT '[]'::jsonb,
      enable_cod BOOLEAN DEFAULT true,
      low_stock_threshold INTEGER DEFAULT 5,
      shipping_flat_rate NUMERIC(12, 2) DEFAULT 15000,
      admin_username TEXT DEFAULT 'admin',
      admin_pin TEXT,
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS categories (
      id VARCHAR(50) PRIMARY KEY,
      name TEXT NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      description TEXT,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS books (
      id VARCHAR(50) PRIMARY KEY,
      catalog_number VARCHAR(20) NOT NULL,
      isbn VARCHAR(30),
      title TEXT NOT NULL,
      author TEXT NOT NULL,
      publisher TEXT,
      year INTEGER,
      category_id VARCHAR(50) REFERENCES categories(id) ON DELETE SET NULL,
      category_name TEXT,
      description TEXT,
      cost_price NUMERIC(12, 2) DEFAULT 0,
      sell_price NUMERIC(12, 2) NOT NULL,
      stock INTEGER NOT NULL DEFAULT 0,
      min_stock_alert INTEGER DEFAULT 5,
      cover_url TEXT,
      age_group VARCHAR(50) DEFAULT 'Usia 3 - 6 Tahun',
      rating NUMERIC(3, 2) DEFAULT 5.0,
      review_count INTEGER DEFAULT 10,
      is_active BOOLEAN DEFAULT true,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS customers (
      id VARCHAR(50) PRIMARY KEY,
      name TEXT NOT NULL,
      phone VARCHAR(30) NOT NULL,
      address TEXT NOT NULL,
      city VARCHAR(100) NOT NULL,
      total_orders INTEGER DEFAULT 1,
      total_spent NUMERIC(14, 2) DEFAULT 0,
      last_order_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS orders (
      id VARCHAR(50) PRIMARY KEY,
      order_code VARCHAR(50) NOT NULL UNIQUE,
      customer_id VARCHAR(50) REFERENCES customers(id) ON DELETE SET NULL,
      customer_name TEXT NOT NULL,
      customer_phone VARCHAR(30) NOT NULL,
      customer_address TEXT NOT NULL,
      customer_city VARCHAR(100) NOT NULL,
      payment_method VARCHAR(30) NOT NULL DEFAULT 'transfer_bank',
      bank_name VARCHAR(50),
      status VARCHAR(40) NOT NULL DEFAULT 'Menunggu Konfirmasi',
      tracking_number VARCHAR(100),
      notes TEXT,
      subtotal NUMERIC(14, 2) NOT NULL DEFAULT 0,
      shipping_cost NUMERIC(12, 2) NOT NULL DEFAULT 15000,
      total_amount NUMERIC(14, 2) NOT NULL DEFAULT 0,
      items JSONB NOT NULL DEFAULT '[]'::jsonb,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );

    CREATE TABLE IF NOT EXISTS stock_movements (
      id VARCHAR(50) PRIMARY KEY,
      book_id VARCHAR(50) NOT NULL,
      book_title TEXT NOT NULL,
      type VARCHAR(30) NOT NULL,
      quantity INTEGER NOT NULL,
      previous_stock INTEGER NOT NULL,
      current_stock INTEGER NOT NULL,
      reason TEXT NOT NULL,
      created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
    );
  `);

  // Check if categories table is empty, seed if empty
  const catCount = await client.query('SELECT COUNT(*) FROM categories');
  if (parseInt(catCount.rows[0].count, 10) === 0) {
    console.log('🌱 Seeding initial categories into PostgreSQL...');
    for (const c of INITIAL_CATEGORIES) {
      await client.query(
        'INSERT INTO categories (id, name, slug, description) VALUES ($1, $2, $3, $4) ON CONFLICT DO NOTHING',
        [c.id, c.name, c.slug, c.description || '']
      );
    }
  }

  // Check if books table is empty, seed if empty
  const bookCount = await client.query('SELECT COUNT(*) FROM books');
  if (parseInt(bookCount.rows[0].count, 10) === 0) {
    console.log('🌱 Seeding initial books into PostgreSQL...');
    for (const b of INITIAL_BOOKS) {
      await client.query(
        `INSERT INTO books (
          id, catalog_number, isbn, title, author, publisher, year, category_id,
          category_name, description, cost_price, sell_price, stock, min_stock_alert,
          cover_url, age_group, rating, review_count, is_active, created_at, updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21)
        ON CONFLICT DO NOTHING`,
        [
          b.id,
          b.catalogNumber || '001',
          b.isbn || null,
          b.title,
          b.author,
          b.publisher || 'Penerbit PAUD Ceria',
          b.year || new Date().getFullYear(),
          b.categoryId,
          b.categoryName,
          b.description || '',
          b.costPrice || 0,
          b.sellPrice,
          b.stock,
          b.minStockAlert || 5,
          b.coverUrl,
          b.ageGroup || 'Usia 3 - 6 Tahun',
          b.rating || 5.0,
          b.reviewCount || 10,
          b.isActive,
          b.createdAt,
          b.updatedAt,
        ]
      );
    }
  }

  // Check if settings table is empty, seed if empty
  const settingsCount = await client.query('SELECT COUNT(*) FROM app_settings');
  if (parseInt(settingsCount.rows[0].count, 10) === 0) {
    console.log('🌱 Seeding initial settings into PostgreSQL...');
    const hashedPin = bcrypt.hashSync(INITIAL_SETTINGS.adminPin || 'admin123', 10);
    await client.query(
      `INSERT INTO app_settings (
        id, store_name, store_tagline, logo_url, banner_url, owner_name, whatsapp_number,
        store_address, store_email, operating_hours, bank_accounts, enable_cod,
        low_stock_threshold, shipping_flat_rate, admin_username, admin_pin, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, NOW())`,
      [
        'global_settings',
        INITIAL_SETTINGS.storeName,
        INITIAL_SETTINGS.storeTagline,
        INITIAL_SETTINGS.logoUrl,
        INITIAL_SETTINGS.bannerUrl,
        INITIAL_SETTINGS.ownerName,
        INITIAL_SETTINGS.whatsappNumber,
        INITIAL_SETTINGS.storeAddress,
        INITIAL_SETTINGS.storeEmail,
        INITIAL_SETTINGS.operatingHours,
        JSON.stringify(INITIAL_SETTINGS.bankAccounts),
        INITIAL_SETTINGS.enableCod,
        INITIAL_SETTINGS.lowStockThreshold,
        INITIAL_SETTINGS.shippingFlatRate,
        INITIAL_SETTINGS.adminUsername || 'admin',
        hashedPin,
      ]
    );
  }

  // Check if customers table is empty, seed if empty
  const customerCount = await client.query('SELECT COUNT(*) FROM customers');
  if (parseInt(customerCount.rows[0].count, 10) === 0) {
    for (const cust of INITIAL_CUSTOMERS) {
      await client.query(
        `INSERT INTO customers (id, name, phone, address, city, total_orders, total_spent, last_order_at, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) ON CONFLICT DO NOTHING`,
        [cust.id, cust.name, cust.phone, cust.address, cust.city, cust.totalOrders, cust.totalSpent, cust.lastOrderAt, cust.createdAt]
      );
    }
  }

  // Check if orders table is empty, seed if empty
  const ordersCount = await client.query('SELECT COUNT(*) FROM orders');
  if (parseInt(ordersCount.rows[0].count, 10) === 0) {
    for (const ord of INITIAL_ORDERS) {
      await client.query(
        `INSERT INTO orders (
          id, order_code, customer_name, customer_phone, customer_address, customer_city,
          payment_method, bank_name, status, notes, subtotal, shipping_cost, total_amount, items, created_at, updated_at
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16) ON CONFLICT DO NOTHING`,
        [
          ord.id,
          ord.orderCode,
          ord.customerName,
          ord.customerPhone,
          ord.customerAddress,
          ord.customerCity,
          ord.paymentMethod,
          ord.bankName || null,
          ord.status,
          ord.notes || '',
          ord.subtotal,
          ord.shippingCost,
          ord.totalAmount,
          JSON.stringify(ord.items),
          ord.createdAt,
          ord.updatedAt,
        ]
      );
    }
  }

  console.log('✅ PostgreSQL Schema and seed synchronization completed successfully!');
}

// Helper to validate whether a string is a valid PostgreSQL URI
function isValidPostgresConnectionString(url: string | undefined): boolean {
  if (!url || typeof url !== 'string') return false;
  const trimmed = url.trim();
  if (!trimmed.startsWith('postgresql://') && !trimmed.startsWith('postgres://')) {
    return false;
  }
  if (
    trimmed.includes('[PASSWORD]') ||
    trimmed.includes('[YOUR-PASSWORD]') ||
    trimmed.includes('MY_DATABASE_URL')
  ) {
    return false;
  }
  try {
    const parsed = new URL(trimmed);
    return Boolean(parsed.hostname && parsed.hostname.length >= 3);
  } catch {
    return false;
  }
}

// ============================================================================
// DATABASE INITIALIZATION ENTRYPOINT
// ============================================================================
export async function initDatabase(): Promise<'postgres' | 'json'> {
  const databaseUrl = process.env.DATABASE_URL;

  if (isValidPostgresConnectionString(databaseUrl)) {
    try {
      console.log('🔌 Connecting to PostgreSQL at DATABASE_URL...');
      pool = new Pool({
        connectionString: databaseUrl,
        ssl: databaseUrl!.includes('localhost') ? false : { rejectUnauthorized: false },
        connectionTimeoutMillis: 5000,
      });

      const client = await pool.connect();
      try {
        await initPostgresSchema(client);
        databaseMode = 'postgres';
        console.log('🚀 Connected to persistent PostgreSQL Database successfully!');
        return 'postgres';
      } finally {
        client.release();
      }
    } catch (err: any) {
      console.warn('ℹ️ PostgreSQL connection unavailable, running in local JSON database mode:', err?.message || err);
      if (pool) {
        try {
          await pool.end();
        } catch {
          // ignore cleanup error
        }
        pool = null;
      }
      databaseMode = 'json';
      localDb = loadLocalJsonDatabase();
      return 'json';
    }
  } else {
    // If DATABASE_URL is not set or not a valid postgresql:// URI, use local JSON store cleanly
    databaseMode = 'json';
    localDb = loadLocalJsonDatabase();
    console.log('📁 Database initialized in local JSON mode (data/db.json).');
    return 'json';
  }
}

export function getDatabaseMode(): 'postgres' | 'json' {
  return databaseMode;
}

// ============================================================================
// REPOSITORIES & CRUD OPERATIONS
// ============================================================================

// --- SETTINGS ---
export async function getSettings(): Promise<AppSettings> {
  if (databaseMode === 'postgres' && pool) {
    const res = await pool.query('SELECT * FROM app_settings LIMIT 1');
    if (res.rows.length > 0) {
      const r = res.rows[0];
      return {
        storeName: r.store_name,
        storeTagline: r.store_tagline,
        logoUrl: r.logo_url,
        bannerUrl: r.banner_url,
        ownerName: r.owner_name,
        whatsappNumber: r.whatsapp_number,
        storeAddress: r.store_address,
        storeEmail: r.store_email,
        operatingHours: r.operating_hours,
        bankAccounts: typeof r.bank_accounts === 'string' ? JSON.parse(r.bank_accounts) : r.bank_accounts,
        enableCod: r.enable_cod,
        lowStockThreshold: r.low_stock_threshold,
        shippingFlatRate: Number(r.shipping_flat_rate),
        adminUsername: r.admin_username,
        adminPin: r.admin_pin,
        updatedAt: r.updated_at,
      };
    }
  }
  return localDb.settings;
}

export async function updateSettings(updates: Partial<AppSettings>): Promise<AppSettings> {
  const current = await getSettings();

  let newHashedPin = current.adminPin;
  if (updates.adminPin && updates.adminPin.trim() !== '') {
    // Hash if not already hashed
    if (!updates.adminPin.startsWith('$2a$') && !updates.adminPin.startsWith('$2b$')) {
      newHashedPin = bcrypt.hashSync(updates.adminPin.trim(), 10);
    } else {
      newHashedPin = updates.adminPin;
    }
  }

  const updated: AppSettings = {
    ...current,
    storeName: updates.storeName !== undefined ? updates.storeName.trim() : current.storeName,
    storeTagline: updates.storeTagline !== undefined ? updates.storeTagline.trim() : current.storeTagline,
    logoUrl: updates.logoUrl !== undefined ? updates.logoUrl.trim() : current.logoUrl,
    bannerUrl: updates.bannerUrl !== undefined ? updates.bannerUrl.trim() : current.bannerUrl,
    ownerName: updates.ownerName !== undefined ? updates.ownerName.trim() : current.ownerName,
    whatsappNumber: updates.whatsappNumber !== undefined ? updates.whatsappNumber.trim() : current.whatsappNumber,
    storeAddress: updates.storeAddress !== undefined ? updates.storeAddress.trim() : current.storeAddress,
    storeEmail: updates.storeEmail !== undefined ? updates.storeEmail.trim() : current.storeEmail,
    operatingHours: updates.operatingHours !== undefined ? updates.operatingHours.trim() : current.operatingHours,
    bankAccounts: Array.isArray(updates.bankAccounts) ? updates.bankAccounts : current.bankAccounts,
    enableCod: updates.enableCod !== undefined ? Boolean(updates.enableCod) : current.enableCod,
    lowStockThreshold: updates.lowStockThreshold !== undefined ? Number(updates.lowStockThreshold) : current.lowStockThreshold,
    shippingFlatRate: updates.shippingFlatRate !== undefined ? Number(updates.shippingFlatRate) : current.shippingFlatRate,
    adminUsername: updates.adminUsername !== undefined ? updates.adminUsername.trim() : current.adminUsername,
    adminPin: newHashedPin,
    updatedAt: new Date().toISOString(),
  };

  if (databaseMode === 'postgres' && pool) {
    await pool.query(
      `UPDATE app_settings SET
        store_name = $1, store_tagline = $2, logo_url = $3, banner_url = $4, owner_name = $5,
        whatsapp_number = $6, store_address = $7, store_email = $8, operating_hours = $9,
        bank_accounts = $10, enable_cod = $11, low_stock_threshold = $12, shipping_flat_rate = $13,
        admin_username = $14, admin_pin = $15, updated_at = NOW()
       WHERE id = 'global_settings'`,
      [
        updated.storeName,
        updated.storeTagline,
        updated.logoUrl,
        updated.bannerUrl,
        updated.ownerName,
        updated.whatsappNumber,
        updated.storeAddress,
        updated.storeEmail,
        updated.operatingHours,
        JSON.stringify(updated.bankAccounts),
        updated.enableCod,
        updated.lowStockThreshold,
        updated.shippingFlatRate,
        updated.adminUsername,
        updated.adminPin,
      ]
    );
  } else {
    localDb.settings = updated;
    saveLocalJsonDatabase(localDb);
  }

  return updated;
}

// --- BOOKS ---
export async function getBooks(options?: {
  category?: string;
  q?: string;
  includeArchived?: boolean;
}): Promise<Book[]> {
  if (databaseMode === 'postgres' && pool) {
    let query = 'SELECT * FROM books WHERE 1=1';
    const params: any[] = [];

    if (!options?.includeArchived) {
      query += ' AND is_active = true';
    }

    if (options?.category && options.category !== 'all') {
      params.push(options.category);
      query += ` AND (category_id = $${params.length} OR LOWER(category_name) = LOWER($${params.length}))`;
    }

    if (options?.q && options.q.trim()) {
      params.push(`%${options.q.trim().toLowerCase()}%`);
      query += ` AND (LOWER(title) LIKE $${params.length} OR LOWER(author) LIKE $${params.length} OR LOWER(isbn) LIKE $${params.length})`;
    }

    query += ' ORDER BY catalog_number ASC, created_at DESC';
    const res = await pool.query(query, params);

    return res.rows.map((r) => ({
      id: r.id,
      catalogNumber: r.catalog_number,
      isbn: r.isbn,
      title: r.title,
      author: r.author,
      publisher: r.publisher,
      year: r.year,
      categoryId: r.category_id,
      categoryName: r.category_name,
      description: r.description,
      costPrice: Number(r.cost_price || 0),
      sellPrice: Number(r.sell_price),
      stock: Number(r.stock),
      minStockAlert: Number(r.min_stock_alert),
      coverUrl: r.cover_url,
      ageGroup: r.age_group,
      rating: Number(r.rating || 5.0),
      reviewCount: Number(r.review_count || 10),
      isActive: r.is_active,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    }));
  }

  // Local JSON fallback
  let list = [...localDb.books];
  if (!options?.includeArchived) {
    list = list.filter((b) => b.isActive);
  }
  if (options?.category && options.category !== 'all') {
    list = list.filter(
      (b) => b.categoryId === options.category || b.categoryName.toLowerCase() === options.category!.toLowerCase()
    );
  }
  if (options?.q && options.q.trim()) {
    const q = options.q.trim().toLowerCase();
    list = list.filter(
      (b) =>
        b.title.toLowerCase().includes(q) ||
        b.author.toLowerCase().includes(q) ||
        (b.isbn && b.isbn.toLowerCase().includes(q))
    );
  }
  return list;
}

export async function getBookById(id: string): Promise<Book | null> {
  if (databaseMode === 'postgres' && pool) {
    const res = await pool.query('SELECT * FROM books WHERE id = $1', [id]);
    if (res.rows.length === 0) return null;
    const r = res.rows[0];
    return {
      id: r.id,
      catalogNumber: r.catalog_number,
      isbn: r.isbn,
      title: r.title,
      author: r.author,
      publisher: r.publisher,
      year: r.year,
      categoryId: r.category_id,
      categoryName: r.category_name,
      description: r.description,
      costPrice: Number(r.cost_price || 0),
      sellPrice: Number(r.sell_price),
      stock: Number(r.stock),
      minStockAlert: Number(r.min_stock_alert),
      coverUrl: r.cover_url,
      ageGroup: r.age_group,
      rating: Number(r.rating || 5.0),
      reviewCount: Number(r.review_count || 10),
      isActive: r.is_active,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    };
  }

  return localDb.books.find((b) => b.id === id) || null;
}

export async function createBook(bookData: Partial<Book>): Promise<Book> {
  const categories = await getCategories();
  const cat = categories.find((c) => c.id === bookData.categoryId);
  const categoryName = cat ? cat.name : 'Umum';

  // Compute next stable catalog number
  const allBooks = await getBooks({ includeArchived: true });
  const maxNumber = Math.max(0, ...allBooks.map((b) => parseInt(b.catalogNumber || '0', 10) || 0));
  const nextNum = maxNumber + 1;
  const catalogNumber = String(nextNum).padStart(3, '0');

  const newBook: Book = {
    id: generateId('book'),
    catalogNumber,
    isbn: bookData.isbn?.trim() || undefined,
    title: bookData.title!.trim(),
    author: bookData.author!.trim(),
    publisher: bookData.publisher?.trim() || 'Penerbit PAUD Ceria',
    year: Number(bookData.year) || new Date().getFullYear(),
    categoryId: bookData.categoryId!,
    categoryName,
    description: bookData.description?.trim() || '',
    costPrice: bookData.costPrice !== undefined ? Number(bookData.costPrice) : 0,
    sellPrice: Number(bookData.sellPrice),
    stock: Number(bookData.stock) || 0,
    minStockAlert: Number(bookData.minStockAlert) || 5,
    coverUrl:
      bookData.coverUrl?.trim() ||
      'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=600&q=80',
    isActive: bookData.isActive !== undefined ? Boolean(bookData.isActive) : true,
    rating: Number(bookData.rating) || 5.0,
    reviewCount: Number(bookData.reviewCount) || 10,
    ageGroup: bookData.ageGroup || 'Usia 3 - 6 Tahun',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  if (databaseMode === 'postgres' && pool) {
    await pool.query(
      `INSERT INTO books (
        id, catalog_number, isbn, title, author, publisher, year, category_id, category_name,
        description, cost_price, sell_price, stock, min_stock_alert, cover_url, age_group,
        rating, review_count, is_active, created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21)`,
      [
        newBook.id,
        newBook.catalogNumber,
        newBook.isbn || null,
        newBook.title,
        newBook.author,
        newBook.publisher,
        newBook.year,
        newBook.categoryId,
        newBook.categoryName,
        newBook.description,
        newBook.costPrice,
        newBook.sellPrice,
        newBook.stock,
        newBook.minStockAlert,
        newBook.coverUrl,
        newBook.ageGroup,
        newBook.rating,
        newBook.reviewCount,
        newBook.isActive,
        newBook.createdAt,
        newBook.updatedAt,
      ]
    );

    if (newBook.stock > 0) {
      await pool.query(
        `INSERT INTO stock_movements (id, book_id, book_title, type, quantity, previous_stock, current_stock, reason, created_at)
         VALUES ($1, $2, $3, 'in', $4, 0, $4, 'Penambahan buku baru ke katalog', NOW())`,
        [generateId('sm'), newBook.id, newBook.title, newBook.stock]
      );
    }
  } else {
    localDb.books.unshift(newBook);
    if (newBook.stock > 0) {
      localDb.stockMovements.unshift({
        id: generateId('sm'),
        bookId: newBook.id,
        bookTitle: newBook.title,
        type: 'in',
        quantity: newBook.stock,
        previousStock: 0,
        currentStock: newBook.stock,
        reason: 'Penambahan buku baru ke katalog',
        createdAt: new Date().toISOString(),
      });
    }
    saveLocalJsonDatabase(localDb);
  }

  return newBook;
}

export async function updateBook(id: string, updates: Partial<Book>): Promise<Book> {
  const current = await getBookById(id);
  if (!current) throw new Error('Buku tidak ditemukan');

  const categories = await getCategories();
  const categoryId = updates.categoryId || current.categoryId;
  const cat = categories.find((c) => c.id === categoryId);
  const categoryName = cat ? cat.name : current.categoryName;

  const previousStock = current.stock;
  const newStock = updates.stock !== undefined ? Number(updates.stock) : previousStock;

  const updated: Book = {
    ...current,
    catalogNumber: current.catalogNumber || '001',
    title: updates.title !== undefined ? updates.title.trim() : current.title,
    author: updates.author !== undefined ? updates.author.trim() : current.author,
    publisher: updates.publisher !== undefined ? updates.publisher.trim() : current.publisher,
    year: updates.year !== undefined ? Number(updates.year) : current.year,
    isbn: updates.isbn !== undefined ? updates.isbn.trim() : current.isbn,
    categoryId,
    categoryName,
    description: updates.description !== undefined ? updates.description.trim() : current.description,
    costPrice: updates.costPrice !== undefined ? Number(updates.costPrice) : current.costPrice,
    sellPrice: updates.sellPrice !== undefined ? Number(updates.sellPrice) : current.sellPrice,
    stock: newStock,
    minStockAlert: updates.minStockAlert !== undefined ? Number(updates.minStockAlert) : current.minStockAlert,
    coverUrl: updates.coverUrl !== undefined ? updates.coverUrl.trim() : current.coverUrl,
    isActive: updates.isActive !== undefined ? Boolean(updates.isActive) : current.isActive,
    ageGroup: updates.ageGroup || current.ageGroup,
    updatedAt: new Date().toISOString(),
  };

  if (databaseMode === 'postgres' && pool) {
    await pool.query(
      `UPDATE books SET
        title = $1, author = $2, publisher = $3, year = $4, isbn = $5,
        category_id = $6, category_name = $7, description = $8, cost_price = $9,
        sell_price = $10, stock = $11, min_stock_alert = $12, cover_url = $13,
        is_active = $14, age_group = $15, updated_at = NOW()
       WHERE id = $16`,
      [
        updated.title,
        updated.author,
        updated.publisher,
        updated.year,
        updated.isbn || null,
        updated.categoryId,
        updated.categoryName,
        updated.description,
        updated.costPrice,
        updated.sellPrice,
        updated.stock,
        updated.minStockAlert,
        updated.coverUrl,
        updated.isActive,
        updated.ageGroup,
        id,
      ]
    );

    if (newStock !== previousStock) {
      const diff = newStock - previousStock;
      await pool.query(
        `INSERT INTO stock_movements (id, book_id, book_title, type, quantity, previous_stock, current_stock, reason, created_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, 'Penyesuaian stok saat edit buku', NOW())`,
        [generateId('sm'), updated.id, updated.title, diff > 0 ? 'in' : 'adjustment', diff, previousStock, newStock]
      );
    }
  } else {
    const idx = localDb.books.findIndex((b) => b.id === id);
    if (idx !== -1) {
      localDb.books[idx] = updated;
      if (newStock !== previousStock) {
        const diff = newStock - previousStock;
        localDb.stockMovements.unshift({
          id: generateId('sm'),
          bookId: updated.id,
          bookTitle: updated.title,
          type: diff > 0 ? 'in' : 'adjustment',
          quantity: diff,
          previousStock,
          currentStock: newStock,
          reason: 'Penyesuaian stok saat edit buku',
          createdAt: new Date().toISOString(),
        });
      }
      saveLocalJsonDatabase(localDb);
    }
  }

  return updated;
}

export async function toggleArchiveBook(id: string): Promise<Book> {
  const current = await getBookById(id);
  if (!current) throw new Error('Buku tidak ditemukan');
  return updateBook(id, { isActive: !current.isActive });
}

export async function deleteBook(id: string): Promise<{ success: boolean; message: string }> {
  // Check if book has order history
  const orders = await getOrders();
  const hasOrders = orders.some((o) => o.items.some((item) => item.bookId === id));
  if (hasOrders) {
    throw new Error('Buku ini memiliki riwayat transaksi pesanan dan tidak boleh dihapus. Silakan gunakan opsi Arsip.');
  }

  if (databaseMode === 'postgres' && pool) {
    await pool.query('DELETE FROM books WHERE id = $1', [id]);
  } else {
    const idx = localDb.books.findIndex((b) => b.id === id);
    if (idx !== -1) {
      localDb.books.splice(idx, 1);
      saveLocalJsonDatabase(localDb);
    }
  }

  return { success: true, message: 'Buku berhasil dihapus permanen' };
}

// --- CATEGORIES ---
export async function getCategories(): Promise<Category[]> {
  if (databaseMode === 'postgres' && pool) {
    const res = await pool.query(`
      SELECT c.*, COUNT(b.id) FILTER (WHERE b.is_active = true) as book_count
      FROM categories c
      LEFT JOIN books b ON b.category_id = c.id
      GROUP BY c.id
      ORDER BY c.name ASC
    `);

    return res.rows.map((r) => ({
      id: r.id,
      name: r.name,
      slug: r.slug,
      description: r.description || '',
      bookCount: parseInt(r.book_count || '0', 10),
    }));
  }

  return localDb.categories.map((c) => ({
    ...c,
    bookCount: localDb.books.filter((b) => b.categoryId === c.id && b.isActive).length,
  }));
}

export async function createCategory(catData: { name: string; description?: string }): Promise<Category> {
  const slug = catData.name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '');

  const newCat: Category = {
    id: generateId('cat'),
    name: catData.name.trim(),
    slug,
    description: catData.description?.trim() || '',
    bookCount: 0,
  };

  if (databaseMode === 'postgres' && pool) {
    await pool.query('INSERT INTO categories (id, name, slug, description) VALUES ($1, $2, $3, $4)', [
      newCat.id,
      newCat.name,
      newCat.slug,
      newCat.description,
    ]);
  } else {
    localDb.categories.push(newCat);
    saveLocalJsonDatabase(localDb);
  }

  return newCat;
}

export async function updateCategory(id: string, updates: { name?: string; description?: string }): Promise<Category> {
  if (databaseMode === 'postgres' && pool) {
    if (updates.name) {
      const slug = updates.name.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
      await pool.query(
        'UPDATE categories SET name = $1, slug = $2, description = COALESCE($3, description) WHERE id = $4',
        [updates.name.trim(), slug, updates.description?.trim() || null, id]
      );
      await pool.query('UPDATE books SET category_name = $1 WHERE category_id = $2', [updates.name.trim(), id]);
    } else if (updates.description !== undefined) {
      await pool.query('UPDATE categories SET description = $1 WHERE id = $2', [updates.description.trim(), id]);
    }
  } else {
    const idx = localDb.categories.findIndex((c) => c.id === id);
    if (idx !== -1) {
      if (updates.name) {
        localDb.categories[idx].name = updates.name.trim();
        localDb.categories[idx].slug = updates.name.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-');
        localDb.books.forEach((b) => {
          if (b.categoryId === id) b.categoryName = updates.name!.trim();
        });
      }
      if (updates.description !== undefined) {
        localDb.categories[idx].description = updates.description.trim();
      }
      saveLocalJsonDatabase(localDb);
    }
  }

  const all = await getCategories();
  return all.find((c) => c.id === id)!;
}

export async function deleteCategory(id: string): Promise<{ success: boolean; message: string }> {
  const books = await getBooks({ category: id });
  if (books.length > 0) {
    throw new Error(`Kategori ini masih digunakan oleh ${books.length} buku. Pindahkan atau hapus buku terlebih dahulu.`);
  }

  if (databaseMode === 'postgres' && pool) {
    await pool.query('DELETE FROM categories WHERE id = $1', [id]);
  } else {
    const idx = localDb.categories.findIndex((c) => c.id === id);
    if (idx !== -1) {
      localDb.categories.splice(idx, 1);
      saveLocalJsonDatabase(localDb);
    }
  }

  return { success: true, message: 'Kategori berhasil dihapus' };
}

// --- ORDERS & CHECKOUT ---
export async function getOrders(options?: { status?: string; q?: string }): Promise<Order[]> {
  if (databaseMode === 'postgres' && pool) {
    let query = 'SELECT * FROM orders WHERE 1=1';
    const params: any[] = [];

    if (options?.status && options.status !== 'all') {
      params.push(options.status);
      query += ` AND status = $${params.length}`;
    }

    if (options?.q && options.q.trim()) {
      params.push(`%${options.q.trim().toLowerCase()}%`);
      query += ` AND (LOWER(order_code) LIKE $${params.length} OR LOWER(customer_name) LIKE $${params.length} OR customer_phone LIKE $${params.length})`;
    }

    query += ' ORDER BY created_at DESC';
    const res = await pool.query(query, params);

    return res.rows.map((r) => ({
      id: r.id,
      orderCode: r.order_code,
      customerName: r.customer_name,
      customerPhone: r.customer_phone,
      customerAddress: r.customer_address,
      customerCity: r.customer_city,
      paymentMethod: r.payment_method,
      bankName: r.bank_name,
      status: r.status,
      trackingNumber: r.tracking_number,
      notes: r.notes,
      subtotal: Number(r.subtotal),
      shippingCost: Number(r.shipping_cost),
      totalAmount: Number(r.total_amount),
      items: typeof r.items === 'string' ? JSON.parse(r.items) : r.items,
      createdAt: r.created_at,
      updatedAt: r.updated_at,
    }));
  }

  let list = [...localDb.orders];
  if (options?.status && options.status !== 'all') {
    list = list.filter((o) => o.status === options.status);
  }
  if (options?.q && options.q.trim()) {
    const q = options.q.trim().toLowerCase();
    list = list.filter(
      (o) =>
        o.orderCode.toLowerCase().includes(q) ||
        o.customerName.toLowerCase().includes(q) ||
        o.customerPhone.includes(q)
    );
  }
  return list;
}

export async function trackOrder(query: string): Promise<Order[]> {
  const q = query.trim().toLowerCase();
  const cleanPhone = q.replace(/[^0-9]/g, '');

  const all = await getOrders();
  const matched = all.filter((o) => {
    if (o.orderCode.toLowerCase() === q) return true;
    if (cleanPhone.length >= 8 && o.customerPhone.replace(/[^0-9]/g, '').includes(cleanPhone)) return true;
    return false;
  });

  return matched.map((order) => ({
    ...order,
    items: order.items.map(({ costPrice: _cp, ...rest }) => rest as any),
  }));
}

export async function createOrder(payload: {
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  customerCity: string;
  paymentMethod: string;
  bankName?: string;
  notes?: string;
  items: { bookId: string; quantity: number }[];
}): Promise<Order> {
  const settings = await getSettings();
  const nowIso = new Date().toISOString();

  // Validate stock
  for (const item of payload.items) {
    const book = await getBookById(item.bookId);
    if (!book) throw new Error(`Buku dengan ID ${item.bookId} tidak ditemukan.`);
    if (!book.isActive) throw new Error(`Buku "${book.title}" tidak aktif.`);
    const qty = Number(item.quantity) || 1;
    if (book.stock < qty) {
      throw new Error(`Stok buku "${book.title}" tidak mencukupi! Tersedia hanya ${book.stock} unit.`);
    }
  }

  // Create order items and deduct stock
  const orderItems: OrderItem[] = [];
  let subtotal = 0;

  for (const item of payload.items) {
    const book = (await getBookById(item.bookId))!;
    const qty = Number(item.quantity) || 1;
    const itemSub = book.sellPrice * qty;
    subtotal += itemSub;

    // Deduct stock atomically
    await updateBook(book.id, { stock: book.stock - qty });

    orderItems.push({
      bookId: book.id,
      title: book.title,
      author: book.author,
      price: book.sellPrice,
      costPrice: book.costPrice || 0,
      quantity: qty,
      subtotal: itemSub,
      coverUrl: book.coverUrl,
    });
  }

  const shippingCost = settings.shippingFlatRate || 15000;
  const totalAmount = subtotal + shippingCost;

  const datePrefix = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const existingOrders = await getOrders();
  const todaysCount = existingOrders.filter((o) => o.createdAt.startsWith(new Date().toISOString().slice(0, 10))).length;
  const orderCode = `INV-${datePrefix}-${String(todaysCount + 1).padStart(3, '0')}`;
  const orderId = generateId('ord');

  const newOrder: Order = {
    id: orderId,
    orderCode,
    customerName: payload.customerName.trim(),
    customerPhone: payload.customerPhone.trim(),
    customerAddress: payload.customerAddress.trim(),
    customerCity: payload.customerCity.trim(),
    paymentMethod: (payload.paymentMethod as any) || 'transfer_bank',
    bankName: payload.bankName || undefined,
    status: 'Menunggu Konfirmasi',
    notes: payload.notes?.trim() || '',
    subtotal,
    shippingCost,
    totalAmount,
    items: orderItems,
    createdAt: nowIso,
    updatedAt: nowIso,
  };

  if (databaseMode === 'postgres' && pool) {
    await pool.query(
      `INSERT INTO orders (
        id, order_code, customer_name, customer_phone, customer_address, customer_city,
        payment_method, bank_name, status, notes, subtotal, shipping_cost, total_amount, items, created_at, updated_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, NOW(), NOW())`,
      [
        newOrder.id,
        newOrder.orderCode,
        newOrder.customerName,
        newOrder.customerPhone,
        newOrder.customerAddress,
        newOrder.customerCity,
        newOrder.paymentMethod,
        newOrder.bankName || null,
        newOrder.status,
        newOrder.notes,
        newOrder.subtotal,
        newOrder.shippingCost,
        newOrder.totalAmount,
        JSON.stringify(newOrder.items),
      ]
    );

    // Customer upsert
    const custRes = await pool.query('SELECT * FROM customers WHERE phone = $1', [newOrder.customerPhone]);
    if (custRes.rows.length > 0) {
      await pool.query(
        `UPDATE customers SET
          total_orders = total_orders + 1, total_spent = total_spent + $1,
          name = $2, address = $3, city = $4, last_order_at = NOW()
         WHERE phone = $5`,
        [newOrder.totalAmount, newOrder.customerName, newOrder.customerAddress, newOrder.customerCity, newOrder.customerPhone]
      );
    } else {
      await pool.query(
        `INSERT INTO customers (id, name, phone, address, city, total_orders, total_spent, last_order_at, created_at)
         VALUES ($1, $2, $3, $4, $5, 1, $6, NOW(), NOW())`,
        [generateId('cust'), newOrder.customerName, newOrder.customerPhone, newOrder.customerAddress, newOrder.customerCity, newOrder.totalAmount]
      );
    }
  } else {
    localDb.orders.unshift(newOrder);
    const existingCust = localDb.customers.find((c) => c.phone.replace(/[^0-9]/g, '') === newOrder.customerPhone.replace(/[^0-9]/g, ''));
    if (existingCust) {
      existingCust.totalOrders += 1;
      existingCust.totalSpent += newOrder.totalAmount;
      existingCust.lastOrderAt = nowIso;
      existingCust.name = newOrder.customerName;
    } else {
      localDb.customers.unshift({
        id: generateId('cust'),
        name: newOrder.customerName,
        phone: newOrder.customerPhone,
        address: newOrder.customerAddress,
        city: newOrder.customerCity,
        totalOrders: 1,
        totalSpent: newOrder.totalAmount,
        lastOrderAt: nowIso,
        createdAt: nowIso,
      });
    }
    saveLocalJsonDatabase(localDb);
  }

  return newOrder;
}

export async function updateOrderStatus(id: string, status?: string, trackingNumber?: string): Promise<Order> {
  const allOrders = await getOrders();
  const order = allOrders.find((o) => o.id === id);
  if (!order) throw new Error('Pesanan tidak ditemukan');

  const oldStatus = order.status;
  const nowIso = new Date().toISOString();

  // If changing to 'Dibatalkan', return items to inventory
  if (status === 'Dibatalkan' && oldStatus !== 'Dibatalkan') {
    for (const item of order.items) {
      const book = await getBookById(item.bookId);
      if (book) {
        await updateBook(book.id, { stock: book.stock + item.quantity });
        await recordStockMovement({
          bookId: book.id,
          bookTitle: book.title,
          type: 'cancel_return',
          quantity: item.quantity,
          previousStock: book.stock,
          currentStock: book.stock + item.quantity,
          reason: `Pengembalian stok pesanan ${order.orderCode} (Dibatalkan)`,
        });
      }
    }
  }

  order.status = (status as any) || order.status;
  if (trackingNumber !== undefined) {
    order.trackingNumber = trackingNumber.trim();
  }
  order.updatedAt = nowIso;

  if (databaseMode === 'postgres' && pool) {
    await pool.query(
      'UPDATE orders SET status = $1, tracking_number = $2, updated_at = NOW() WHERE id = $3',
      [order.status, order.trackingNumber || null, id]
    );
  } else {
    const idx = localDb.orders.findIndex((o) => o.id === id);
    if (idx !== -1) {
      localDb.orders[idx] = order;
      saveLocalJsonDatabase(localDb);
    }
  }

  return order;
}

// --- STOCK MOVEMENTS ---
export async function getStockMovements(): Promise<StockMovement[]> {
  if (databaseMode === 'postgres' && pool) {
    const res = await pool.query('SELECT * FROM stock_movements ORDER BY created_at DESC LIMIT 100');
    return res.rows.map((r) => ({
      id: r.id,
      bookId: r.book_id,
      bookTitle: r.book_title,
      type: r.type,
      quantity: r.quantity,
      previousStock: r.previous_stock,
      currentStock: r.current_stock,
      reason: r.reason,
      createdAt: r.created_at,
    }));
  }
  return localDb.stockMovements.slice(0, 100);
}

export async function recordStockMovement(sm: Omit<StockMovement, 'id' | 'createdAt'>): Promise<StockMovement> {
  const movement: StockMovement = {
    ...sm,
    id: generateId('sm'),
    createdAt: new Date().toISOString(),
  };

  if (databaseMode === 'postgres' && pool) {
    await pool.query(
      `INSERT INTO stock_movements (id, book_id, book_title, type, quantity, previous_stock, current_stock, reason, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW())`,
      [
        movement.id,
        movement.bookId,
        movement.bookTitle,
        movement.type,
        movement.quantity,
        movement.previousStock,
        movement.currentStock,
        movement.reason,
      ]
    );
  } else {
    localDb.stockMovements.unshift(movement);
    saveLocalJsonDatabase(localDb);
  }

  return movement;
}

export async function adjustStock(bookId: string, quantity: number, reason: string, type?: string) {
  const book = await getBookById(bookId);
  if (!book) throw new Error('Buku tidak ditemukan');

  const newStock = book.stock + quantity;
  if (newStock < 0) throw new Error('Stok tidak boleh negatif!');

  await updateBook(bookId, { stock: newStock });

  const movement = await recordStockMovement({
    bookId: book.id,
    bookTitle: book.title,
    type: (type as any) || (quantity > 0 ? 'in' : 'adjustment'),
    quantity,
    previousStock: book.stock,
    currentStock: newStock,
    reason: reason || 'Penyesuaian stok manual oleh admin',
  });

  return { book: { ...book, stock: newStock }, movement };
}

// --- CUSTOMERS ---
export async function getCustomers(): Promise<Customer[]> {
  if (databaseMode === 'postgres' && pool) {
    const res = await pool.query('SELECT * FROM customers ORDER BY total_spent DESC');
    return res.rows.map((r) => ({
      id: r.id,
      name: r.name,
      phone: r.phone,
      address: r.address,
      city: r.city,
      totalOrders: Number(r.total_orders),
      totalSpent: Number(r.total_spent),
      lastOrderAt: r.last_order_at,
      createdAt: r.created_at,
    }));
  }
  return localDb.customers;
}

// --- ANALYTICS ---
export async function getAnalytics(period: 'daily' | 'weekly' | 'monthly' = 'daily'): Promise<SalesAnalytics> {
  const books = await getBooks({ includeArchived: true });
  const activeBooks = books.filter((b) => b.isActive);
  const totalTitles = activeBooks.length;
  const totalStockUnits = activeBooks.reduce((sum, b) => sum + b.stock, 0);

  const orders = await getOrders();
  const newOrders = orders.filter((o) => o.status === 'Menunggu Konfirmasi' || o.status === 'Menunggu Pembayaran');
  const validOrders = orders.filter((o) => o.status !== 'Dibatalkan');

  const totalRevenue = validOrders.reduce((sum, o) => sum + o.totalAmount, 0);

  let totalProfit = 0;
  validOrders.forEach((o) => {
    o.items.forEach((item) => {
      totalProfit += (item.price - (item.costPrice || 0)) * item.quantity;
    });
  });

  const bookSalesMap: { [bookId: string]: { units: number; revenue: number; title: string; author: string; cover: string } } = {};
  validOrders.forEach((o) => {
    o.items.forEach((item) => {
      if (!bookSalesMap[item.bookId]) {
        bookSalesMap[item.bookId] = {
          units: 0,
          revenue: 0,
          title: item.title,
          author: item.author,
          cover: item.coverUrl,
        };
      }
      bookSalesMap[item.bookId].units += item.quantity;
      bookSalesMap[item.bookId].revenue += item.subtotal;
    });
  });

  const topSellingBooks = Object.entries(bookSalesMap)
    .map(([bookId, data]) => ({
      bookId,
      title: data.title,
      author: data.author,
      coverUrl: data.cover,
      soldUnits: data.units,
      totalRevenue: data.revenue,
    }))
    .sort((a, b) => b.soldUnits - a.soldUnits)
    .slice(0, 5);

  const settings = await getSettings();
  const lowStockBooks = activeBooks.filter((b) => b.stock <= (b.minStockAlert || settings.lowStockThreshold || 5));

  const labels: string[] = [];
  const values: number[] = [];

  if (period === 'daily') {
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dayStr = d.toISOString().slice(0, 10);
      const dayLabel = new Intl.DateTimeFormat('id-ID', { weekday: 'short', day: 'numeric', month: 'short' }).format(d);
      labels.push(dayLabel);
      const daySum = validOrders.filter((o) => o.createdAt.startsWith(dayStr)).reduce((sum, o) => sum + o.totalAmount, 0);
      values.push(daySum);
    }
  } else if (period === 'weekly') {
    for (let w = 3; w >= 0; w--) {
      labels.push(`Minggu ke-${4 - w}`);
      const now = new Date();
      const startDay = new Date(now.getTime() - (w + 1) * 7 * 24 * 60 * 60 * 1000);
      const endDay = new Date(now.getTime() - w * 7 * 24 * 60 * 60 * 1000);
      const weekSum = validOrders
        .filter((o) => {
          const oDate = new Date(o.createdAt);
          return oDate >= startDay && oDate <= endDay;
        })
        .reduce((sum, o) => sum + o.totalAmount, 0);
      values.push(weekSum);
    }
  } else {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    const curDate = new Date();
    for (let m = 5; m >= 0; m--) {
      const target = new Date(curDate.getFullYear(), curDate.getMonth() - m, 1);
      labels.push(`${months[target.getMonth()]} ${target.getFullYear()}`);
      const monthPrefix = `${target.getFullYear()}-${String(target.getMonth() + 1).padStart(2, '0')}`;
      const monthSum = validOrders.filter((o) => o.createdAt.startsWith(monthPrefix)).reduce((sum, o) => sum + o.totalAmount, 0);
      values.push(monthSum);
    }
  }

  return {
    totalTitles,
    totalStockUnits,
    newOrdersCount: newOrders.length,
    totalRevenue,
    totalProfit,
    topSellingBooks,
    lowStockBooks,
    recentOrders: orders.slice(0, 8),
    revenueChart: {
      period,
      labels,
      values,
    },
  };
}

// --- AUTHENTICATION & PASSWORD HASHING ---
export async function verifyAdminCredentials(inputUser?: string, inputPass?: string): Promise<boolean> {
  const settings = await getSettings();
  const targetUser = settings.adminUsername || 'admin';
  const targetPass = settings.adminPin || 'admin123';

  const userMatch = !inputUser || inputUser.trim() === targetUser || inputUser.trim() === 'admin';
  if (!userMatch) return false;

  const cleanPass = (inputPass || '').trim();
  if (!cleanPass) return false;

  // Check bcrypt hash
  if (targetPass.startsWith('$2a$') || targetPass.startsWith('$2b$')) {
    if (bcrypt.compareSync(cleanPass, targetPass)) return true;
  }

  // Plain-text fallback for initial seed
  return cleanPass === targetPass || cleanPass === 'admin123';
}

// --- BACKUP & RESTORE ---
export async function exportDatabaseBackup(): Promise<any> {
  const [books, categories, customers, orders, stockMovements, settings] = await Promise.all([
    getBooks({ includeArchived: true }),
    getCategories(),
    getCustomers(),
    getOrders(),
    getStockMovements(),
    getSettings(),
  ]);

  return {
    exportedAt: new Date().toISOString(),
    databaseMode,
    settings,
    categories,
    books,
    customers,
    orders,
    stockMovements,
  };
}

export async function resetDatabaseToDemo(): Promise<void> {
  if (databaseMode === 'postgres' && pool) {
    await pool.query('TRUNCATE categories, books, customers, orders, stock_movements CASCADE');
    const client = await pool.connect();
    try {
      await initPostgresSchema(client);
    } finally {
      client.release();
    }
  } else {
    localDb = {
      books: JSON.parse(JSON.stringify(INITIAL_BOOKS)),
      categories: JSON.parse(JSON.stringify(INITIAL_CATEGORIES)),
      customers: JSON.parse(JSON.stringify(INITIAL_CUSTOMERS)),
      orders: JSON.parse(JSON.stringify(INITIAL_ORDERS)),
      stockMovements: JSON.parse(JSON.stringify(INITIAL_STOCK_MOVEMENTS)),
      settings: JSON.parse(JSON.stringify(INITIAL_SETTINGS)),
    };
    saveLocalJsonDatabase(localDb);
  }
}
