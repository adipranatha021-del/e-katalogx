import {
  Book,
  Category,
  Order,
  Customer,
  StockMovement,
  AppSettings,
  SalesAnalytics,
} from '../types.ts';

const API_BASE = '/api';

function getAuthHeaders(): Record<string, string> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  try {
    const token = localStorage.getItem('ekatalog_admin_token');
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
      headers['x-admin-token'] = token;
    }
  } catch {
    // Ignore localStorage access issues in restricted contexts
  }
  return headers;
}

async function handleResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let errorMsg = 'Terjadi kesalahan sistem';
    try {
      const data = await res.json();
      if (data.error) errorMsg = data.error;
    } catch {
      errorMsg = res.statusText || errorMsg;
    }
    throw new Error(errorMsg);
  }
  return res.json();
}

export const api = {
  // Public config (safe for any visitor)
  getConfig: async (): Promise<Omit<AppSettings, 'adminPin'>> => {
    const res = await fetch(`${API_BASE}/config`);
    return handleResponse(res);
  },

  // Books
  getBooks: async (params?: { category?: string; q?: string; include_archived?: boolean }): Promise<Book[]> => {
    const searchParams = new URLSearchParams();
    if (params?.category) searchParams.set('category', params.category);
    if (params?.q) searchParams.set('q', params.q);
    if (params?.include_archived) searchParams.set('include_archived', 'true');
    const res = await fetch(`${API_BASE}/books?${searchParams.toString()}`, {
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },

  getBookById: async (id: string): Promise<Book> => {
    const res = await fetch(`${API_BASE}/books/${id}`);
    return handleResponse(res);
  },

  createBook: async (bookData: Partial<Book>): Promise<Book> => {
    const res = await fetch(`${API_BASE}/books`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(bookData),
    });
    return handleResponse(res);
  },

  updateBook: async (id: string, bookData: Partial<Book>): Promise<Book> => {
    const res = await fetch(`${API_BASE}/books/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(bookData),
    });
    return handleResponse(res);
  },

  toggleArchiveBook: async (id: string): Promise<Book> => {
    const res = await fetch(`${API_BASE}/books/${id}/archive`, {
      method: 'PATCH',
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },

  deleteBook: async (id: string): Promise<{ success: boolean; message: string }> => {
    const res = await fetch(`${API_BASE}/books/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },

  // Categories
  getCategories: async (): Promise<Category[]> => {
    const res = await fetch(`${API_BASE}/categories`);
    return handleResponse(res);
  },

  createCategory: async (categoryData: { name: string; description?: string }): Promise<Category> => {
    const res = await fetch(`${API_BASE}/categories`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(categoryData),
    });
    return handleResponse(res);
  },

  updateCategory: async (id: string, categoryData: { name: string; description?: string }): Promise<Category> => {
    const res = await fetch(`${API_BASE}/categories/${id}`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(categoryData),
    });
    return handleResponse(res);
  },

  deleteCategory: async (id: string): Promise<{ success: boolean; message: string }> => {
    const res = await fetch(`${API_BASE}/categories/${id}`, {
      method: 'DELETE',
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },

  // Orders
  getOrders: async (params?: { status?: string; q?: string }): Promise<Order[]> => {
    const searchParams = new URLSearchParams();
    if (params?.status) searchParams.set('status', params.status);
    if (params?.q) searchParams.set('q', params.q);
    const res = await fetch(`${API_BASE}/orders?${searchParams.toString()}`, {
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },

  trackOrder: async (query: string): Promise<Order[]> => {
    const res = await fetch(`${API_BASE}/orders/track?q=${encodeURIComponent(query)}`);
    return handleResponse(res);
  },

  createOrder: async (orderPayload: {
    customerName: string;
    customerPhone: string;
    customerAddress: string;
    customerCity: string;
    paymentMethod: string;
    bankName?: string;
    notes?: string;
    items: { bookId: string; quantity: number }[];
  }): Promise<Order> => {
    const res = await fetch(`${API_BASE}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(orderPayload),
    });
    return handleResponse(res);
  },

  updateOrderStatus: async (
    id: string,
    payload: { status?: string; trackingNumber?: string }
  ): Promise<Order> => {
    const res = await fetch(`${API_BASE}/orders/${id}/status`, {
      method: 'PATCH',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload),
    });
    return handleResponse(res);
  },

  // Stock
  getStockMovements: async (): Promise<StockMovement[]> => {
    const res = await fetch(`${API_BASE}/stock-movements`, {
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },

  adjustStock: async (payload: {
    bookId: string;
    quantity: number;
    reason: string;
    type?: string;
  }): Promise<{ book: Book; movement: StockMovement }> => {
    const res = await fetch(`${API_BASE}/stock-adjustments`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(payload),
    });
    return handleResponse(res);
  },

  // Customers (Admin only)
  getCustomers: async (): Promise<Customer[]> => {
    const res = await fetch(`${API_BASE}/customers`, {
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },

  // Analytics (Admin only)
  getAnalytics: async (period: 'daily' | 'weekly' | 'monthly' = 'daily'): Promise<SalesAnalytics> => {
    const res = await fetch(`${API_BASE}/analytics?period=${period}`, {
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },

  // Settings
  getSettings: async (): Promise<AppSettings> => {
    const res = await fetch(`${API_BASE}/settings`, {
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },

  updateSettings: async (settings: Partial<AppSettings>): Promise<AppSettings> => {
    const res = await fetch(`${API_BASE}/settings`, {
      method: 'PUT',
      headers: getAuthHeaders(),
      body: JSON.stringify(settings),
    });
    return handleResponse(res);
  },

  // Admin Auth
  loginAdmin: async (credentials: string | { username?: string; password?: string; pin?: string }): Promise<{ success: boolean; token: string }> => {
    const payload = typeof credentials === 'string' ? { pin: credentials } : credentials;
    const res = await fetch(`${API_BASE}/admin/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    return handleResponse(res);
  },

  // Backup & Restore
  getBackupDownloadUrl: (): string => `${API_BASE}/backup`,

  restoreBackup: async (backupData: any): Promise<{ success: boolean; message: string }> => {
    const res = await fetch(`${API_BASE}/backup/restore`, {
      method: 'POST',
      headers: getAuthHeaders(),
      body: JSON.stringify(backupData),
    });
    return handleResponse(res);
  },

  resetDemoData: async (): Promise<{ success: boolean; message: string }> => {
    const res = await fetch(`${API_BASE}/backup/reset-demo`, {
      method: 'POST',
      headers: getAuthHeaders(),
    });
    return handleResponse(res);
  },
};
