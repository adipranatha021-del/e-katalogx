import React, { useState, useRef } from 'react';
import {
  Database,
  Download,
  Upload,
  RotateCcw,
  AlertTriangle,
  CheckCircle,
  Loader2,
  ShieldCheck,
} from 'lucide-react';
import { api } from '../../services/api.ts';

interface AdminBackupViewProps {
  onRefreshAll: () => void;
}

export const AdminBackupView: React.FC<AdminBackupViewProps> = ({ onRefreshAll }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [restoreDataPending, setRestoreDataPending] = useState<any | null>(null);
  const [showResetConfirmModal, setShowResetConfirmModal] = useState(false);

  // 1. Download JSON Backup
  const handleDownloadBackup = () => {
    const a = document.createElement('a');
    a.href = api.getBackupDownloadUrl();
    a.download = `ekatalog-paud-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    setFeedbackMsg({
      type: 'success',
      text: 'File cadangan JSON database berhasil dibuat dan diunduh.',
    });
    setTimeout(() => setFeedbackMsg(null), 4000);
  };

  // 2. Restore JSON Backup
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        setRestoreDataPending(json);
      } catch (err: any) {
        setFeedbackMsg({
          type: 'error',
          text: err.message || 'File cadangan rusak atau format tidak sesuai skema JSON.',
        });
        setTimeout(() => setFeedbackMsg(null), 4000);
      } finally {
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
  };

  const handleConfirmRestore = async () => {
    if (!restoreDataPending) return;
    setIsProcessing(true);
    try {
      const res = await api.restoreBackup(restoreDataPending);
      setFeedbackMsg({
        type: 'success',
        text: res.message || 'Database berhasil dipulihkan dari cadangan!',
      });
      setRestoreDataPending(null);
      onRefreshAll();
    } catch (err: any) {
      setFeedbackMsg({
        type: 'error',
        text: err.message || 'Gagal memulihkan database dari file cadangan.',
      });
    } finally {
      setIsProcessing(false);
      setTimeout(() => setFeedbackMsg(null), 4000);
    }
  };

  // 3. Reset to Demo Seed Data
  const handleConfirmResetDemo = async () => {
    setIsProcessing(true);
    setShowResetConfirmModal(false);
    try {
      const res = await api.resetDemoData();
      setFeedbackMsg({
        type: 'success',
        text: res.message || 'Data contoh buku PAUD berhasil dipasang kembali!',
      });
      onRefreshAll();
    } catch (err: any) {
      setFeedbackMsg({
        type: 'error',
        text: err.message || 'Gagal mereset data demo.',
      });
    } finally {
      setIsProcessing(false);
      setTimeout(() => setFeedbackMsg(null), 4000);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Feedback Banner */}
      {feedbackMsg && (
        <div
          className={`p-4 rounded-2xl text-xs sm:text-sm font-semibold border flex items-center gap-2 animate-fadeIn ${
            feedbackMsg.type === 'success'
              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
              : 'bg-rose-50 text-rose-800 border-rose-200'
          }`}
        >
          {feedbackMsg.type === 'success' ? (
            <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
          ) : (
            <AlertTriangle className="w-5 h-5 text-rose-500 shrink-0" />
          )}
          <span>{feedbackMsg.text}</span>
        </div>
      )}

      {/* Header */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
          <Database className="w-5 h-5 text-blue-600" />
          <h3 className="text-base font-extrabold text-slate-900">
            Cadangan & Pemulihan Database (Backup & Restore)
          </h3>
        </div>
        <p className="text-xs text-slate-500 mt-2 leading-relaxed">
          Amankan seluruh data katalog buku, riwayat pesanan pelanggan, catatan mutasi stok, serta preferensi toko. Anda dapat mengunduh salinan berkala dan memulihkannya kapan saja.
        </p>
      </div>

      {/* Action Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        {/* Card 1: Download JSON Backup */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4">
              <Download className="w-6 h-6" />
            </div>
            <h4 className="font-extrabold text-base text-slate-900 mb-1">
              Unduh Cadangan Database Lengkap
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed mb-6">
              Mengunduh seluruh file <code>db.json</code> (katalog buku, kategori, pelanggan, pesanan, audit log stok, dan pengaturan).
            </p>
          </div>

          <button
            onClick={handleDownloadBackup}
            disabled={isProcessing}
            className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-blue-600/20 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Unduh Cadangan Lengkap (.JSON)</span>
          </button>
        </div>

        {/* Card 2: Restore JSON Backup */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mb-4">
              <Upload className="w-6 h-6" />
            </div>
            <h4 className="font-extrabold text-base text-slate-900 mb-1">
              Pulihkan Database dari File Cadangan
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed mb-6">
              Pilih file JSON hasil backup sebelumnya untuk memulihkan seluruh katalog dan data transaksi.
            </p>
          </div>

          <div>
            <input
              type="file"
              ref={fileInputRef}
              accept=".json"
              onChange={handleFileChange}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              disabled={isProcessing}
              className="w-full py-3 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Memproses File...</span>
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4" />
                  <span>Pilih File Backup (.JSON)</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Card 3: Reset to Clean Demo Data */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <RotateCcw className="w-4 h-4 text-rose-500" />
            <h4 className="font-extrabold text-sm text-slate-900">
              Reset ke Data Sampel Demo
            </h4>
          </div>
          <p className="text-xs text-slate-500 max-w-xl">
            Kembalikan seluruh database ke setelan awal pabrik yang berisi 10 buku original Indonesia, kategori sastra & teknologi, dan contoh pesanan masuk.
          </p>
        </div>

        <button
          onClick={() => setShowResetConfirmModal(true)}
          disabled={isProcessing}
          className="px-4 py-2.5 rounded-xl border border-rose-300 text-rose-700 hover:bg-rose-50 font-bold text-xs shrink-0 transition-colors"
        >
          Reset ke Data Awal Demo
        </button>
      </div>

      {/* Card: Download Project Source Code ZIP for GitHub */}
      <div className="bg-gradient-to-r from-slate-900 to-blue-950 text-white rounded-2xl p-6 border border-slate-800 shadow-md flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <Download className="w-5 h-5 text-emerald-400" />
            <h4 className="font-extrabold text-base text-white">
              Unduh Source Code Proyek (.ZIP untuk GitHub)
            </h4>
          </div>
          <p className="text-xs text-slate-300 max-w-xl leading-relaxed">
            Unduh seluruh berkas proyek lengkap (React, Express, PostgreSQL adapter, <code>render.yaml</code>, dan <code>README.md</code>) yang siap di-upload ke GitHub dan dideploy di Render.
          </p>
        </div>

        <a
          href="/download-zip"
          download="ekatalog-buku-github.zip"
          className="px-5 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs flex items-center gap-2 shadow-lg shadow-emerald-500/25 transition-all shrink-0 cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>Unduh ekatalog-buku-github.zip</span>
        </a>
      </div>

      {/* Safety Notice */}
      <div className="p-4 rounded-2xl bg-blue-50/60 border border-blue-200 flex items-start gap-3 text-xs text-blue-900">
        <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
        <div>
          <p className="font-bold">Keamanan Data Terjamin</p>
          <p className="text-[11px] text-blue-800 mt-0.5 leading-relaxed">
            Database server secara otomatis menyimpan perubahan ke disk penyimpanan secara atomik setiap kali transaksi pesanan berhasil dibuat atau diedit oleh admin. Data tetap tersimpan setelah browser ditutup maupun komputer di-restart.
          </p>
        </div>
      </div>

      {/* Modal 1: Konfirmasi Restore Backup */}
      {restoreDataPending && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="relative bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-200 p-6 animate-scaleUp">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <h3 className="text-lg font-extrabold text-slate-900">
              Konfirmasi Pemulihan Database?
            </h3>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Seluruh data saat ini (buku, pesanan, kategori, dan pengaturan) akan digantikan secara penuh oleh data dari file cadangan yang Anda pilih.
            </p>

            <div className="mt-6 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setRestoreDataPending(null)}
                className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-100"
              >
                Batal
              </button>

              <button
                type="button"
                onClick={handleConfirmRestore}
                disabled={isProcessing}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-blue-600/30 active:scale-95 disabled:opacity-50"
              >
                {isProcessing ? 'Memulihkan...' : 'Ya, Pulihkan Sekarang'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal 2: Konfirmasi Reset Demo */}
      {showResetConfirmModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="relative bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-200 p-6 animate-scaleUp">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mb-4">
              <RotateCcw className="w-6 h-6" />
            </div>

            <h3 className="text-lg font-extrabold text-slate-900">
              Reset ke Data Sampel Demo?
            </h3>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Apakah Anda yakin ingin mengatur ulang data kembali ke sampel awal (koleksi buku PAUD, kategori lengkap, dan contoh pesanan)? Tindakan ini berguna untuk demonstrasi.
            </p>

            <div className="mt-6 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setShowResetConfirmModal(false)}
                className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-100"
              >
                Batal
              </button>

              <button
                type="button"
                onClick={handleConfirmResetDemo}
                disabled={isProcessing}
                className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-rose-600/30 active:scale-95 disabled:opacity-50"
              >
                {isProcessing ? 'Mereset...' : 'Ya, Reset Data Demo'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
