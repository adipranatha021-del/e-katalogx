import React, { useState } from 'react';
import { Users, Search, MessageSquare, MapPin, ShoppingBag } from 'lucide-react';
import { Customer } from '../../types.ts';
import { formatRupiah, formatDateIndonesia, buildWhatsAppUrl } from '../../utils/formatters.ts';

interface AdminCustomersViewProps {
  customers: Customer[];
}

export const AdminCustomersView: React.FC<AdminCustomersViewProps> = ({ customers }) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = customers.filter((c) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      c.name.toLowerCase().includes(q) ||
      c.phone.includes(q) ||
      c.city.toLowerCase().includes(q) ||
      c.address.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6">
      {/* Header & Search */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
            <Users className="w-5 h-5 text-blue-600" />
            <span>Direktori Pelanggan ({customers.length} Orang)</span>
          </h3>
          <p className="text-xs text-slate-500">
            Daftar pelanggan yang pernah bertransaksi di E-Katalog
          </p>
        </div>

        <div className="relative min-w-[240px]">
          <input
            type="text"
            placeholder="Cari nama, nomor HP, atau kota..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
        </div>
      </div>

      {/* Customers Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 uppercase font-bold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Nama Pelanggan</th>
                <th className="py-3 px-4">Kontak WhatsApp</th>
                <th className="py-3 px-4">Alamat & Kota</th>
                <th className="py-3 px-4 text-center">Total Pesanan</th>
                <th className="py-3 px-4 text-right">Total Transaksi</th>
                <th className="py-3 px-4">Pesanan Terakhir</th>
                <th className="py-3 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-slate-400">
                    Tidak ada data pelanggan yang cocok.
                  </td>
                </tr>
              ) : (
                filtered.map((cust) => (
                  <tr key={cust.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 font-bold text-slate-900">
                      {cust.name}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-700">
                      {cust.phone}
                    </td>
                    <td className="py-3 px-4 text-slate-600 max-w-xs truncate">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                        <span>{cust.address}, {cust.city}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-blue-50 text-blue-700 inline-flex items-center gap-1">
                        <ShoppingBag className="w-3 h-3" />
                        <span>{cust.totalOrders}x</span>
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-extrabold text-blue-700 font-mono">
                      {formatRupiah(cust.totalSpent)}
                    </td>
                    <td className="py-3 px-4 text-slate-500 text-[11px]">
                      {formatDateIndonesia(cust.lastOrderAt)}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <a
                        href={buildWhatsAppUrl(
                          cust.phone,
                          `Halo ${cust.name}, terima kasih telah berbelanja di E-Katalog Buku.`
                        )}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-2.5 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-semibold text-xs inline-flex items-center gap-1 transition-colors"
                        title="Kirim pesan WhatsApp"
                      >
                        <MessageSquare className="w-3.5 h-3.5" />
                        <span>Chat WA</span>
                      </a>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
