import React, { useState } from 'react';
import {
  Boxes,
  AlertTriangle,
  ArrowUpRight,
  ArrowDownRight,
  History,
  PlusCircle,
  X,
  Loader2,
  CheckCircle,
} from 'lucide-react';
import { Book, StockMovement } from '../../types.ts';
import { formatDateIndonesia } from '../../utils/formatters.ts';
import { api } from '../../services/api.ts';

interface AdminStockViewProps {
  books: Book[];
  stockMovements: StockMovement[];
  onRefresh: () => void;
  selectedBookForRestock?: Book | null;
  onClearSelectedBook?: () => void;
}

export const AdminStockView: React.FC<AdminStockViewProps> = ({
  books,
  stockMovements,
  onRefresh,
  selectedBookForRestock,
  onClearSelectedBook,
}) => {
  const [isAdjustModalOpen, setIsAdjustModalOpen] = useState(Boolean(selectedBookForRestock));
  const [targetBookId, setTargetBookId] = useState(selectedBookForRestock?.id || books[0]?.id || '');
  const [adjustQuantity, setAdjustQuantity] = useState<number>(5);
  const [adjustType, setAdjustType] = useState<'in' | 'adjustment'>('in');
  const [adjustReason, setAdjustReason] = useState('Penerimaan restok dari distributor');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  const activeBooks = books.filter((b) => b.isActive);
  const totalUnits = activeBooks.reduce((sum, b) => sum + b.stock, 0);
  const lowStockBooks = activeBooks.filter((b) => b.stock <= (b.minStockAlert || 5));

  const handleOpenModal = (book?: Book) => {
    if (book) {
      setTargetBookId(book.id);
    } else {
      setTargetBookId(books[0]?.id || '');
    }
    setAdjustQuantity(5);
    setAdjustType('in');
    setAdjustReason('Penerimaan restok dari distributor');
    setIsAdjustModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsAdjustModalOpen(false);
    if (onClearSelectedBook) onClearSelectedBook();
  };

  const handleSubmitAdjustment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!targetBookId || adjustQuantity === 0) return;

    setIsSubmitting(true);
    try {
      const delta = adjustType === 'in' ? Math.abs(adjustQuantity) : -Math.abs(adjustQuantity);
      await api.adjustStock({
        bookId: targetBookId,
        quantity: delta,
        reason: adjustReason.trim(),
        type: adjustType,
      });

      setFeedbackMsg('Penyesuaian mutasi stok berhasil dicatat ke sistem.');
      handleCloseModal();
      onRefresh();
      setTimeout(() => setFeedbackMsg(null), 3000);
    } catch (err: any) {
      setFeedbackMsg(err.message || 'Gagal mengubah stok.');
      setTimeout(() => setFeedbackMsg(null), 3000);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Feedback banner */}
      {feedbackMsg && (
        <div className="p-4 rounded-2xl bg-emerald-50 text-emerald-800 text-xs sm:text-sm font-semibold border border-emerald-200 flex items-center gap-2 animate-fadeIn">
          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{feedbackMsg}</span>
        </div>
      )}

      {/* Stock Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Total Unit Fisik
          </span>
          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-1">
            {totalUnits} Unit
          </h3>
          <p className="text-xs text-slate-500 mt-1">Dari {activeBooks.length} judul buku aktif</p>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Stok Menipis / Kritis
          </span>
          <h3 className="text-2xl sm:text-3xl font-extrabold text-amber-600 mt-1">
            {lowStockBooks.length} Judul
          </h3>
          <p className="text-xs text-amber-600 mt-1 font-semibold">Perlu segera dilakukan restok</p>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Aksi Cepat
            </span>
            <p className="text-xs text-slate-600 mt-1 font-medium">Catat mutasi / restok manual</p>
          </div>
          <button
            onClick={() => handleOpenModal()}
            className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-blue-600/20"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Sesuaikan Stok</span>
          </button>
        </div>
      </div>

      {/* Low Stock List */}
      {lowStockBooks.length > 0 && (
        <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="w-5 h-5 text-amber-600" />
            <h4 className="font-extrabold text-sm text-amber-900">
              Perhatian: {lowStockBooks.length} Buku Memiliki Stok Kritis (Di Bawah Batas Minimum)
            </h4>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {lowStockBooks.map((b) => (
              <div
                key={b.id}
                className="bg-white p-3 rounded-xl border border-amber-200 flex items-center justify-between gap-3 text-xs"
              >
                <div className="min-w-0">
                  <p className="font-bold text-slate-900 truncate">{b.title}</p>
                  <p className="text-[11px] text-slate-500 truncate">{b.author}</p>
                  <span className="text-amber-700 font-extrabold">Sisa {b.stock} unit</span>
                </div>
                <button
                  onClick={() => handleOpenModal(b)}
                  className="px-2.5 py-1.5 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-lg shrink-0 text-xs shadow-xs"
                >
                  Restok
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Audit History of Stock Movements (Mutasi Stok) */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-blue-600" />
            <div>
              <h3 className="font-extrabold text-base text-slate-900">
                Riwayat Mutasi Stok (Audit Log)
              </h3>
              <p className="text-xs text-slate-500">
                Setiap pengurangan akibat pesanan dan penambahan restok tercatat secara otomatis
              </p>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 uppercase font-bold border-b border-slate-200">
              <tr>
                <th className="py-2.5 px-4">Waktu (WITA)</th>
                <th className="py-2.5 px-4">Judul Buku</th>
                <th className="py-2.5 px-4 text-center">Tipe Mutasi</th>
                <th className="py-2.5 px-4 text-center">Perubahan</th>
                <th className="py-2.5 px-4 text-center">Sebelum / Sesudah</th>
                <th className="py-2.5 px-4">Keterangan / Alasan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {stockMovements.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    Belum ada riwayat mutasi stok tercatat.
                  </td>
                </tr>
              ) : (
                stockMovements.map((sm) => (
                  <tr key={sm.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4 text-slate-500 font-mono text-[11px]">
                      {formatDateIndonesia(sm.createdAt)}
                    </td>
                    <td className="py-3 px-4 font-bold text-slate-900">
                      {sm.bookTitle}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          sm.type === 'in'
                            ? 'bg-emerald-100 text-emerald-800'
                            : sm.type === 'out'
                            ? 'bg-rose-100 text-rose-800'
                            : sm.type === 'cancel_return'
                            ? 'bg-sky-100 text-sky-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {sm.type === 'in'
                          ? 'Restok Masuk'
                          : sm.type === 'out'
                          ? 'Keluar (Pesanan)'
                          : sm.type === 'cancel_return'
                          ? 'Retur Batal'
                          : 'Penyesuaian'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center font-bold font-mono">
                      <span
                        className={`inline-flex items-center gap-0.5 ${
                          sm.quantity > 0 ? 'text-emerald-600' : 'text-rose-600'
                        }`}
                      >
                        {sm.quantity > 0 ? (
                          <ArrowUpRight className="w-3.5 h-3.5" />
                        ) : (
                          <ArrowDownRight className="w-3.5 h-3.5" />
                        )}
                        {sm.quantity > 0 ? `+${sm.quantity}` : sm.quantity}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center text-slate-500 font-mono">
                      {sm.previousStock} → <strong className="text-slate-900">{sm.currentStock}</strong>
                    </td>
                    <td className="py-3 px-4 text-slate-600 max-w-xs truncate">
                      {sm.reason}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Adjust Stock */}
      {isAdjustModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div
            className="relative bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-200 animate-scaleUp"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-5 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="font-extrabold text-base">Penyesuaian Stok Manual</h3>
              <button
                onClick={handleCloseModal}
                className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitAdjustment} className="p-6 space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Pilih Judul Buku
                </label>
                <select
                  value={targetBookId}
                  onChange={(e) => setTargetBookId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
                >
                  {books.map((b) => (
                    <option key={b.id} value={b.id}>
                      {b.title} (Saat ini: {b.stock} unit)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Jenis Penyesuaian
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAdjustType('in')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition-colors ${
                      adjustType === 'in'
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    + Tambah Stok (Restok)
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdjustType('adjustment')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold transition-colors ${
                      adjustType === 'adjustment'
                        ? 'bg-rose-600 text-white'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    - Kurangi Stok (Rusak/Hilang)
                  </button>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Jumlah Unit
                </label>
                <input
                  type="number"
                  min="1"
                  required
                  value={adjustQuantity}
                  onChange={(e) => setAdjustQuantity(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none font-bold"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Alasan / Keterangan Mutasi
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Restok kiriman dari penerbit Jakarta"
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={handleCloseModal}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-5 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-2 shadow-md"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Menyimpan...</span>
                    </>
                  ) : (
                    <span>Catat Mutasi Stok</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
