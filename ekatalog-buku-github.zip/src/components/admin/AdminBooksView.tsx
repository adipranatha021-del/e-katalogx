import React, { useState, useRef } from 'react';
import {
  BookOpen,
  Plus,
  Search,
  Edit2,
  Archive,
  ArchiveRestore,
  Trash2,
  AlertCircle,
  CheckCircle,
  Loader2,
  X,
  Upload,
  Image as ImageIcon,
} from 'lucide-react';
import { Book, Category } from '../../types.ts';
import { formatRupiah } from '../../utils/formatters.ts';
import { api } from '../../services/api.ts';

interface AdminBooksViewProps {
  books: Book[];
  categories: Category[];
  onRefresh: () => void;
  onQuickRestock: (book: Book) => void;
}

export const AdminBooksView: React.FC<AdminBooksViewProps> = ({
  books,
  categories,
  onRefresh,
  onQuickRestock,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showArchived, setShowArchived] = useState(false);

  // Modal Add / Edit
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBook, setEditingBook] = useState<Book | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);
  const [bookToDelete, setBookToDelete] = useState<Book | null>(null);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  // Form Fields
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [publisher, setPublisher] = useState('');
  const [year, setYear] = useState(new Date().getFullYear());
  const [isbn, setIsbn] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [description, setDescription] = useState('');
  const [costPrice, setCostPrice] = useState<number>(0);
  const [sellPrice, setSellPrice] = useState<number>(0);
  const [stock, setStock] = useState<number>(15);
  const [coverUrl, setCoverUrl] = useState('');
  const [ageGroup, setAgeGroup] = useState('Usia 3 - 6 Tahun');
  const [isActive, setIsActive] = useState(true);

  // File upload input ref
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Open Add Modal
  const handleOpenAdd = () => {
    setEditingBook(null);
    setTitle('');
    setAuthor('');
    setPublisher('Penerbit PAUD Ceria');
    setYear(new Date().getFullYear());
    setIsbn('');
    setCategoryId(categories[0]?.id || '');
    setDescription('');
    setCostPrice(0);
    setSellPrice(25000);
    setStock(15);
    setCoverUrl('https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=600&q=80');
    setAgeGroup('Usia 3 - 6 Tahun');
    setIsActive(true);
    setFormError(null);
    setIsModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEdit = (b: Book) => {
    setEditingBook(b);
    setTitle(b.title);
    setAuthor(b.author);
    setPublisher(b.publisher);
    setYear(b.year);
    setIsbn(b.isbn || '');
    setCategoryId(b.categoryId);
    setDescription(b.description);
    setCostPrice(b.costPrice || 0);
    setSellPrice(b.sellPrice);
    setStock(b.stock);
    setCoverUrl(b.coverUrl);
    setAgeGroup(b.ageGroup || 'Usia 3 - 6 Tahun');
    setIsActive(b.isActive);
    setFormError(null);
    setIsModalOpen(true);
  };

  // Image Upload handler (supports base64 data URL)
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setFormError('Mohon pilih file gambar (JPG, PNG, WebP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setCoverUrl(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!title.trim() || !author.trim() || !categoryId || sellPrice <= 0) {
      setFormError('Judul buku, Penulis, Kategori, dan Harga Jual wajib diisi dengan benar.');
      return;
    }

    setIsSubmitting(true);
    try {
      const payload = {
        title: title.trim(),
        author: author.trim(),
        publisher: publisher.trim(),
        year: Number(year),
        isbn: isbn.trim() || undefined,
        categoryId,
        description: description.trim(),
        costPrice: Number(costPrice) || 0,
        sellPrice: Number(sellPrice),
        stock: Number(stock),
        coverUrl: coverUrl.trim(),
        ageGroup,
        isActive,
      };

      if (editingBook) {
        await api.updateBook(editingBook.id, payload);
        setFeedbackMsg(`Buku No. ${editingBook.catalogNumber} — "${title}" berhasil diperbarui.`);
      } else {
        const created = await api.createBook(payload);
        setFeedbackMsg(`Buku No. ${created.catalogNumber} — "${title}" berhasil ditambahkan ke katalog.`);
      }

      setIsModalOpen(false);
      onRefresh();
      setTimeout(() => setFeedbackMsg(null), 3000);
    } catch (err: any) {
      setFormError(err.message || 'Gagal menyimpan data buku.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleToggleArchive = async (b: Book) => {
    try {
      await api.toggleArchiveBook(b.id);
      setFeedbackMsg(
        b.isActive
          ? `Buku No. ${b.catalogNumber} berhasil diarsipkan.`
          : `Buku No. ${b.catalogNumber} berhasil diaktifkan kembali.`
      );
      onRefresh();
      setTimeout(() => setFeedbackMsg(null), 3000);
    } catch (err: any) {
      setFeedbackMsg(err.message || 'Gagal mengubah status buku.');
      setTimeout(() => setFeedbackMsg(null), 3000);
    }
  };

  const handleConfirmDelete = async () => {
    if (!bookToDelete) return;
    setDeleteError(null);
    setIsSubmitting(true);

    try {
      await api.deleteBook(bookToDelete.id);
      setFeedbackMsg(`Buku No. ${bookToDelete.catalogNumber} — "${bookToDelete.title}" berhasil dihapus.`);
      setBookToDelete(null);
      onRefresh();
      setTimeout(() => setFeedbackMsg(null), 3000);
    } catch (err: any) {
      setDeleteError(err.message || 'Gagal menghapus buku.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Filter books
  const filtered = books
    .filter((b) => {
      if (!showArchived && !b.isActive) return false;
      if (selectedCategory !== 'all' && b.categoryId !== selectedCategory) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const match =
          b.title.toLowerCase().includes(q) ||
          b.author.toLowerCase().includes(q) ||
          (b.catalogNumber && b.catalogNumber.toLowerCase().includes(q)) ||
          (b.isbn && b.isbn.toLowerCase().includes(q)) ||
          b.publisher.toLowerCase().includes(q);
        if (!match) return false;
      }
      return true;
    })
    .sort((a, b) => {
      const numA = parseInt(a.catalogNumber || '0', 10);
      const numB = parseInt(b.catalogNumber || '0', 10);
      return numA - numB;
    });

  return (
    <div className="space-y-6">
      {/* Feedback banner */}
      {feedbackMsg && (
        <div className="p-4 rounded-2xl bg-emerald-50 text-emerald-800 text-xs sm:text-sm font-semibold border border-emerald-200 flex items-center gap-2 animate-fadeIn">
          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{feedbackMsg}</span>
        </div>
      )}

      {/* Control bar */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/90 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Search & Category Filter */}
        <div className="flex flex-1 flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <input
              type="text"
              placeholder="Cari nomor katalog (001), judul buku, penulis..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          </div>

          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="px-3 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-700 bg-white cursor-pointer"
          >
            <option value="all">Semua Kategori PAUD</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          <label className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 cursor-pointer select-none bg-slate-50 px-3 py-2.5 rounded-xl border border-slate-200">
            <input
              type="checkbox"
              checked={showArchived}
              onChange={(e) => setShowArchived(e.target.checked)}
              className="rounded text-blue-600"
            />
            <span>Tampilkan Arsip</span>
          </label>
        </div>

        {/* Add Book Button matching collage mockup */}
        <button
          onClick={handleOpenAdd}
          className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-md shadow-blue-600/25 transition-all shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Tambah Buku</span>
        </button>
      </div>

      {/* Books Table */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 uppercase font-bold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4 text-center">No. Katalog</th>
                <th className="py-3 px-4">Buku & Sampul</th>
                <th className="py-3 px-4">Kategori & Usia</th>
                <th className="py-3 px-4 text-right">Harga Jual</th>
                <th className="py-3 px-4 text-center">Stok Fisik</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-right">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-400">
                    Tidak ada data buku yang ditemukan.
                  </td>
                </tr>
              ) : (
                filtered.map((b) => (
                  <tr
                    key={b.id}
                    className={`hover:bg-slate-50/80 transition-colors ${!b.isActive ? 'bg-slate-50/50 opacity-70' : ''}`}
                  >
                    {/* Catalog Number Badge */}
                    <td className="py-3 px-4 text-center font-mono">
                      <span className="px-2.5 py-1 rounded-lg bg-blue-50 text-blue-800 font-black border border-blue-200 text-xs">
                        No. {b.catalogNumber || '001'}
                      </span>
                    </td>

                    {/* Cover & Title */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img
                          src={b.coverUrl}
                          alt={b.title}
                          className="w-10 h-14 object-cover rounded-md shadow-2xs border border-slate-200 shrink-0 bg-slate-50"
                        />
                        <div className="min-w-0 max-w-xs">
                          <h4 className="font-bold text-slate-900 truncate">{b.title}</h4>
                          <p className="text-[11px] text-slate-500 truncate">{b.author}</p>
                          {b.publisher && (
                            <span className="text-[10px] text-slate-400 block truncate">
                              {b.publisher} ({b.year})
                            </span>
                          )}
                        </div>
                      </div>
                    </td>

                    {/* Category & Age Group */}
                    <td className="py-3 px-4">
                      <span className="font-semibold text-slate-800 block">{b.categoryName}</span>
                      <span className="text-[10px] text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded font-medium inline-block mt-0.5">
                        {b.ageGroup || 'Usia PAUD'}
                      </span>
                    </td>

                    {/* Sell Price */}
                    <td className="py-3 px-4 text-right font-extrabold text-blue-700 font-mono text-sm">
                      {formatRupiah(b.sellPrice)}
                    </td>

                    {/* Stock */}
                    <td className="py-3 px-4 text-center">
                      <div className="inline-flex items-center gap-1.5">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                            b.stock <= 0
                              ? 'bg-rose-100 text-rose-800'
                              : b.stock <= (b.minStockAlert || 5)
                              ? 'bg-amber-100 text-amber-800 animate-pulse'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {b.stock} unit
                        </span>
                        <button
                          onClick={() => onQuickRestock(b)}
                          className="text-[10px] text-blue-600 hover:underline font-bold"
                          title="Tambah stok"
                        >
                          +
                        </button>
                      </div>
                    </td>

                    {/* Status */}
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          b.isActive
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : 'bg-slate-200 text-slate-600 border border-slate-300'
                        }`}
                      >
                        {b.isActive ? 'Tersedia' : 'Arsip'}
                      </span>
                    </td>

                    {/* Actions */}
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleOpenEdit(b)}
                          className="p-1.5 rounded-lg text-slate-600 hover:text-blue-600 hover:bg-blue-50 transition-colors"
                          title="Edit Buku & Harga"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          onClick={() => handleToggleArchive(b)}
                          className="p-1.5 rounded-lg text-slate-600 hover:text-amber-600 hover:bg-amber-50 transition-colors"
                          title={b.isActive ? 'Arsipkan Buku' : 'Pulihkan Buku'}
                        >
                          {b.isActive ? (
                            <Archive className="w-3.5 h-3.5" />
                          ) : (
                            <ArchiveRestore className="w-3.5 h-3.5 text-emerald-600" />
                          )}
                        </button>

                        <button
                          onClick={() => {
                            setDeleteError(null);
                            setBookToDelete(b);
                          }}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                          title="Hapus Buku"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ========================================================= */}
      {/* MODAL TAMBAH / EDIT BUKU MATCHING COLLAGE MOCKUP          */}
      {/* ========================================================= */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
          <div
            className="relative bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-200 animate-scaleUp my-8"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="p-5 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-blue-400" />
                <h3 className="font-extrabold text-base">
                  {editingBook
                    ? `Edit Buku No. ${editingBook.catalogNumber}`
                    : 'Tambah Buku PAUD Baru'}
                </h3>
              </div>
              <button
                onClick={() => setIsModalOpen(false)}
                className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Form matching reference mockup */}
            <form onSubmit={handleSubmitForm} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
              {formError && (
                <div className="p-3 rounded-xl bg-rose-50 text-rose-800 text-xs font-semibold border border-rose-200 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
                  <span>{formError}</span>
                </div>
              )}

              {/* Title & Author */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Judul Buku <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Masukkan judul buku PAUD"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Penulis <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Masukkan nama penulis"
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Category & Sell Price */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Kategori PAUD <span className="text-rose-500">*</span>
                  </label>
                  <select
                    value={categoryId}
                    onChange={(e) => setCategoryId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white cursor-pointer"
                  >
                    {categories.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Harga Jual (Rp) <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    required
                    min="1000"
                    step="500"
                    placeholder="Masukkan harga"
                    value={sellPrice}
                    onChange={(e) => setSellPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none font-bold text-blue-700"
                  />
                </div>
              </div>

              {/* Stock & Age Group */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Jumlah Stok Unit <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    placeholder="Masukkan jumlah stok"
                    value={stock}
                    onChange={(e) => setStock(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none font-bold"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    Kelompok Usia Sasaran
                  </label>
                  <select
                    value={ageGroup}
                    onChange={(e) => setAgeGroup(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none bg-white"
                  >
                    <option value="Usia 2 - 4 Tahun">Usia 2 - 4 Tahun (Batita / Pre-PAUD)</option>
                    <option value="Usia 3 - 5 Tahun">Usia 3 - 5 Tahun (PAUD / TK A)</option>
                    <option value="Usia 4 - 6 Tahun">Usia 4 - 6 Tahun (TK B / Persiapan SD)</option>
                    <option value="Semua Usia PAUD">Semua Usia PAUD</option>
                  </select>
                </div>
              </div>

              {/* Upload Gambar Sampul Box matching mockup: "Klik untuk memilih gambar atau drag & drop" */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Upload Gambar Sampul Buku
                </label>
                <input
                  type="file"
                  ref={fileInputRef}
                  accept="image/*"
                  onChange={handleFileChange}
                  className="hidden"
                />

                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-300 hover:border-blue-500 rounded-2xl p-4 text-center cursor-pointer bg-slate-50/60 hover:bg-blue-50/40 transition-colors flex flex-col items-center justify-center gap-2 group"
                >
                  {coverUrl ? (
                    <div className="flex items-center gap-4">
                      <img
                        src={coverUrl}
                        alt="Pratinjau Sampul"
                        className="w-14 h-18 object-cover rounded-lg shadow-sm border border-slate-200"
                      />
                      <div className="text-left">
                        <span className="text-xs font-bold text-blue-600 block">
                          Sampul dipilih
                        </span>
                        <span className="text-[11px] text-slate-500">
                          Klik untuk mengganti dengan file lain
                        </span>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center group-hover:scale-105 transition-transform">
                        <ImageIcon className="w-6 h-6" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-blue-600">
                          Klik untuk memilih gambar
                        </p>
                        <p className="text-[11px] text-slate-400">
                          atau drag & drop file gambar sampul buku
                        </p>
                      </div>
                    </>
                  )}
                </div>

                {/* Direct URL input fallback */}
                <div className="mt-2">
                  <input
                    type="url"
                    placeholder="Atau tempel URL gambar langsung (https://...)"
                    value={coverUrl}
                    onChange={(e) => setCoverUrl(e.target.value)}
                    className="w-full px-3 py-1.5 rounded-lg border border-slate-200 text-[11px] text-slate-600"
                  />
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  Deskripsi / Sinopsis Buku
                </label>
                <textarea
                  rows={3}
                  placeholder="Masukkan deskripsi buku..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>

              {/* Active Toggle */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="isActiveToggle"
                  checked={isActive}
                  onChange={(e) => setIsActive(e.target.checked)}
                  className="rounded text-blue-600 w-4 h-4 cursor-pointer"
                />
                <label htmlFor="isActiveToggle" className="text-xs font-semibold text-slate-700 cursor-pointer">
                  Tampilkan aktif di katalog toko publik
                </label>
              </div>

              {/* Submit Button matching mockup: "Simpan" primary blue */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-100"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-2 shadow-md shadow-blue-600/25 active:scale-98"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Menyimpan...</span>
                    </>
                  ) : (
                    <span>Simpan</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL KONFIRMASI HAPUS BUKU                              */}
      {/* ========================================================= */}
      {bookToDelete && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="relative bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-200 p-6 animate-scaleUp">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mb-4">
              <Trash2 className="w-6 h-6" />
            </div>

            <h3 className="text-lg font-extrabold text-slate-900">
              Hapus Buku No. {bookToDelete.catalogNumber}?
            </h3>
            <p className="text-sm font-semibold text-slate-700 mt-1">
              "{bookToDelete.title}"
            </p>

            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Apakah Anda yakin ingin menghapus buku ini dari katalog? Jika buku telah memiliki riwayat pesanan pelanggan, buku sebaiknya diarsipkan agar riwayat penjualan tetap utuh.
            </p>

            {deleteError && (
              <div className="mt-4 p-3 rounded-xl bg-rose-50 text-rose-700 text-xs font-semibold border border-rose-200 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <span>{deleteError}</span>
              </div>
            )}

            <div className="mt-6 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => {
                  setBookToDelete(null);
                  setDeleteError(null);
                }}
                className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-100"
              >
                Batal
              </button>

              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isSubmitting}
                className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-rose-600/30 active:scale-95 disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Menghapus...</span>
                  </>
                ) : (
                  <span>Ya, Hapus Buku</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
