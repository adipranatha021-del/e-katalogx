import React, { useState, useRef } from 'react';
import {
  Save,
  CheckCircle,
  Building,
  CreditCard,
  Lock,
  Phone,
  Image as ImageIcon,
  Clock,
  User,
  Loader2,
  Plus,
  Trash2,
  ExternalLink,
} from 'lucide-react';
import { AppSettings, BankAccount } from '../../types.ts';
import { api } from '../../services/api.ts';

interface AdminSettingsViewProps {
  settings: AppSettings | null;
  onRefresh: () => void;
}

export const AdminSettingsView: React.FC<AdminSettingsViewProps> = ({
  settings,
  onRefresh,
}) => {
  // Store Profile Fields
  const [storeName, setStoreName] = useState(settings?.storeName || 'Katalog Buku PAUD Ceria');
  const [storeTagline, setStoreTagline] = useState(settings?.storeTagline || '');
  const [logoUrl, setLogoUrl] = useState(settings?.logoUrl || '');
  const [bannerUrl, setBannerUrl] = useState(settings?.bannerUrl || '');
  const [ownerName, setOwnerName] = useState(settings?.ownerName || '');
  const [whatsappNumber, setWhatsappNumber] = useState(settings?.whatsappNumber || '6281234567890');
  const [storeAddress, setStoreAddress] = useState(settings?.storeAddress || '');
  const [storeEmail, setStoreEmail] = useState(settings?.storeEmail || '');
  const [operatingHours, setOperatingHours] = useState(settings?.operatingHours || 'Senin - Sabtu: 08.00 - 17.00 WITA');

  // Operational Settings
  const [enableCod, setEnableCod] = useState(settings?.enableCod ?? true);
  const [lowStockThreshold, setLowStockThreshold] = useState(settings?.lowStockThreshold || 5);
  const [shippingFlatRate, setShippingFlatRate] = useState(settings?.shippingFlatRate || 15000);

  // Security Credentials
  const [adminUsername, setAdminUsername] = useState(settings?.adminUsername || 'admin');
  const [adminPin, setAdminPin] = useState(settings?.adminPin || 'admin123');

  // Bank Accounts
  const [bankAccounts, setBankAccounts] = useState<BankAccount[]>(
    settings?.bankAccounts || [
      { bank: 'BCA', number: '8271-992-011', holder: 'Katalog Buku PAUD Official' },
      { bank: 'Bank Mandiri', number: '137-00-9821-223', holder: 'Katalog Buku PAUD Official' },
      { bank: 'BRI', number: '0123-01-002931-50-8', holder: 'Katalog Buku PAUD Official' },
    ]
  );

  const logoFileRef = useRef<HTMLInputElement>(null);
  const bannerFileRef = useRef<HTMLInputElement>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Logo upload reader
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setLogoUrl(ev.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Banner upload reader
  const handleBannerUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setBannerUrl(ev.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleBankChange = (index: number, field: keyof BankAccount, value: string) => {
    const updated = [...bankAccounts];
    updated[index] = { ...updated[index], [field]: value };
    setBankAccounts(updated);
  };

  const handleAddBank = () => {
    setBankAccounts([...bankAccounts, { bank: 'BNI', number: '', holder: storeName }]);
  };

  const handleRemoveBank = (index: number) => {
    setBankAccounts(bankAccounts.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMsg(null);
    try {
      await api.updateSettings({
        storeName: storeName.trim(),
        storeTagline: storeTagline.trim(),
        logoUrl: logoUrl.trim(),
        bannerUrl: bannerUrl.trim(),
        ownerName: ownerName.trim(),
        whatsappNumber: whatsappNumber.trim(),
        storeAddress: storeAddress.trim(),
        storeEmail: storeEmail.trim(),
        operatingHours: operatingHours.trim(),
        bankAccounts,
        enableCod,
        lowStockThreshold: Number(lowStockThreshold),
        shippingFlatRate: Number(shippingFlatRate),
        adminUsername: adminUsername.trim(),
        adminPin: adminPin.trim(),
      });

      setFeedbackMsg('Profil toko dan pengaturan berhasil disimpan!');
      onRefresh();
      setTimeout(() => setFeedbackMsg(null), 3000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Gagal menyimpan pengaturan.');
      setTimeout(() => setErrorMsg(null), 4000);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Feedback Alert */}
      {feedbackMsg && (
        <div className="p-4 rounded-2xl bg-emerald-50 text-emerald-800 text-xs sm:text-sm font-bold border border-emerald-200 flex items-center gap-2 animate-fadeIn">
          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{feedbackMsg}</span>
        </div>
      )}

      {/* Error Alert */}
      {errorMsg && (
        <div className="p-4 rounded-2xl bg-rose-50 text-rose-800 text-xs sm:text-sm font-bold border border-rose-200 flex items-center gap-2 animate-fadeIn">
          <CheckCircle className="w-5 h-5 text-rose-600 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Main Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* ========================================================= */}
        {/* SECTION 1: PROFIL TOKO MANUAL (Persyaratan D)            */}
        {/* ========================================================= */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs space-y-5">
          <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
            <Building className="w-5 h-5 text-blue-600" />
            <div>
              <h3 className="text-base font-extrabold text-slate-900">
                Profil Toko Manual
              </h3>
              <p className="text-xs text-slate-400">
                Informasi ini ditampilkan di banner, navbar, dan kartu kontak WhatsApp katalog publik
              </p>
            </div>
          </div>

          {/* Nama Toko & Pemilik */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Nama Toko / Katalog <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={storeName}
                onChange={(e) => setStoreName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Nama Pemilik / Pengelola (Opsional)
              </label>
              <input
                type="text"
                placeholder="Contoh: Bunda Rini & Tim Pustaka PAUD"
                value={ownerName}
                onChange={(e) => setOwnerName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Slogan / Deskripsi */}
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">
              Deskripsi & Slogan Toko
            </label>
            <input
              type="text"
              placeholder="Contoh: Pusat Buku Belajar PAUD, Aktivitas Huruf, Angka & Mewarnai"
              value={storeTagline}
              onChange={(e) => setStoreTagline(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          {/* Nomor WhatsApp & Jam Operasional */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Nomor WhatsApp Toko (Awalan 62) <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                placeholder="6281234567890"
                value={whatsappNumber}
                onChange={(e) => setWhatsappNumber(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono font-bold text-emerald-700 focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Semua tombol pemesanan buku di katalog akan membuka obrolan ke nomor ini.
              </span>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Jam Operasional
              </label>
              <input
                type="text"
                placeholder="Contoh: Senin - Sabtu: 08.00 - 17.00 WITA"
                value={operatingHours}
                onChange={(e) => setOperatingHours(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Alamat Fisik & Email */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Alamat Toko Lengkap
              </label>
              <input
                type="text"
                placeholder="Jl. Pendidikan No. 12, Makassar"
                value={storeAddress}
                onChange={(e) => setStoreAddress(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Email Toko (Opsional)
              </label>
              <input
                type="email"
                placeholder="pustaka.paud@gmail.com"
                value={storeEmail}
                onChange={(e) => setStoreEmail(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Upload Logo & Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
            {/* Logo Upload */}
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Logo Toko
              </label>
              <input
                type="file"
                ref={logoFileRef}
                accept="image/*"
                onChange={handleLogoUpload}
                className="hidden"
              />
              <div className="flex items-center gap-3">
                {logoUrl && (
                  <img
                    src={logoUrl}
                    alt="Logo"
                    className="w-12 h-12 object-cover rounded-xl border border-slate-200 shadow-2xs"
                  />
                )}
                <button
                  type="button"
                  onClick={() => logoFileRef.current?.click()}
                  className="px-3 py-2 rounded-xl border border-slate-300 hover:bg-slate-50 text-xs font-bold text-slate-700 flex items-center gap-1.5"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                  <span>Pilih Logo Baru</span>
                </button>
              </div>
            </div>

            {/* Banner Upload */}
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Banner Gambar Katalog PAUD
              </label>
              <input
                type="file"
                ref={bannerFileRef}
                accept="image/*"
                onChange={handleBannerUpload}
                className="hidden"
              />
              <div className="flex items-center gap-3">
                {bannerUrl && (
                  <img
                    src={bannerUrl}
                    alt="Banner"
                    className="w-16 h-10 object-cover rounded-lg border border-slate-200 shadow-2xs"
                  />
                )}
                <button
                  type="button"
                  onClick={() => bannerFileRef.current?.click()}
                  className="px-3 py-2 rounded-xl border border-slate-300 hover:bg-slate-50 text-xs font-bold text-slate-700 flex items-center gap-1.5"
                >
                  <ImageIcon className="w-3.5 h-3.5 text-blue-600" />
                  <span>Pilih Banner Baru</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* ========================================================= */}
        {/* SECTION 2: AUTENTIKASI ADMIN & KEAMANAN                   */}
        {/* ========================================================= */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
            <Lock className="w-5 h-5 text-blue-600" />
            <h3 className="text-base font-extrabold text-slate-900">
              Kredensial Login Admin
            </h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Username Admin
              </label>
              <input
                type="text"
                value={adminUsername}
                onChange={(e) => setAdminUsername(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono font-bold focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Password / PIN Admin
              </label>
              <input
                type="text"
                value={adminPin}
                onChange={(e) => setAdminPin(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono font-bold focus:ring-2 focus:ring-blue-500 focus:outline-none text-blue-700"
              />
            </div>
          </div>
        </div>

        {/* ========================================================= */}
        {/* SECTION 3: REKENING BANK TOKO                             */}
        {/* ========================================================= */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-blue-600" />
              <h3 className="text-base font-extrabold text-slate-900">Rekening Transfer Pembeli</h3>
            </div>
            <button
              type="button"
              onClick={handleAddBank}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Tambah Bank</span>
            </button>
          </div>

          <div className="space-y-2.5">
            {bankAccounts.map((acc, idx) => (
              <div
                key={idx}
                className="grid grid-cols-1 sm:grid-cols-12 gap-2 p-2.5 bg-slate-50 rounded-xl border border-slate-200 text-xs items-center"
              >
                <div className="sm:col-span-3">
                  <input
                    type="text"
                    value={acc.bank}
                    onChange={(e) => handleBankChange(idx, 'bank', e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs font-bold bg-white"
                  />
                </div>
                <div className="sm:col-span-4">
                  <input
                    type="text"
                    value={acc.number}
                    onChange={(e) => handleBankChange(idx, 'number', e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs font-mono font-bold bg-white"
                  />
                </div>
                <div className="sm:col-span-4">
                  <input
                    type="text"
                    value={acc.holder}
                    onChange={(e) => handleBankChange(idx, 'holder', e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs bg-white"
                  />
                </div>
                <div className="sm:col-span-1 text-right">
                  <button
                    type="button"
                    onClick={() => handleRemoveBank(idx)}
                    className="p-1.5 text-slate-400 hover:text-rose-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* COD Toggle & Low stock threshold */}
          <div className="pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-800 block">
                  Metode COD (Bayar di Tempat)
                </span>
                <span className="text-[11px] text-slate-400">
                  Izinkan pembeli memilih bayar tunai
                </span>
              </div>
              <input
                type="checkbox"
                checked={enableCod}
                onChange={(e) => setEnableCod(e.target.checked)}
                className="w-4 h-4 text-blue-600 rounded cursor-pointer"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700 block mb-1">
                Ambang Batas Peringatan Stok Menipis
              </label>
              <input
                type="number"
                min="1"
                value={lowStockThreshold}
                onChange={(e) => setLowStockThreshold(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-8 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm flex items-center gap-2 shadow-lg shadow-blue-600/30 transition-all active:scale-98"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Menyimpan Perubahan...</span>
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                <span>Simpan Seluruh Pengaturan & Profil Toko</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
