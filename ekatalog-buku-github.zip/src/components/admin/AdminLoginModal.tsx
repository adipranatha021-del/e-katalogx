import React, { useState } from 'react';
import { BookOpen, User, Lock, Eye, EyeOff, X, AlertCircle, Loader2, ArrowRight } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';

interface AdminLoginModalProps {
  onSuccess?: () => void;
  onEnterAsGuest?: () => void;
  isStandalonePage?: boolean;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  onSuccess,
  onEnterAsGuest,
  isStandalonePage = false,
}) => {
  const { isLoginModalOpen, closeLoginModal, login } = useAuth();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isLoginModalOpen && !isStandalonePage) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!password.trim()) {
      setError('Password / PIN Admin wajib diisi');
      return;
    }

    setIsLoading(true);
    try {
      const ok = await login({ username: username.trim(), password: password.trim() });
      if (ok) {
        setPassword('');
        if (onSuccess) onSuccess();
      }
    } catch (err: any) {
      setError(err.message || 'Username atau Password salah. Default: admin / admin123');
    } finally {
      setIsLoading(false);
    }
  };

  const handleGuestClick = () => {
    if (onEnterAsGuest) {
      onEnterAsGuest();
    } else {
      closeLoginModal();
    }
  };

  const content = (
    <div
      className="relative bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-200 animate-scaleUp p-8"
      onClick={(e) => e.stopPropagation()}
    >
      {/* Close button if modal */}
      {!isStandalonePage && (
        <button
          onClick={closeLoginModal}
          className="absolute top-4 right-4 w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition-colors"
          aria-label="Tutup"
        >
          <X className="w-4 h-4" />
        </button>
      )}

      {/* Brand Header matching mockup */}
      <div className="text-center mb-8">
        <div className="w-14 h-14 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto mb-3 shadow-lg shadow-blue-500/25">
          <BookOpen className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-black text-slate-900 tracking-tight">E-Katalog</h2>
        <p className="text-xs font-semibold text-slate-500 mt-1">Aplikasi Katalog Buku PAUD</p>
      </div>

      {error && (
        <div className="mb-5 p-3 rounded-xl bg-rose-50 text-rose-800 text-xs font-semibold border border-rose-200 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Form matching mockup */}
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Username */}
        <div>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              <User className="w-4 h-4" />
            </div>
            <input
              type="text"
              required
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all bg-slate-50/50 focus:bg-white"
            />
          </div>
        </div>

        {/* Password */}
        <div>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
              <Lock className="w-4 h-4" />
            </div>
            <input
              type={showPassword ? 'text' : 'password'}
              required
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoFocus
              className="w-full pl-10 pr-10 py-3 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none transition-all bg-slate-50/50 focus:bg-white font-mono"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600"
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          <div className="flex justify-between items-center mt-1.5 text-[11px] text-slate-400 px-1">
            <span>Bawaan: admin / admin123</span>
          </div>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={isLoading}
          className="w-full py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition-all active:scale-98"
        >
          {isLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Memverifikasi...</span>
            </>
          ) : (
            <>
              <Lock className="w-4 h-4" />
              <span>Login</span>
            </>
          )}
        </button>

        {/* Separator */}
        <div className="relative my-4">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-200" />
          </div>
          <div className="relative flex justify-center text-xs">
            <span className="px-3 bg-white text-slate-400">atau</span>
          </div>
        </div>

        {/* Guest entrance matching mockup */}
        <button
          type="button"
          onClick={handleGuestClick}
          className="w-full py-2.5 px-4 rounded-xl border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-colors"
        >
          <span>Masuk sebagai Pengunjung</span>
          <ArrowRight className="w-4 h-4 text-blue-600" />
        </button>
      </form>
    </div>
  );

  if (isStandalonePage) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-blue-950 flex items-center justify-center p-4">
        {content}
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
      {content}
    </div>
  );
};
