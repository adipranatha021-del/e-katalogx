import React, { useState } from 'react';
import {
  ShoppingBag,
  Search,
  Printer,
  Truck,
  CheckCircle,
  Clock,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  MessageSquare,
  Hash,
} from 'lucide-react';
import { Order, OrderStatus, AppSettings } from '../../types.ts';
import { formatRupiah, formatDateIndonesia, buildWhatsAppUrl } from '../../utils/formatters.ts';
import { api } from '../../services/api.ts';

interface AdminOrdersViewProps {
  orders: Order[];
  settings: Partial<AppSettings> | null;
  onRefresh: () => void;
  onOpenInvoice: (order: Order) => void;
}

export const AdminOrdersView: React.FC<AdminOrdersViewProps> = ({
  orders,
  settings,
  onRefresh,
  onOpenInvoice,
}) => {
  const [selectedStatusTab, setSelectedStatusTab] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedOrderId, setExpandedOrderId] = useState<string | null>(null);
  const [resiInputs, setResiInputs] = useState<{ [orderId: string]: string }>({});
  const [updatingId, setUpdatingId] = useState<string | null>(null);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  const [orderToCancel, setOrderToCancel] = useState<Order | null>(null);

  const statusOptions: OrderStatus[] = [
    'Menunggu Konfirmasi',
    'Menunggu Pembayaran',
    'Diproses',
    'Dikirim',
    'Selesai',
    'Dibatalkan',
  ];

  const handleStatusChange = async (order: Order, newStatus: string) => {
    if (newStatus === 'Dibatalkan') {
      setOrderToCancel(order);
      return;
    }

    setUpdatingId(order.id);
    try {
      await api.updateOrderStatus(order.id, { status: newStatus });
      setFeedbackMsg(`Status pesanan ${order.orderCode} diubah menjadi "${newStatus}".`);
      onRefresh();
      setTimeout(() => setFeedbackMsg(null), 3000);
    } catch (err: any) {
      setFeedbackMsg(err.message || 'Gagal memperbarui status pesanan.');
      setTimeout(() => setFeedbackMsg(null), 3000);
    } finally {
      setUpdatingId(null);
    }
  };

  const handleConfirmCancelOrder = async () => {
    if (!orderToCancel) return;
    setUpdatingId(orderToCancel.id);
    try {
      await api.updateOrderStatus(orderToCancel.id, { status: 'Dibatalkan' });
      setFeedbackMsg(`Pesanan ${orderToCancel.orderCode} telah dibatalkan dan stok dikembalikan ke katalog.`);
      setOrderToCancel(null);
      onRefresh();
      setTimeout(() => setFeedbackMsg(null), 3000);
    } catch (err: any) {
      setFeedbackMsg(err.message || 'Gagal membatalkan pesanan.');
      setTimeout(() => setFeedbackMsg(null), 3000);
    } finally {
      setUpdatingId(null);
    }
  };

  const handleSaveResi = async (order: Order) => {
    const resi = resiInputs[order.id];
    if (resi === undefined) return;

    setUpdatingId(order.id);
    try {
      await api.updateOrderStatus(order.id, {
        trackingNumber: resi.trim(),
        status: order.status === 'Diproses' ? 'Dikirim' : order.status,
      });
      setFeedbackMsg(`Nomor resi untuk ${order.orderCode} berhasil disimpan.`);
      onRefresh();
      setTimeout(() => setFeedbackMsg(null), 3000);
    } catch (err: any) {
      setFeedbackMsg(err.message || 'Gagal menyimpan nomor resi.');
      setTimeout(() => setFeedbackMsg(null), 3000);
    } finally {
      setUpdatingId(null);
    }
  };

  // Filter orders
  const filtered = orders.filter((o) => {
    if (selectedStatusTab !== 'all' && o.status !== selectedStatusTab) return false;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const match =
        o.orderCode.toLowerCase().includes(q) ||
        o.customerName.toLowerCase().includes(q) ||
        o.customerPhone.includes(q) ||
        (o.trackingNumber && o.trackingNumber.toLowerCase().includes(q));
      if (!match) return false;
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Feedback banner */}
      {feedbackMsg && (
        <div className="p-4 rounded-2xl bg-emerald-50 text-emerald-800 text-xs sm:text-sm font-semibold border border-emerald-200 flex items-center gap-2 animate-fadeIn">
          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{feedbackMsg}</span>
        </div>
      )}

      {/* Control bar */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs space-y-4">
        {/* Status Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setSelectedStatusTab('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all ${
              selectedStatusTab === 'all'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Semua ({orders.length})
          </button>
          {statusOptions.map((st) => {
            const count = orders.filter((o) => o.status === st).length;
            return (
              <button
                key={st}
                onClick={() => setSelectedStatusTab(st)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-all ${
                  selectedStatusTab === st
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {st} ({count})
              </button>
            );
          })}
        </div>

        {/* Search */}
        <div className="relative">
          <input
            type="text"
            placeholder="Cari kode invoice (INV-...), nama pemesan, no HP, atau no resi..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 rounded-xl border border-slate-300 text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
        </div>
      </div>

      {/* Orders List Cards / Table */}
      <div className="space-y-4">
        {filtered.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 text-center border border-slate-200/80 text-slate-400">
            <ShoppingBag className="w-12 h-12 mx-auto mb-2 text-slate-300" />
            <p className="text-sm font-semibold">Tidak ada pesanan pada kriteria ini.</p>
          </div>
        ) : (
          filtered.map((order) => {
            const isExpanded = expandedOrderId === order.id;
            return (
              <div
                key={order.id}
                className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden transition-all"
              >
                {/* Main Row */}
                <div className="p-4 sm:p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  {/* Left: Code & Customer */}
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center shrink-0">
                      <Hash className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs sm:text-sm font-extrabold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                          {order.orderCode}
                        </span>
                        <span className="text-[11px] text-slate-400">
                          {formatDateIndonesia(order.createdAt)}
                        </span>
                      </div>
                      <h4 className="font-extrabold text-slate-900 text-sm mt-1">
                        {order.customerName}{' '}
                        <span className="font-normal text-xs text-slate-500">
                          ({order.customerPhone})
                        </span>
                      </h4>
                      <p className="text-xs text-slate-500 truncate max-w-md">
                        {order.customerAddress}, {order.customerCity}
                      </p>
                    </div>
                  </div>

                  {/* Middle: Amount & Status Dropdown */}
                  <div className="flex flex-wrap items-center gap-4">
                    <div>
                      <span className="text-[11px] text-slate-400 block">Total Tagihan</span>
                      <span className="font-extrabold text-base text-blue-700">
                        {formatRupiah(order.totalAmount)}
                      </span>
                    </div>

                    <div>
                      <span className="text-[11px] text-slate-400 block mb-0.5">Status</span>
                      <select
                        value={order.status}
                        onChange={(e) => handleStatusChange(order, e.target.value)}
                        disabled={updatingId === order.id}
                        className={`text-xs font-bold rounded-xl px-3 py-1.5 border cursor-pointer ${
                          order.status === 'Selesai'
                            ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                            : order.status === 'Dikirim'
                            ? 'bg-sky-50 text-sky-800 border-sky-300'
                            : order.status === 'Diproses'
                            ? 'bg-blue-50 text-blue-800 border-blue-300'
                            : order.status === 'Dibatalkan'
                            ? 'bg-rose-50 text-rose-800 border-rose-300'
                            : 'bg-amber-50 text-amber-800 border-amber-300'
                        }`}
                      >
                        {statusOptions.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Right: Actions */}
                  <div className="flex items-center gap-2 self-end lg:self-center">
                    <button
                      onClick={() => onOpenInvoice(order)}
                      className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition-colors"
                      title="Cetak Nota / Invoice Resmi"
                    >
                      <Printer className="w-3.5 h-3.5 text-blue-600" />
                      <span>Nota</span>
                    </button>

                    <a
                      href={buildWhatsAppUrl(
                        order.customerPhone,
                        `Halo Kak ${order.customerName}, kami dari E-Katalog Buku ingin mengonfirmasi pesanan ${order.orderCode}.`
                      )}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-600"
                      title="Chat Pelanggan di WhatsApp"
                    >
                      <MessageSquare className="w-4 h-4" />
                    </a>

                    <button
                      onClick={() => setExpandedOrderId(isExpanded ? null : order.id)}
                      className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600"
                      title={isExpanded ? 'Tutup Rincian' : 'Lihat Rincian'}
                    >
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Expanded Details */}
                {isExpanded && (
                  <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-100 space-y-4 text-xs animate-fadeIn">
                    {/* Items Table */}
                    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
                      <div className="px-3 py-2 bg-slate-100 font-bold text-slate-700 uppercase tracking-wider text-[11px]">
                        Rincian Barang Dipesan ({order.items.length} judul)
                      </div>
                      <div className="divide-y divide-slate-100">
                        {order.items.map((item, idx) => (
                          <div key={idx} className="p-3 flex items-center justify-between">
                            <div className="flex items-center gap-3">
                              <img
                                src={item.coverUrl}
                                alt={item.title}
                                className="w-9 h-12 object-cover rounded shadow-2xs border border-slate-200 bg-slate-50 shrink-0"
                              />
                              <div>
                                <h5 className="font-bold text-slate-900">{item.title}</h5>
                                <p className="text-[11px] text-slate-500">
                                  {item.author} • {formatRupiah(item.price)} x {item.quantity} unit
                                </p>
                              </div>
                            </div>
                            <span className="font-bold text-blue-700">
                              {formatRupiah(item.subtotal)}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Resi & Courier Input */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div className="bg-white p-3 rounded-xl border border-slate-200">
                        <label className="font-bold text-slate-700 block mb-1">
                          Nomor Resi Pengiriman (Kurir)
                        </label>
                        <div className="flex gap-2">
                          <input
                            type="text"
                            placeholder="Contoh: JNE-88231920 / SICEPAT-991"
                            value={
                              resiInputs[order.id] !== undefined
                                ? resiInputs[order.id]
                                : order.trackingNumber || ''
                            }
                            onChange={(e) =>
                              setResiInputs({ ...resiInputs, [order.id]: e.target.value })
                            }
                            className="flex-1 px-3 py-1.5 rounded-lg border border-slate-300 text-xs font-mono"
                          />
                          <button
                            onClick={() => handleSaveResi(order)}
                            className="px-3 py-1.5 bg-sky-600 hover:bg-sky-500 text-white rounded-lg font-bold text-xs"
                          >
                            Simpan Resi
                          </button>
                        </div>
                      </div>

                      <div className="bg-white p-3 rounded-xl border border-slate-200">
                        <span className="font-bold text-slate-700 block mb-1">
                          Metode Bayar & Catatan
                        </span>
                        <p className="text-slate-600">
                          {order.paymentMethod === 'cod' ? 'COD (Bayar di Tempat)' : `Transfer Bank ${order.bankName || ''}`}
                        </p>
                        {order.notes && (
                          <p className="text-slate-500 italic mt-1">Catatan: "{order.notes}"</p>
                        )}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>

      {/* ========================================================= */}
      {/* MODAL KONFIRMASI PEMBATALAN PESANAN                      */}
      {/* ========================================================= */}
      {orderToCancel && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 animate-fadeIn">
          <div className="relative bg-white rounded-3xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-200 p-6 animate-scaleUp">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mb-4">
              <AlertCircle className="w-6 h-6" />
            </div>

            <h3 className="text-lg font-extrabold text-slate-900">
              Batalkan Pesanan {orderToCancel.orderCode}?
            </h3>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Pesanan atas nama <strong>{orderToCancel.customerName}</strong> senilai{' '}
              <strong>{formatRupiah(orderToCancel.totalAmount)}</strong> akan dibatalkan.
            </p>

            <div className="mt-3 p-3 rounded-xl bg-blue-50 text-blue-800 text-xs font-medium border border-blue-100">
              ℹ️ <strong>Restok Otomatis:</strong> Sistem akan otomatis mengembalikan{' '}
              <strong>
                {orderToCancel.items.reduce((sum, item) => sum + item.quantity, 0)} unit buku
              </strong>{' '}
              kembali ke stok katalog fisik.
            </div>

            <div className="mt-6 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={() => setOrderToCancel(null)}
                className="px-4 py-2 rounded-xl border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-100"
              >
                Kembali
              </button>

              <button
                type="button"
                onClick={handleConfirmCancelOrder}
                disabled={Boolean(updatingId)}
                className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-md shadow-rose-600/30 active:scale-95 disabled:opacity-50"
              >
                {updatingId ? 'Membatalkan...' : 'Ya, Batalkan Pesanan'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
