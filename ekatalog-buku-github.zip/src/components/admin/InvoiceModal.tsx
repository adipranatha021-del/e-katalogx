import React from 'react';
import { X, Printer, BookOpen, CheckCircle, Clock } from 'lucide-react';
import { Order, AppSettings } from '../../types.ts';
import { formatRupiah, formatDateIndonesia } from '../../utils/formatters.ts';

interface InvoiceModalProps {
  order: Order | null;
  settings: Partial<AppSettings> | null;
  onClose: () => void;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({ order, settings, onClose }) => {
  if (!order) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div
        className="relative bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-200 animate-scaleUp my-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Control Bar (Hidden when printed) */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
              Pratinjau Nota Penjualan
            </span>
            <span className="font-mono text-xs bg-blue-600 px-2 py-0.5 rounded font-bold">
              {order.orderCode}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-sm transition-all"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Cetak Nota</span>
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* ========================================================= */}
        {/* PRINTABLE INVOICE DOCUMENT                                */}
        {/* ========================================================= */}
        <div className="p-6 sm:p-10 space-y-6 text-slate-800 bg-white" id="invoice-printable">
          {/* Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b-2 border-slate-900">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center text-white font-extrabold text-xl shadow-xs">
                <BookOpen className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl font-black text-slate-900 tracking-tight">
                  {settings?.storeName || 'E-KATALOG BUKU'}
                </h1>
                <p className="text-xs text-slate-500">{settings?.storeAddress || 'Makassar, Indonesia'}</p>
                <p className="text-[11px] text-slate-500">
                  WA: +{settings?.whatsappNumber || '6281234567890'} | Email: {settings?.storeEmail || 'halo@ekatalogbuku.id'}
                </p>
              </div>
            </div>

            <div className="text-left sm:text-right">
              <span className="text-xs font-bold uppercase tracking-widest text-slate-400 block">
                INVOICE RESMI
              </span>
              <span className="font-mono text-base sm:text-lg font-black text-blue-700">
                {order.orderCode}
              </span>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Tanggal: {formatDateIndonesia(order.createdAt)}
              </p>
            </div>
          </div>

          {/* Customer & Shipping Details */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
            <div>
              <span className="font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Tujuan Pengiriman:
              </span>
              <h4 className="font-extrabold text-sm text-slate-900">{order.customerName}</h4>
              <p className="text-slate-600 mt-0.5">{order.customerPhone}</p>
              <p className="text-slate-600 mt-1 leading-relaxed">
                {order.customerAddress}, {order.customerCity}
              </p>
            </div>

            <div>
              <span className="font-bold text-slate-400 uppercase tracking-wider block mb-1">
                Informasi Transaksi:
              </span>
              <p className="text-slate-700">
                <strong>Metode Bayar: </strong>
                {order.paymentMethod === 'cod' ? 'Bayar di Tempat (COD)' : `Transfer Bank ${order.bankName || ''}`}
              </p>
              <p className="text-slate-700 mt-1">
                <strong>Status Pesanan: </strong>
                <span className="font-bold text-blue-700">{order.status}</span>
              </p>
              {order.trackingNumber && (
                <p className="text-slate-700 mt-1">
                  <strong>No. Resi Pengiriman: </strong>
                  <span className="font-mono font-bold text-sky-700">{order.trackingNumber}</span>
                </p>
              )}
              {order.notes && (
                <p className="text-slate-500 italic mt-1 text-[11px]">
                  Catatan: "{order.notes}"
                </p>
              )}
            </div>
          </div>

          {/* Items Table */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-700 font-bold uppercase border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Judul Buku</th>
                  <th className="py-2.5 px-3 text-center">Jml</th>
                  <th className="py-2.5 px-3 text-right">Harga</th>
                  <th className="py-2.5 px-3 text-right">Subtotal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {order.items.map((item, idx) => (
                  <tr key={idx}>
                    <td className="py-3 px-3">
                      <p className="font-bold text-slate-900">{item.title}</p>
                      <p className="text-[11px] text-slate-500">{item.author}</p>
                    </td>
                    <td className="py-3 px-3 text-center font-semibold text-slate-800">
                      {item.quantity}
                    </td>
                    <td className="py-3 px-3 text-right text-slate-600">
                      {formatRupiah(item.price)}
                    </td>
                    <td className="py-3 px-3 text-right font-bold text-slate-900">
                      {formatRupiah(item.subtotal)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Subtotals & Grand Total */}
          <div className="flex justify-end">
            <div className="w-full sm:w-64 space-y-2 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>Subtotal Buku:</span>
                <span className="font-semibold">{formatRupiah(order.subtotal)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Ongkos Kirim:</span>
                <span className="font-semibold">{formatRupiah(order.shippingCost)}</span>
              </div>
              <div className="pt-2 border-t-2 border-slate-900 flex justify-between font-extrabold text-sm text-slate-900">
                <span>Total Tagihan:</span>
                <span className="text-blue-700">{formatRupiah(order.totalAmount)}</span>
              </div>
            </div>
          </div>

          {/* Bank Account info for transfers */}
          {order.paymentMethod === 'transfer_bank' && (
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs">
              <span className="font-bold text-slate-800 block mb-1">
                Rekening Resmi Pembayaran:
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px]">
                {settings?.bankAccounts?.map((b, idx) => (
                  <div key={idx} className="bg-white p-2 rounded-lg border border-slate-200">
                    <span className="font-bold text-slate-800">{b.bank}: </span>
                    <span className="font-mono text-blue-700 font-semibold">{b.number}</span>
                    <span className="block text-slate-500">a.n. {b.holder}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Footer note */}
          <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-400 gap-2 text-center sm:text-left">
            <span>Terima kasih telah mempercayakan pembelian buku Anda pada kami.</span>
            <span>Dicetak secara resmi oleh Sistem E-Katalog</span>
          </div>
        </div>
      </div>
    </div>
  );
};
