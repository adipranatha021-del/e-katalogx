import React from 'react';
import { TrendingUp, DollarSign, PieChart, CreditCard, ShoppingBag, ArrowUpRight } from 'lucide-react';
import { Order } from '../../types.ts';
import { formatRupiah, formatDateIndonesia } from '../../utils/formatters.ts';

interface AdminSalesViewProps {
  orders: Order[];
}

export const AdminSalesView: React.FC<AdminSalesViewProps> = ({ orders }) => {
  const completedOrActive = orders.filter((o) => o.status !== 'Dibatalkan');

  const totalOmset = completedOrActive.reduce((sum, o) => sum + o.totalAmount, 0);

  // Calculate total cost and profit
  let totalModal = 0;
  let totalUnitsSold = 0;

  completedOrActive.forEach((order) => {
    order.items.forEach((item) => {
      const unitCost = item.costPrice || 0;
      totalModal += unitCost * item.quantity;
      totalUnitsSold += item.quantity;
    });
  });

  const grossProfit = totalOmset - totalModal;
  const profitMarginPercent = totalOmset > 0 ? ((grossProfit / totalOmset) * 100).toFixed(1) : '0';
  const averageOrderValue = completedOrActive.length > 0 ? Math.round(totalOmset / completedOrActive.length) : 0;

  // Payment breakdown
  const transferBankCount = completedOrActive.filter((o) => o.paymentMethod === 'transfer_bank').length;
  const codCount = completedOrActive.filter((o) => o.paymentMethod === 'cod').length;

  return (
    <div className="space-y-6">
      {/* Financial Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Total Omset Penjualan
          </span>
          <h3 className="text-2xl font-extrabold text-blue-700 mt-1">
            {formatRupiah(totalOmset)}
          </h3>
          <p className="text-xs text-slate-500 mt-1">Dari {completedOrActive.length} transaksi sukses</p>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Total Harga Modal (HPP)
          </span>
          <h3 className="text-2xl font-extrabold text-slate-700 mt-1">
            {formatRupiah(totalModal)}
          </h3>
          <p className="text-xs text-slate-500 mt-1">{totalUnitsSold} unit buku fisik terjual</p>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Estimasi Laba Kotor
          </span>
          <h3 className="text-2xl font-extrabold text-emerald-600 mt-1">
            {formatRupiah(grossProfit)}
          </h3>
          <p className="text-xs text-emerald-600 font-semibold mt-1">
            Margin Keuntungan: {profitMarginPercent}%
          </p>
        </div>

        <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
            Rata-rata Order (AOV)
          </span>
          <h3 className="text-2xl font-extrabold text-slate-900 mt-1">
            {formatRupiah(averageOrderValue)}
          </h3>
          <p className="text-xs text-slate-500 mt-1">Per transaksi pelanggan</p>
        </div>
      </div>

      {/* Payment Method Distribution */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
        <h3 className="text-base font-extrabold text-slate-900 mb-3 flex items-center gap-2">
          <PieChart className="w-5 h-5 text-blue-600" />
          <span>Distribusi Metode Pembayaran</span>
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center">
                <CreditCard className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm text-slate-900">Transfer Bank</h4>
                <p className="text-xs text-slate-500">BCA, Mandiri, BRI</p>
              </div>
            </div>
            <span className="text-lg font-extrabold text-blue-700">
              {transferBankCount} Transaksi
            </span>
          </div>

          <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-extrabold text-sm text-slate-900">Bayar di Tempat (COD)</h4>
                <p className="text-xs text-slate-500">Tunai saat kurir tiba</p>
              </div>
            </div>
            <span className="text-lg font-extrabold text-amber-700">
              {codCount} Transaksi
            </span>
          </div>
        </div>
      </div>

      {/* Sales Transactions Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-extrabold text-base text-slate-900 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-blue-600" />
            <span>Rincian Transaksi Penjualan</span>
          </h3>
          <span className="text-xs text-slate-500">
            {completedOrActive.length} Transaksi Terhitung
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-600 uppercase font-bold border-b border-slate-200">
              <tr>
                <th className="py-3 px-4">Invoice & Tanggal</th>
                <th className="py-3 px-4">Pelanggan</th>
                <th className="py-3 px-4">Metode Bayar</th>
                <th className="py-3 px-4 text-center">Unit</th>
                <th className="py-3 px-4 text-right">Modal</th>
                <th className="py-3 px-4 text-right">Omset</th>
                <th className="py-3 px-4 text-right">Est. Laba</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {completedOrActive.map((order) => {
                let orderCost = 0;
                let units = 0;
                order.items.forEach((item) => {
                  orderCost += (item.costPrice || 0) * item.quantity;
                  units += item.quantity;
                });
                const orderProfit = order.totalAmount - orderCost;

                return (
                  <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                    <td className="py-3 px-4">
                      <span className="font-mono font-bold text-blue-700 block">
                        {order.orderCode}
                      </span>
                      <span className="text-[10px] text-slate-400">
                        {formatDateIndonesia(order.createdAt)}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-semibold text-slate-900 block">{order.customerName}</span>
                      <span className="text-[11px] text-slate-500">{order.customerCity}</span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="font-semibold text-slate-700">
                        {order.paymentMethod === 'cod' ? 'COD' : `Transfer ${order.bankName || ''}`}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center font-semibold">
                      {units}
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-slate-500">
                      {formatRupiah(orderCost)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900">
                      {formatRupiah(order.totalAmount)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-emerald-600">
                      +{formatRupiah(orderProfit)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
