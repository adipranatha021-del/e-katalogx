import React, { useState } from 'react';
import { FileBarChart2, Download, FileSpreadsheet, Calendar, CheckCircle } from 'lucide-react';
import { Book, Order, Customer } from '../../types.ts';
import { exportToCsv, formatRupiah, formatDateIndonesia } from '../../utils/formatters.ts';

interface AdminReportsViewProps {
  books: Book[];
  orders: Order[];
  customers: Customer[];
}

export const AdminReportsView: React.FC<AdminReportsViewProps> = ({
  books,
  orders,
  customers,
}) => {
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  // 1. Export Books to CSV
  const handleExportBooksCsv = () => {
    const headers = [
      'ID Buku',
      'ISBN',
      'Judul Buku',
      'Penulis',
      'Penerbit',
      'Tahun',
      'Kategori',
      'Harga Modal',
      'Harga Jual',
      'Stok Unit',
      'Status Aktif',
      'Tanggal Dibuat',
    ];

    const rows = books.map((b) => [
      b.id,
      b.isbn || '-',
      b.title,
      b.author,
      b.publisher,
      b.year,
      b.categoryName,
      b.costPrice || 0,
      b.sellPrice,
      b.stock,
      b.isActive ? 'Aktif' : 'Arsip',
      b.createdAt,
    ]);

    exportToCsv(`katalog-buku-${new Date().toISOString().slice(0, 10)}`, headers, rows);
    setDownloadSuccess('File CSV Katalog Buku berhasil diunduh.');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  // 2. Export Orders to CSV
  const handleExportOrdersCsv = () => {
    const headers = [
      'Nomor Invoice',
      'Nama Pemesan',
      'Nomor Telepon',
      'Alamat Pengiriman',
      'Kota',
      'Metode Pembayaran',
      'Status Pesanan',
      'Nomor Resi',
      'Subtotal Buku',
      'Ongkir',
      'Total Transaksi',
      'Jumlah Judul Buku',
      'Tanggal Pesanan (WITA)',
    ];

    const rows = orders.map((o) => [
      o.orderCode,
      o.customerName,
      o.customerPhone,
      o.customerAddress,
      o.customerCity,
      o.paymentMethod,
      o.status,
      o.trackingNumber || '-',
      o.subtotal,
      o.shippingCost,
      o.totalAmount,
      o.items.length,
      formatDateIndonesia(o.createdAt),
    ]);

    exportToCsv(`laporan-pesanan-${new Date().toISOString().slice(0, 10)}`, headers, rows);
    setDownloadSuccess('File CSV Riwayat Pesanan berhasil diunduh.');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  // 3. Export Sales Summary to CSV
  const handleExportSalesSummaryCsv = () => {
    const headers = [
      'Nomor Invoice',
      'Tanggal',
      'Judul Buku',
      'Kuantitas',
      'Harga Jual Satuan',
      'Harga Modal Satuan',
      'Total Omset Item',
      'Total Modal Item',
      'Laba Kotor Item',
    ];

    const rows: (string | number)[][] = [];

    orders
      .filter((o) => o.status !== 'Dibatalkan')
      .forEach((order) => {
        order.items.forEach((item) => {
          const omset = item.price * item.quantity;
          const modal = (item.costPrice || 0) * item.quantity;
          const laba = omset - modal;

          rows.push([
            order.orderCode,
            order.createdAt.slice(0, 10),
            item.title,
            item.quantity,
            item.price,
            item.costPrice || 0,
            omset,
            modal,
            laba,
          ]);
        });
      });

    exportToCsv(`laporan-penjualan-detail-${new Date().toISOString().slice(0, 10)}`, headers, rows);
    setDownloadSuccess('File CSV Laporan Detail Penjualan berhasil diunduh.');
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Download Alert */}
      {downloadSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-50 text-emerald-800 text-xs sm:text-sm font-semibold border border-emerald-200 flex items-center gap-2 animate-fadeIn">
          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{downloadSuccess}</span>
        </div>
      )}

      {/* Header */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200/80 shadow-xs">
        <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
          <FileBarChart2 className="w-5 h-5 text-blue-600" />
          <span>Laporan Penjualan & Ekspor Data (CSV)</span>
        </h3>
        <p className="text-xs text-slate-500 mt-1">
          Unduh laporan transaksi dan katalog untuk kebutuhan pembukuan, akuntansi, dan arsip offline
        </p>
      </div>

      {/* 3 Export Action Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        {/* Card 1 */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <h4 className="font-extrabold text-base text-slate-900 mb-1">
              Ekspor Katalog Buku
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed mb-6">
              Mengunduh seluruh data judul buku, ISBN, penulis, stok unit, harga modal, dan harga jual dalam format CSV.
            </p>
          </div>

          <button
            onClick={handleExportBooksCsv}
            className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-blue-600/20 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Unduh CSV Buku ({books.length} Item)</span>
          </button>
        </div>

        {/* Card 2 */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <h4 className="font-extrabold text-base text-slate-900 mb-1">
              Ekspor Riwayat Pesanan
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed mb-6">
              Daftar seluruh pesanan masuk, data pembeli, status pengiriman, nomor resi, dan total transaksi.
            </p>
          </div>

          <button
            onClick={handleExportOrdersCsv}
            className="w-full py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-emerald-600/20 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Unduh CSV Pesanan ({orders.length} Transaksi)</span>
          </button>
        </div>

        {/* Card 3 */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200/80 shadow-xs flex flex-col justify-between">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-sky-50 text-sky-600 flex items-center justify-center mb-4">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <h4 className="font-extrabold text-base text-slate-900 mb-1">
              Laporan Profit & Laba Detail
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed mb-6">
              Rincian item per buku dengan perhitungan omset, modal pokok (HPP), dan laba bersih per transaksi.
            </p>
          </div>

          <button
            onClick={handleExportSalesSummaryCsv}
            className="w-full py-2.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md shadow-sky-600/20 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Unduh CSV Laba Detail</span>
          </button>
        </div>
      </div>
    </div>
  );
};
