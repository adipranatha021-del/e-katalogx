import React, { useState, useEffect } from 'react';
import {
  Home,
  BookOpen,
  Tags,
  Boxes,
  ShoppingBag,
  Users,
  FileBarChart2,
  Settings,
  Database,
  LogOut,
  Menu,
  X,
  ExternalLink,
  Clock,
  User,
  ChevronDown,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';

export type AdminTab =
  | 'dashboard'
  | 'books'
  | 'categories'
  | 'stock'
  | 'orders'
  | 'customers'
  | 'sales'
  | 'reports'
  | 'settings'
  | 'backup';

interface AdminLayoutProps {
  currentTab: AdminTab;
  onSelectTab: (tab: AdminTab) => void;
  onExitToStore: () => void;
  newOrdersBadge?: number;
  lowStockBadge?: number;
  children: React.ReactNode;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  currentTab,
  onSelectTab,
  onExitToStore,
  newOrdersBadge = 0,
  lowStockBadge = 0,
  children,
}) => {
  const { logout } = useAuth();
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [witaTime, setWitaTime] = useState('');

  // Live WITA clock
  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      const formatted = new Intl.DateTimeFormat('id-ID', {
        timeZone: 'Asia/Makassar',
        weekday: 'short',
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        hour12: false,
      }).format(now);
      setWitaTime(`${formatted} WITA`);
    };

    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  // Menu items closely matching collage mockup
  const mainMenuItems = [
    { id: 'dashboard' as AdminTab, label: 'Beranda', icon: Home },
    { id: 'books' as AdminTab, label: 'Katalog Buku', icon: BookOpen },
    { id: 'categories' as AdminTab, label: 'Kategori PAUD', icon: Tags },
    {
      id: 'stock' as AdminTab,
      label: 'Stok Buku',
      icon: Boxes,
      badge: lowStockBadge > 0 ? lowStockBadge : undefined,
    },
    {
      id: 'orders' as AdminTab,
      label: 'Pesanan',
      icon: ShoppingBag,
      badge: newOrdersBadge > 0 ? newOrdersBadge : undefined,
    },
    { id: 'customers' as AdminTab, label: 'Pelanggan', icon: Users },
    { id: 'reports' as AdminTab, label: 'Laporan', icon: FileBarChart2 },
    { id: 'settings' as AdminTab, label: 'Pengaturan & Profil', icon: Settings },
    { id: 'backup' as AdminTab, label: 'Backup & Restore', icon: Database },
  ];

  const handleMenuClick = (tab: AdminTab) => {
    onSelectTab(tab);
    setIsMobileSidebarOpen(false);
  };

  const handleLogout = () => {
    if (window.confirm('Apakah Anda yakin ingin logout dari dashboard admin?')) {
      logout();
      onExitToStore();
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col lg:flex-row text-slate-800">
      {/* ========================================================= */}
      {/* DESKTOP SIDEBAR MATCHING COLLAGE MOCKUP (Deep Navy Blue)  */}
      {/* ========================================================= */}
      <aside className="hidden lg:flex flex-col w-60 bg-[#0f172a] text-slate-300 shrink-0 select-none border-r border-slate-900">
        {/* Brand Header */}
        <div className="h-18 px-6 flex items-center gap-3 border-b border-slate-800/80">
          <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h1 className="font-extrabold text-base tracking-tight text-white">E-Katalog</h1>
            <p className="text-[10px] text-blue-400 font-bold uppercase tracking-wider">
              Buku PAUD
            </p>
          </div>
        </div>

        {/* Navigation Menus matching collage mockup */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {mainMenuItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleMenuClick(item.id)}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-xs font-bold transition-all ${
                  isActive
                    ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.badge !== undefined && (
                  <span className="px-1.5 py-0.5 text-[10px] font-black bg-amber-500 text-white rounded-full">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Bottom Logout Button matching mockup */}
        <div className="p-3 border-t border-slate-800/80 space-y-2">
          <button
            onClick={onExitToStore}
            className="w-full py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-bold flex items-center justify-center gap-2 border border-slate-800 transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5 text-blue-400" />
            <span>Lihat Toko Publik</span>
          </button>

          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold text-slate-400 hover:text-rose-400 hover:bg-rose-950/30 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Logout</span>
          </button>
        </div>
      </aside>

      {/* ========================================================= */}
      {/* MOBILE HEADER & DRAWER                                    */}
      {/* ========================================================= */}
      <div className="lg:hidden bg-[#0f172a] text-white border-b border-slate-800 px-4 py-3 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsMobileSidebarOpen(true)}
            className="p-2 rounded-xl bg-slate-900 text-slate-300 hover:text-white"
            aria-label="Menu"
          >
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-blue-400" />
            <span className="font-extrabold text-sm tracking-tight text-white">E-KATALOG PAUD</span>
          </div>
        </div>

        <button
          onClick={onExitToStore}
          className="text-xs font-bold px-3 py-1.5 rounded-lg bg-blue-600 text-white flex items-center gap-1.5 shadow-xs"
        >
          <ExternalLink className="w-3 h-3" />
          <span>Katalog</span>
        </button>
      </div>

      {/* Mobile Drawer */}
      {isMobileSidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs"
            onClick={() => setIsMobileSidebarOpen(false)}
          />

          <div className="relative w-64 max-w-[80vw] bg-[#0f172a] text-slate-300 flex flex-col h-full border-r border-slate-900 shadow-2xl z-10 animate-slideLeft">
            <div className="p-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-blue-400" />
                <span className="font-extrabold text-sm text-white">E-Katalog Admin</span>
              </div>
              <button
                onClick={() => setIsMobileSidebarOpen(false)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
              {mainMenuItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleMenuClick(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-bold ${
                      isActive
                        ? 'bg-blue-600 text-white'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <Icon className="w-4 h-4" />
                      <span>{item.label}</span>
                    </div>
                  </button>
                );
              })}
            </nav>

            <div className="p-3 border-t border-slate-800">
              <button
                onClick={handleLogout}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold text-rose-400 hover:bg-rose-950/30"
              >
                <LogOut className="w-4 h-4" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MAIN ADMIN CONTENT AREA MATCHING COLLAGE MOCKUP           */}
      {/* ========================================================= */}
      <div className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        {/* Top Header Bar matching mockup: localhost/e-katalog & Admin dropdown */}
        <header className="bg-white border-b border-slate-200/90 px-6 sm:px-8 py-3.5 flex items-center justify-between gap-4 shadow-xs">
          {/* Breadcrumb / Location path matching mockup */}
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-400 font-mono">
            <span>app/e-katalog</span>
            <span>/</span>
            <span className="text-blue-600 font-bold uppercase">{currentTab}</span>
          </div>

          {/* Right: WITA Clock & Admin User Dropdown */}
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-50 border border-slate-200 text-xs font-semibold text-slate-600">
              <Clock className="w-3.5 h-3.5 text-blue-600" />
              <span className="font-mono">{witaTime || 'Asia/Makassar (WITA)'}</span>
            </div>

            {/* Admin Avatar & Dropdown matching mockup */}
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 text-slate-800 text-xs font-bold cursor-pointer hover:bg-slate-200 transition-colors">
              <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center text-[11px] font-bold">
                <User className="w-3.5 h-3.5" />
              </div>
              <span>Admin</span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </div>
          </div>
        </header>

        {/* View Body */}
        <main className="p-4 sm:p-8 flex-1">{children}</main>
      </div>
    </div>
  );
};
