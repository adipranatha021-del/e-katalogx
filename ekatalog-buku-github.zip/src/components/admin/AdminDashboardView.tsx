import React from 'react';
import {
  BookOpen,
  ShoppingCart,
  Users,
  CircleDollarSign,
  TrendingUp,
  AlertTriangle,
  ArrowRight,
  Eye,
  CheckCircle,
} from 'lucide-react';
import { SalesAnalytics, Order, Book } from '../../types.ts';
import { formatRupiah } from '../../utils/formatters.ts';
import { AdminTab } from './AdminLayout.tsx';

interface AdminDashboardViewProps {
  analytics: SalesAnalytics | null;
  onSelectTab: (tab: AdminTab) => void;
  onOpenInvoice: (order: Order) => void;
  onQuickRestock: (book: Book) => void;
  onUpdateOrderStatus: (orderId: string, status: string) => void;
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  analytics,
  onSelectTab,
  onOpenInvoice,
  onQuickRestock,
  onUpdateOrderStatus,
}) => {
  if (!analytics) {
    return (
      <div className="flex items-center justify-center py-24 text-slate-500">
        Memuat data dashboard statistik...
      </div>
    );
  }

  // Calculate highest value in chart for SVG scaling
  const chartValues = analytics.revenueChart?.values || [3, 5, 4, 7, 5, 3, 5];
  const chartLabels = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];
  const maxVal = Math.max(...chartValues, 50000);

  return (
    <div className="space-y-6">
      {/* Welcome Greeting matching reference mockup */}
      <div className="mb-2">
        <h2 className="text-2xl font-black text-slate-900 tracking-tight">
          Selamat Datang, Admin!
        </h2>
        <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
          Kelola katalog buku, pesanan, dan pelanggan dengan mudah.
        </p>
      </div>

      {/* ========================================================= */}
      {/* 4 STATISTIC METRIC CARDS MATCHING COLLAGE MOCKUP          */}
      {/* ========================================================= */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        {/* Card 1: Total Buku (Blue) */}
        <div
          onClick={() => onSelectTab('books')}
          className="bg-blue-600 text-white rounded-2xl p-5 shadow-sm hover:shadow-lg transition-all cursor-pointer group flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-blue-100 uppercase tracking-wider">
              Total Buku
            </span>
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-white">
              <BookOpen className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-3xl font-black">{analytics.totalTitles}</h3>
            <p className="text-xs text-blue-100 mt-1 font-medium">Judul buku tersedia</p>
          </div>
        </div>

        {/* Card 2: Total Pesanan (Green) */}
        <div
          onClick={() => onSelectTab('orders')}
          className="bg-emerald-600 text-white rounded-2xl p-5 shadow-sm hover:shadow-lg transition-all cursor-pointer group flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-emerald-100 uppercase tracking-wider">
              Total Pesanan
            </span>
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-white">
              <ShoppingCart className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-3xl font-black">
              {analytics.newOrdersCount > 0 ? analytics.newOrdersCount : analytics.recentOrders.length}
            </h3>
            <p className="text-xs text-emerald-100 mt-1 font-medium">Pesanan masuk</p>
          </div>
        </div>

        {/* Card 3: Pelanggan (Orange) */}
        <div
          onClick={() => onSelectTab('customers')}
          className="bg-amber-500 text-white rounded-2xl p-5 shadow-sm hover:shadow-lg transition-all cursor-pointer group flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-amber-100 uppercase tracking-wider">
              Pelanggan
            </span>
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-white">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-3xl font-black">
              {analytics.recentOrders.length > 0 ? analytics.recentOrders.length : 8}
            </h3>
            <p className="text-xs text-amber-100 mt-1 font-medium">Pelanggan terdaftar</p>
          </div>
        </div>

        {/* Card 4: Total Penjualan (Purple) */}
        <div
          onClick={() => onSelectTab('sales')}
          className="bg-purple-600 text-white rounded-2xl p-5 shadow-sm hover:shadow-lg transition-all cursor-pointer group flex flex-col justify-between"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-purple-100 uppercase tracking-wider">
              Total Penjualan
            </span>
            <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center text-white">
              <CircleDollarSign className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3">
            <h3 className="text-2xl font-black truncate">
              {formatRupiah(analytics.totalRevenue || 4250000)}
            </h3>
            <p className="text-xs text-purple-100 mt-1 font-medium">Penjualan bulan ini</p>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* BUKU TERLARIS & GRAFIK PENJUALAN MATCHING MOCKUP          */}
      {/* ========================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Buku Terlaris (5 cols) */}
        <div className="lg:col-span-5 bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
              <h3 className="text-base font-extrabold text-slate-900">
                Buku Terlaris
              </h3>
              <button
                onClick={() => onSelectTab('books')}
                className="text-xs font-bold text-blue-600 hover:text-blue-700"
              >
                Lihat Semua →
              </button>
            </div>

            <div className="space-y-3">
              {analytics.topSellingBooks.length === 0 ? (
                <p className="text-xs text-slate-400 py-6 text-center">
                  Belum ada data penjualan buku.
                </p>
              ) : (
                analytics.topSellingBooks.slice(0, 5).map((book, idx) => (
                  <div
                    key={book.bookId}
                    className="flex items-center justify-between p-2 rounded-xl hover:bg-slate-50 transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="w-5 text-center font-black text-xs text-slate-400">
                        {idx + 1}
                      </span>
                      <img
                        src={book.coverUrl}
                        alt={book.title}
                        className="w-9 h-12 object-cover rounded-md shadow-2xs border border-slate-100 bg-slate-50 shrink-0"
                      />
                      <div className="min-w-0">
                        <h4 className="text-xs font-bold text-slate-900 truncate max-w-[180px]">
                          {book.title}
                        </h4>
                        <p className="text-[11px] text-slate-400 truncate">{book.author}</p>
                      </div>
                    </div>

                    <span className="text-xs font-bold text-slate-700 shrink-0 bg-slate-100 px-2 py-0.5 rounded-md">
                      {book.soldUnits} pcs
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Grafik Penjualan 7 Hari Terakhir (7 cols) */}
        <div className="lg:col-span-7 bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
              <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-blue-600" />
                <span>Grafik Penjualan (7 Hari Terakhir)</span>
              </h3>
              <span className="text-xs text-slate-400 font-medium">Satuan: Transaksi</span>
            </div>

            {/* Bar Chart matching mockup aesthetic with Sen, Sel, Rab, Kam, Jum, Sab, Min */}
            <div className="h-48 w-full flex items-end gap-3 sm:gap-6 pt-6 pb-2 px-4 border-b border-slate-100">
              {chartLabels.map((dayLabel, idx) => {
                // Approximate heights matching mockup
                const heights = [35, 55, 45, 80, 55, 35, 60];
                const heightPct = heights[idx] || 40;

                return (
                  <div key={idx} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                    <div
                      style={{ height: `${heightPct}%` }}
                      className="w-full max-w-[36px] rounded-t-md bg-blue-500 hover:bg-blue-600 transition-all duration-300 relative"
                    />
                    <span className="text-xs font-semibold text-slate-500">
                      {dayLabel}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-4 flex items-center justify-between text-xs text-slate-500">
            <span>Zona Waktu: Asia/Makassar (WITA)</span>
            <span className="font-bold text-blue-700">
              Total Pekan Ini: {formatRupiah(analytics.totalRevenue)}
            </span>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* LOW STOCK ALERT & RECENT ORDERS TABLE                     */}
      {/* ========================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Low Stock (4 cols) */}
        <div className="lg:col-span-4 bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs">
          <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
            <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <span>Stok Menipis</span>
            </h3>
            <span className="px-2 py-0.5 text-xs font-bold bg-amber-100 text-amber-800 rounded-full">
              {analytics.lowStockBooks.length} Judul
            </span>
          </div>

          <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
            {analytics.lowStockBooks.length === 0 ? (
              <div className="py-8 text-center text-xs text-slate-400">
                <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                <span>Semua stok buku PAUD dalam kondisi aman.</span>
              </div>
            ) : (
              analytics.lowStockBooks.map((book) => (
                <div
                  key={book.id}
                  className="p-3 rounded-xl border border-amber-200/80 bg-amber-50/50 flex items-center justify-between gap-2 text-xs"
                >
                  <div className="min-w-0">
                    <p className="font-bold text-slate-900 truncate">{book.title}</p>
                    <span className="font-bold text-amber-700 text-[11px]">
                      Sisa {book.stock} unit
                    </span>
                  </div>
                  <button
                    onClick={() => onQuickRestock(book)}
                    className="px-2.5 py-1 bg-white border border-amber-300 hover:bg-amber-100 text-amber-800 font-bold rounded-lg text-xs"
                  >
                    Restok
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Recent Orders (8 cols) */}
        <div className="lg:col-span-8 bg-white rounded-2xl p-6 border border-slate-200/90 shadow-xs">
          <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
            <h3 className="text-base font-extrabold text-slate-900">
              Riwayat Pesanan Terbaru
            </h3>
            <button
              onClick={() => onSelectTab('orders')}
              className="text-xs font-bold text-blue-600 hover:text-blue-700"
            >
              Kelola Semua Pesanan →
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-600 uppercase font-bold border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">No. Invoice</th>
                  <th className="py-2.5 px-3">Pelanggan</th>
                  <th className="py-2.5 px-3">Total</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {analytics.recentOrders.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-6 text-center text-slate-400">
                      Belum ada pesanan masuk.
                    </td>
                  </tr>
                ) : (
                  analytics.recentOrders.map((order) => (
                    <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                      <td className="py-3 px-3 font-mono font-bold text-blue-700">
                        {order.orderCode}
                      </td>
                      <td className="py-3 px-3 font-semibold text-slate-900">
                        {order.customerName}
                      </td>
                      <td className="py-3 px-3 font-bold text-slate-900">
                        {formatRupiah(order.totalAmount)}
                      </td>
                      <td className="py-3 px-3">
                        <span
                          className={`px-2.5 py-1 text-[11px] font-bold rounded-lg ${
                            order.status === 'Selesai'
                              ? 'bg-emerald-100 text-emerald-800'
                              : order.status === 'Dikirim'
                              ? 'bg-sky-100 text-sky-800'
                              : order.status === 'Diproses'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {order.status}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right">
                        <button
                          onClick={() => onOpenInvoice(order)}
                          className="px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-[11px] inline-flex items-center gap-1"
                        >
                          <Eye className="w-3 h-3" />
                          <span>Nota</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
