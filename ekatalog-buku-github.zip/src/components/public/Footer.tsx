import React from 'react';
import { BookOpen, MapPin, Phone, Mail, Lock, ShieldCheck, Clock } from 'lucide-react';
import { AppSettings, Category } from '../../types.ts';
import { useCart } from '../../context/CartContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';

interface FooterProps {
  settings: Partial<AppSettings> | null;
  categories: Category[];
  onSelectCategory: (catId: string) => void;
  onNavigateToAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  settings,
  categories,
  onSelectCategory,
  onNavigateToAdmin,
}) => {
  const { openTracking } = useCart();
  const { isAdminAuthenticated, openLoginModal } = useAuth();

  return (
    <footer className="bg-slate-950 text-slate-400 border-t border-slate-900 pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 pb-10 border-b border-slate-800/80">
          {/* Store Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
                <BookOpen className="w-5 h-5" />
              </div>
              <span className="font-extrabold text-lg text-white tracking-tight">
                {settings?.storeName || 'E-KATALOG'}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
              {settings?.storeTagline ||
                'Pusat pemesanan dan katalog buku Indonesia terpercaya. Koleksi buku ber-ISBN original langsung ke tangan Anda.'}
            </p>
            <div className="space-y-2 text-xs">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <span>{settings?.storeAddress || 'Makassar, Sulawesi Selatan'}</span>
              </div>
              {settings?.storeEmail && (
                <div className="flex items-center gap-2">
                  <Mail className="w-4 h-4 text-sky-400 shrink-0" />
                  <span>{settings.storeEmail}</span>
                </div>
              )}
              {settings?.whatsappNumber && (
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>+{settings.whatsappNumber}</span>
                </div>
              )}
            </div>
          </div>

          {/* Quick Categories */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">
              Kategori Pilihan
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm">
              {categories.slice(0, 5).map((cat) => (
                <li key={cat.id}>
                  <button
                    onClick={() => {
                      onSelectCategory(cat.id);
                      window.scrollTo({ top: 400, behavior: 'smooth' });
                    }}
                    className="hover:text-blue-400 transition-colors text-left"
                  >
                    {cat.name}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Customer Support & Links */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">
              Layanan Pelanggan
            </h4>
            <ul className="space-y-2.5 text-xs sm:text-sm">
              <li>
                <button
                  onClick={openTracking}
                  className="hover:text-blue-400 transition-colors"
                >
                  Lacak Status Pesanan
                </button>
              </li>
              <li>
                <a
                  href={`https://wa.me/${settings?.whatsappNumber?.replace(/[^0-9]/g, '')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-emerald-400 transition-colors"
                >
                  Konsultasi Judul Buku (WhatsApp)
                </a>
              </li>
              <li>
                <span className="text-slate-500">Jaminan Buku 100% Original</span>
              </li>
              <li>
                <span className="text-slate-500">Pengiriman se-Indonesia</span>
              </li>
            </ul>
          </div>

          {/* Payment & Security */}
          <div>
            <h4 className="text-sm font-bold text-white uppercase tracking-wider mb-4">
              Metode Pembayaran
            </h4>
            <p className="text-xs text-slate-400 mb-3">
              Menerima transfer antar bank nasional dan Bayar di Tempat (COD).
            </p>
            <div className="flex flex-wrap gap-2">
              <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300 text-xs font-semibold">
                Bank BCA
              </span>
              <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300 text-xs font-semibold">
                Bank Mandiri
              </span>
              <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-slate-300 text-xs font-semibold">
                Bank BRI
              </span>
              <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-emerald-400 text-xs font-semibold">
                COD Tersedia
              </span>
            </div>

            <div className="mt-5 pt-4 border-t border-slate-900 flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <ShieldCheck className="w-4 h-4 text-emerald-500" />
                <span>Transaksi Terenkripsi</span>
              </div>

              {isAdminAuthenticated ? (
                <button
                  onClick={onNavigateToAdmin}
                  className="text-xs text-emerald-400 hover:text-emerald-300 font-semibold"
                >
                  Dashboard Admin →
                </button>
              ) : (
                <button
                  onClick={openLoginModal}
                  className="text-xs text-slate-500 hover:text-slate-300 flex items-center gap-1"
                >
                  <Lock className="w-3 h-3" />
                  <span>Portal Admin</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <p>© {new Date().getFullYear()} E-Katalog Buku Indonesia. Hak cipta dilindungi.</p>
          <div className="flex items-center gap-1.5 text-slate-400">
            <Clock className="w-3.5 h-3.5 text-blue-400" />
            <span>Zona Waktu: Asia/Makassar (WITA, UTC+8)</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
