import React, { useState } from 'react';
import {
  BookOpen,
  Search,
  ShoppingCart,
  Compass,
  Lock,
  Menu,
  X,
  PhoneCall,
  LayoutDashboard,
} from 'lucide-react';
import { useCart } from '../../context/CartContext.tsx';
import { useAuth } from '../../context/AuthContext.tsx';
import { AppSettings } from '../../types.ts';

interface NavbarProps {
  settings: Partial<AppSettings> | null;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  onNavigateToAdmin: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  settings,
  searchQuery,
  onSearchChange,
  onNavigateToAdmin,
}) => {
  const { totalItems, openCart, openTracking } = useCart();
  const { isAdminAuthenticated, openLoginModal } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-slate-900 border-b border-slate-800 text-white shadow-lg">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20 gap-4">
          {/* Logo & Store Name */}
          <div className="flex items-center gap-3 cursor-pointer select-none" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            {settings?.logoUrl ? (
              <img
                src={settings.logoUrl}
                alt={settings?.storeName || 'Logo'}
                className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl object-cover border border-blue-400/30 shadow-md shadow-blue-500/20"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            ) : (
              <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-tr from-blue-600 to-sky-400 flex items-center justify-center shadow-md shadow-blue-500/30">
                <BookOpen className="w-6 h-6 text-white" />
              </div>
            )}
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg sm:text-xl tracking-tight text-white">
                  {settings?.storeName || 'E-KATALOG PAUD'}
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 text-[10px] font-bold tracking-wider uppercase bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded-full">
                  Buku PAUD & TK
                </span>
              </div>
              <p className="text-xs text-slate-400 truncate max-w-[200px] sm:max-w-xs">
                {settings?.storeTagline || 'Katalog Resmi Buku Belajar Anak Usia Dini'}
              </p>
            </div>
          </div>

          {/* Desktop Search Bar */}
          <div className="hidden md:flex flex-1 max-w-md mx-4">
            <div className="relative w-full">
              <input
                type="text"
                placeholder="Cari judul buku, penulis, atau ISBN..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full bg-slate-800/90 text-slate-100 placeholder-slate-400 pl-10 pr-4 py-2 rounded-xl border border-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm transition-all"
              />
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
              {searchQuery && (
                <button
                  onClick={() => onSearchChange('')}
                  className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-white"
                >
                  ✕
                </button>
              )}
            </div>
          </div>

          {/* Desktop Actions */}
          <div className="hidden lg:flex items-center gap-3">
            {/* Lacak Pesanan */}
            <button
              onClick={openTracking}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors"
            >
              <Compass className="w-4 h-4 text-sky-400" />
              <span>Lacak Pesanan</span>
            </button>

            {/* Keranjang Belanja */}
            <button
              onClick={openCart}
              className="relative flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-sm shadow-md shadow-blue-600/30 transition-all active:scale-95"
            >
              <ShoppingCart className="w-4 h-4" />
              <span>Keranjang</span>
              {totalItems > 0 && (
                <span className="ml-1 px-2 py-0.5 text-xs font-bold bg-white text-blue-700 rounded-full animate-pulse">
                  {totalItems}
                </span>
              )}
            </button>

            <div className="h-6 w-px bg-slate-800 mx-1" />

            {/* Admin Switcher */}
            {isAdminAuthenticated ? (
              <button
                onClick={onNavigateToAdmin}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-600/30 font-medium text-sm transition-colors"
              >
                <LayoutDashboard className="w-4 h-4 text-emerald-400" />
                <span>Dashboard Admin</span>
              </button>
            ) : (
              <button
                onClick={openLoginModal}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-slate-400 hover:text-slate-200 hover:bg-slate-800 text-sm font-medium transition-colors"
                title="Masuk sebagai Administrator"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Admin</span>
              </button>
            )}
          </div>

          {/* Mobile Cart & Menu Toggle */}
          <div className="flex lg:hidden items-center gap-2">
            <button
              onClick={openCart}
              className="relative p-2.5 rounded-xl bg-blue-600 text-white"
              aria-label="Buka Keranjang"
            >
              <ShoppingCart className="w-5 h-5" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 px-1.5 py-0.5 text-[10px] font-bold bg-rose-500 text-white rounded-full">
                  {totalItems}
                </span>
              )}
            </button>

            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="p-2.5 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800"
              aria-label="Menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Search Input */}
        <div className="md:hidden pb-3 pt-1">
          <div className="relative w-full">
            <input
              type="text"
              placeholder="Cari judul buku atau penulis..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full bg-slate-800 text-slate-100 placeholder-slate-400 pl-9 pr-4 py-2 rounded-xl border border-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-white"
              >
                ✕
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-slate-900 border-t border-slate-800 px-4 pt-3 pb-6 space-y-3 animate-fadeIn">
          <button
            onClick={() => {
              setIsMobileMenuOpen(false);
              openTracking();
            }}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-200 hover:bg-slate-800 font-medium text-sm text-left"
          >
            <Compass className="w-5 h-5 text-sky-400" />
            <span>Lacak Status Pesanan</span>
          </button>

          {settings?.whatsappNumber && (
            <a
              href={`https://wa.me/${settings.whatsappNumber.replace(/[^0-9]/g, '')}`}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-200 hover:bg-slate-800 font-medium text-sm text-left"
            >
              <PhoneCall className="w-5 h-5 text-emerald-400" />
              <span>Hubungi CS WhatsApp</span>
            </a>
          )}

          <div className="pt-2 border-t border-slate-800">
            {isAdminAuthenticated ? (
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  onNavigateToAdmin();
                }}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-600 text-white font-semibold text-sm shadow-md"
              >
                <LayoutDashboard className="w-4 h-4" />
                <span>Masuk ke Dashboard Admin</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  openLoginModal();
                }}
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-sm"
              >
                <Lock className="w-4 h-4" />
                <span>Login Dashboard Admin</span>
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
