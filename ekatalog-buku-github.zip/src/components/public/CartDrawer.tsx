import React from 'react';
import { X, Trash2, ShoppingBag, ArrowRight, ShieldCheck } from 'lucide-react';
import { useCart } from '../../context/CartContext.tsx';
import { formatRupiah } from '../../utils/formatters.ts';

export const CartDrawer: React.FC = () => {
  const {
    cart,
    isCartOpen,
    closeCart,
    updateQuantity,
    removeFromCart,
    clearCart,
    subtotal,
    openCheckout,
  } = useCart();

  if (!isCartOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-slate-900/50 backdrop-blur-xs transition-opacity animate-fadeIn"
        onClick={closeCart}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col border-l border-slate-200 animate-slideLeft">
          {/* Header */}
          <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
            <div className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-blue-600" />
              <h2 className="text-base sm:text-lg font-extrabold text-slate-900">
                Keranjang Belanja
              </h2>
              <span className="px-2 py-0.5 text-xs font-bold bg-blue-100 text-blue-700 rounded-full">
                {cart.length} item
              </span>
            </div>

            <div className="flex items-center gap-2">
              {cart.length > 0 && (
                <button
                  onClick={clearCart}
                  className="text-xs text-rose-500 hover:text-rose-700 font-medium px-2 py-1 rounded"
                  title="Kosongkan keranjang"
                >
                  Kosongkan
                </button>
              )}
              <button
                onClick={closeCart}
                className="w-8 h-8 rounded-full bg-slate-200/60 hover:bg-slate-200 flex items-center justify-center text-slate-500 hover:text-slate-700 transition-colors"
                aria-label="Tutup Keranjang"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Cart Items List */}
          <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 divide-y divide-slate-100">
            {cart.length === 0 ? (
              <div className="text-center py-16">
                <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-400 flex items-center justify-center mx-auto mb-4">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h3 className="text-base font-bold text-slate-800 mb-1">
                  Keranjang belanja masih kosong
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 max-w-xs mx-auto mb-6">
                  Pilih buku favorit Anda dari katalog dan tambahkan ke keranjang untuk memesan.
                </p>
                <button
                  onClick={closeCart}
                  className="px-5 py-2.5 rounded-xl bg-blue-600 text-white font-semibold text-xs sm:text-sm shadow-md shadow-blue-600/20 hover:bg-blue-500"
                >
                  Jelajahi Katalog Buku
                </button>
              </div>
            ) : (
              cart.map(({ book, quantity }) => (
                <div key={book.id} className="pt-4 first:pt-0 flex gap-3 sm:gap-4">
                  {/* Thumbnail */}
                  <img
                    src={book.coverUrl}
                    alt={book.title}
                    className="w-16 h-22 object-cover rounded-xl shadow-xs border border-slate-100 shrink-0 bg-slate-50"
                  />

                  {/* Details */}
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <h4 className="font-bold text-slate-900 text-xs sm:text-sm line-clamp-1">
                        {book.title}
                      </h4>
                      <p className="text-[11px] text-slate-500 line-clamp-1">{book.author}</p>
                      <p className="text-xs font-extrabold text-blue-700 mt-1">
                        {formatRupiah(book.sellPrice)}
                      </p>
                    </div>

                    <div className="flex items-center justify-between mt-2">
                      {/* Quantity stepper */}
                      <div className="flex items-center border border-slate-200 rounded-lg overflow-hidden bg-slate-50">
                        <button
                          onClick={() => updateQuantity(book.id, quantity - 1)}
                          className="px-2 py-0.5 text-slate-600 hover:bg-slate-200 text-xs font-bold"
                          aria-label="Kurangi"
                        >
                          -
                        </button>
                        <span className="px-2.5 py-0.5 text-xs font-bold text-slate-800 bg-white">
                          {quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(book.id, quantity + 1)}
                          disabled={quantity >= book.stock}
                          className={`px-2 py-0.5 text-xs font-bold ${
                            quantity >= book.stock
                              ? 'text-slate-300 cursor-not-allowed'
                              : 'text-slate-600 hover:bg-slate-200'
                          }`}
                          aria-label="Tambah"
                        >
                          +
                        </button>
                      </div>

                      {/* Remove item */}
                      <button
                        onClick={() => removeFromCart(book.id)}
                        className="text-slate-400 hover:text-rose-600 p-1 transition-colors"
                        title="Hapus buku"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer Subtotal & Checkout */}
          {cart.length > 0 && (
            <div className="p-4 sm:p-5 border-t border-slate-100 bg-slate-50 space-y-3">
              <div className="flex items-center justify-between text-xs sm:text-sm text-slate-600">
                <span>Subtotal Buku</span>
                <span className="font-bold text-slate-900">{formatRupiah(subtotal)}</span>
              </div>
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span>Estimasi Ongkir</span>
                <span className="font-medium text-emerald-600">Flat Rp 15.000</span>
              </div>
              <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-sm sm:text-base font-extrabold text-slate-900">
                <span>Total Estimasi</span>
                <span className="text-blue-700">{formatRupiah(subtotal + 15000)}</span>
              </div>

              <button
                onClick={openCheckout}
                className="w-full py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 transition-all active:scale-98"
              >
                <span>Lanjut ke Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Validasi stok dan pembayaran aman terjamin</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
