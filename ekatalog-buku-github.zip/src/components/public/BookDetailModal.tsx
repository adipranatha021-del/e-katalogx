import React, { useState } from 'react';
import {
  X,
  ShoppingCart,
  MessageCircle,
  Star,
  CheckCircle2,
  AlertTriangle,
  Bookmark,
  Building,
  Calendar,
  Hash,
  ArrowLeft,
  Share2,
} from 'lucide-react';
import { Book, AppSettings } from '../../types.ts';
import { formatRupiah, buildWhatsAppUrl } from '../../utils/formatters.ts';
import { useCart } from '../../context/CartContext.tsx';

interface BookDetailModalProps {
  book: Book | null;
  settings?: Partial<AppSettings> | null;
  onClose: () => void;
}

export const BookDetailModal: React.FC<BookDetailModalProps> = ({ book, settings, onClose }) => {
  const { addToCart, openCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  const [justAdded, setJustAdded] = useState(false);

  if (!book) return null;

  const isOutOfStock = book.stock <= 0;
  const isLowStock = book.stock > 0 && book.stock <= (book.minStockAlert || 5);
  const catalogNum = book.catalogNumber ? `No. ${book.catalogNumber}` : 'PAUD';

  // WhatsApp order link as per user specification:
  // "Halo, saya tertarik dengan buku katalog No. 002 — Mengenal Angka. Mohon informasi ketersediaan dan cara pemesanannya."
  const waPhone = settings?.whatsappNumber || '6281234567890';
  const waText = `Halo, saya tertarik dengan buku katalog ${catalogNum} — ${book.title} (Jumlah: ${quantity} buku). Mohon informasi ketersediaan dan cara pemesanannya.`;
  const waUrl = buildWhatsAppUrl(waPhone, waText);

  const handleAddToCart = () => {
    if (isOutOfStock) return;
    addToCart(book, quantity);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1500);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-fadeIn">
      <div
        className="relative bg-white rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl border border-slate-200 animate-scaleUp my-6"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Control Bar matching mockup: <- Kembali ke katalog */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:text-blue-800 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Kembali ke katalog</span>
          </button>

          <div className="flex items-center gap-2">
            <span className="font-mono text-xs font-black bg-blue-100 text-blue-800 px-2.5 py-0.5 rounded-md">
              Katalog {catalogNum}
            </span>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-200/70 hover:bg-slate-200 text-slate-500 flex items-center justify-center"
              aria-label="Tutup"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Body matching reference mockup */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 p-6 sm:p-8">
          {/* Big Cover on Left (5 cols) */}
          <div className="md:col-span-5 flex flex-col items-center">
            <div className="relative aspect-[3/4] w-full max-w-[280px] rounded-2xl overflow-hidden shadow-xl border border-slate-100 bg-slate-50">
              <img
                src={book.coverUrl}
                alt={book.title}
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=600&q=80';
                }}
              />
              <span className="absolute top-2.5 left-2.5 px-2.5 py-1 text-xs font-black bg-blue-600 text-white rounded-lg shadow-sm">
                {catalogNum}
              </span>
            </div>

            {book.ageGroup && (
              <span className="mt-3 inline-block px-3 py-1 bg-amber-50 text-amber-800 border border-amber-200 rounded-full text-xs font-bold">
                Rekomendasi: {book.ageGroup}
              </span>
            )}
          </div>

          {/* Details on Right (7 cols) */}
          <div className="md:col-span-7 flex flex-col justify-between">
            <div>
              <p className="text-xs font-bold text-blue-600 uppercase tracking-wider mb-1">
                {book.categoryName}
              </p>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 leading-tight">
                {book.title}
              </h2>
              <p className="text-xs text-slate-500 mt-1 font-medium">Penulis: {book.author}</p>

              {/* Price in Bright Blue */}
              <div className="mt-3 mb-2">
                <span className="text-2xl sm:text-3xl font-black text-blue-600">
                  {formatRupiah(book.sellPrice)}
                </span>
              </div>

              {/* Rating stars matching mockup: ★★★★★ (4.8) 12 ulasan */}
              <div className="flex items-center gap-1.5 text-xs text-slate-600 mb-3">
                <div className="flex text-amber-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <span className="font-bold text-slate-800">
                  ({book.rating ? book.rating.toFixed(1) : '4.9'})
                </span>
                <span className="text-slate-400">
                  {book.reviewCount || 24} ulasan pembeli
                </span>
              </div>

              {/* Stock Available Status with green icon matching mockup */}
              <div className="mb-4">
                {isOutOfStock ? (
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-rose-50 text-rose-700 text-xs font-bold">
                    <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                    <span>Stok buku saat ini sedang habis</span>
                  </div>
                ) : isLowStock ? (
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-amber-50 text-amber-800 text-xs font-bold animate-pulse">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                    <span>Stok menipis: tersisa {book.stock} unit</span>
                  </div>
                ) : (
                  <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Stok tersedia: {book.stock} unit</span>
                  </div>
                )}
              </div>

              {/* Description */}
              <div className="mb-4">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-1">
                  Deskripsi Buku
                </h4>
                <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-h-36 overflow-y-auto pr-2">
                  {book.description}
                </p>
              </div>

              {/* Metadata Pills */}
              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-500 bg-slate-50 p-2.5 rounded-xl border border-slate-200/70 mb-5">
                <div className="flex items-center gap-1">
                  <Building className="w-3.5 h-3.5 text-slate-400" />
                  <span className="truncate">{book.publisher}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>Tahun {book.year}</span>
                </div>
              </div>
            </div>

            {/* Bottom Actions: Stepper and Buttons */}
            <div className="space-y-3 pt-3 border-t border-slate-100">
              {!isOutOfStock && (
                <div className="flex items-center gap-3">
                  <span className="text-xs font-bold text-slate-700">Jumlah:</span>
                  <div className="flex items-center border border-slate-300 rounded-xl overflow-hidden bg-slate-50">
                    <button
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="px-3 py-1 text-slate-600 hover:bg-slate-200 font-bold text-xs"
                      disabled={quantity <= 1}
                    >
                      -
                    </button>
                    <span className="px-3 py-1 text-xs font-bold text-slate-800 bg-white min-w-[32px] text-center">
                      {quantity}
                    </span>
                    <button
                      onClick={() => setQuantity(Math.min(book.stock, quantity + 1))}
                      className="px-3 py-1 text-slate-600 hover:bg-slate-200 font-bold text-xs"
                      disabled={quantity >= book.stock}
                    >
                      +
                    </button>
                  </div>
                </div>
              )}

              {/* Buttons: WhatsApp Direct and Cart */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <a
                  href={waUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-md shadow-emerald-600/30 transition-all active:scale-98"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Pesan via WhatsApp</span>
                </a>

                <button
                  type="button"
                  onClick={handleAddToCart}
                  disabled={isOutOfStock}
                  className={`py-3 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                    isOutOfStock
                      ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                      : justAdded
                      ? 'bg-blue-800 text-white'
                      : 'bg-blue-600 hover:bg-blue-500 text-white shadow-md shadow-blue-600/30 active:scale-98'
                  }`}
                >
                  {justAdded ? (
                    <>
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Berhasil Ditambahkan</span>
                    </>
                  ) : (
                    <>
                      <ShoppingCart className="w-4 h-4" />
                      <span>Masukkan Keranjang</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
