import React, { useState, useMemo } from 'react';
import { SlidersHorizontal, ArrowUpDown, BookOpenCheck, RotateCcw, Sparkles } from 'lucide-react';
import { Book, Category, AppSettings } from '../../types.ts';
import { BookCard } from './BookCard.tsx';

interface BookGridProps {
  books: Book[];
  categories: Category[];
  selectedCategoryId: string;
  onSelectCategory: (catId: string) => void;
  searchQuery: string;
  settings?: Partial<AppSettings> | null;
  onOpenDetail: (book: Book) => void;
}

export const BookGrid: React.FC<BookGridProps> = ({
  books,
  categories,
  selectedCategoryId,
  onSelectCategory,
  searchQuery,
  settings,
  onOpenDetail,
}) => {
  const [onlyInStock, setOnlyInStock] = useState(false);
  const [sortBy, setSortBy] = useState<'number-asc' | 'price-asc' | 'price-desc' | 'title-asc'>('number-asc');
  const [maxPrice, setMaxPrice] = useState<number>(100000);
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);

  // Highest price in PAUD books
  const highestPrice = useMemo(() => {
    if (books.length === 0) return 50000;
    return Math.max(...books.map((b) => b.sellPrice));
  }, [books]);

  // Filtered & Sorted books
  const filteredBooks = useMemo(() => {
    return books
      .filter((book) => {
        if (!book.isActive) return false;

        // Category filter
        if (selectedCategoryId !== 'all' && book.categoryId !== selectedCategoryId) {
          return false;
        }

        // Search query (checks title, author, catalog number, and isbn)
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchTitle = book.title.toLowerCase().includes(q);
          const matchAuthor = book.author.toLowerCase().includes(q);
          const matchNumber = book.catalogNumber ? book.catalogNumber.toLowerCase().includes(q) : false;
          const matchIsbn = book.isbn ? book.isbn.toLowerCase().includes(q) : false;
          if (!matchTitle && !matchAuthor && !matchNumber && !matchIsbn) return false;
        }

        // In-stock filter
        if (onlyInStock && book.stock <= 0) {
          return false;
        }

        // Price filter
        if (book.sellPrice > maxPrice) {
          return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'number-asc') {
          const numA = parseInt(a.catalogNumber || '0', 10);
          const numB = parseInt(b.catalogNumber || '0', 10);
          return numA - numB;
        }
        if (sortBy === 'price-asc') return a.sellPrice - b.sellPrice;
        if (sortBy === 'price-desc') return b.sellPrice - a.sellPrice;
        if (sortBy === 'title-asc') return a.title.localeCompare(b.title);
        return 0;
      });
  }, [books, selectedCategoryId, searchQuery, onlyInStock, maxPrice, sortBy]);

  const handleResetFilters = () => {
    onSelectCategory('all');
    setOnlyInStock(false);
    setMaxPrice(highestPrice > 0 ? highestPrice : 100000);
    setSortBy('number-asc');
  };

  const isFiltered =
    selectedCategoryId !== 'all' ||
    onlyInStock ||
    (highestPrice > 0 && maxPrice < highestPrice) ||
    searchQuery.trim().length > 0;

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
      {/* Category Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-5">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-bold mb-2">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>Katalog Resmi Pembelajaran PAUD</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Katalog Buku PAUD & TK
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Buku pengenalan huruf, angka, mewarnai, dan motorik halus berkualitas tinggi siap kirim
          </p>
        </div>

        {/* Mobile Filter Toggle */}
        <button
          onClick={() => setIsFilterPanelOpen(!isFilterPanelOpen)}
          className="sm:hidden flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold"
        >
          <SlidersHorizontal className="w-3.5 h-3.5" />
          <span>Pengaturan Filter</span>
        </button>
      </div>

      {/* Category Pills Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none mb-6">
        <button
          onClick={() => onSelectCategory('all')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold shrink-0 transition-all ${
            selectedCategoryId === 'all'
              ? 'bg-blue-600 text-white shadow-md shadow-blue-600/25'
              : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          Semua Kategori PAUD
        </button>

        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => onSelectCategory(cat.id)}
            className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold shrink-0 transition-all ${
              selectedCategoryId === cat.id
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/25'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            {cat.name}
            {cat.bookCount !== undefined && (
              <span
                className={`ml-1.5 px-1.5 py-0.5 rounded-full text-[10px] ${
                  selectedCategoryId === cat.id
                    ? 'bg-white/20 text-white'
                    : 'bg-slate-100 text-slate-500'
                }`}
              >
                {cat.bookCount}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Filter and Sorting Control Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-4 mb-8 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Left: Summary & In Stock Toggle */}
        <div className="flex flex-wrap items-center gap-4">
          <span className="text-xs sm:text-sm font-semibold text-slate-700">
            Menampilkan <strong className="text-blue-700">{filteredBooks.length}</strong> buku
            {searchQuery && (
              <span className="ml-1 text-blue-600 font-semibold">
                pencarian "{searchQuery}"
              </span>
            )}
          </span>

          <label className="flex items-center gap-2 cursor-pointer select-none text-xs font-semibold text-slate-700 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-100 transition-colors">
            <input
              type="checkbox"
              checked={onlyInStock}
              onChange={(e) => setOnlyInStock(e.target.checked)}
              className="rounded text-blue-600 focus:ring-blue-500 w-4 h-4"
            />
            <span>Hanya Stok Tersedia</span>
          </label>
        </div>

        {/* Right: Sorting & Reset */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Sort Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 text-xs text-slate-700">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-transparent text-slate-700 font-semibold focus:outline-none cursor-pointer text-xs"
            >
              <option value="number-asc">Nomor Katalog (001 - 999)</option>
              <option value="price-asc">Harga Terendah</option>
              <option value="price-desc">Harga Tertinggi</option>
              <option value="title-asc">Judul A - Z</option>
            </select>
          </div>

          {/* Reset Filters */}
          {isFiltered && (
            <button
              onClick={handleResetFilters}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold text-rose-600 bg-rose-50 hover:bg-rose-100 transition-colors"
              title="Reset semua filter"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset Filter</span>
            </button>
          )}
        </div>
      </div>

      {/* Book Grid Cards matching 4-column reference */}
      {filteredBooks.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {filteredBooks.map((book) => (
            <BookCard
              key={book.id}
              book={book}
              settings={settings}
              onOpenDetail={onOpenDetail}
            />
          ))}
        </div>
      ) : (
        /* Empty State */
        <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8 shadow-xs">
          <div className="w-16 h-16 rounded-2xl bg-blue-50 text-blue-400 flex items-center justify-center mx-auto mb-4">
            <BookOpenCheck className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-extrabold text-slate-800 mb-1">
            Buku PAUD tidak ditemukan
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto mb-6">
            Coba ganti kata kunci pencarian atau pilih kategori materi PAUD lainnya.
          </p>
          <button
            onClick={handleResetFilters}
            className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold shadow-md shadow-blue-600/20"
          >
            Tampilkan Semua Buku PAUD
          </button>
        </div>
      )}
    </section>
  );
};
