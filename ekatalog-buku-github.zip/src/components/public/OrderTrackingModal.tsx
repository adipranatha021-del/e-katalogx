import React, { useState } from 'react';
import {
  X,
  Search,
  Compass,
  Package,
  Truck,
  CheckCircle2,
  Clock,
  AlertCircle,
  MessageSquare,
  Copy,
  Check,
} from 'lucide-react';
import { useCart } from '../../context/CartContext.tsx';
import { api } from '../../services/api.ts';
import { formatRupiah, formatDateIndonesia, buildWhatsAppUrl } from '../../utils/formatters.ts';
import { Order, OrderStatus, AppSettings } from '../../types.ts';

interface OrderTrackingModalProps {
  settings: Partial<AppSettings> | null;
}

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({ settings }) => {
  const { isTrackingOpen, closeTracking } = useCart();
  const [query, setQuery] = useState('');
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copiedResi, setCopiedResi] = useState<string | null>(null);

  if (!isTrackingOpen) return null;

  const handleTrack = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setIsLoading(true);
    setError(null);
    setOrders(null);

    try {
      const results = await api.trackOrder(query.trim());
      setOrders(results);
    } catch (err: any) {
      setError(err.message || 'Pesanan tidak ditemukan.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyResi = (resi: string) => {
    navigator.clipboard.writeText(resi);
    setCopiedResi(resi);
    setTimeout(() => setCopiedResi(null), 2000);
  };

  // Helper for status timeline steps
  const getTimelineStep = (status: OrderStatus) => {
    switch (status) {
      case 'Menunggu Konfirmasi':
        return 1;
      case 'Menunggu Pembayaran':
        return 2;
      case 'Diproses':
        return 3;
      case 'Dikirim':
        return 4;
      case 'Selesai':
        return 5;
      case 'Dibatalkan':
        return -1;
      default:
        return 1;
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div
        className="relative bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-200 animate-scaleUp my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-sky-500 flex items-center justify-center text-white">
              <Compass className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg">
                Lacak Status Pesanan
              </h3>
              <p className="text-xs text-slate-400">
                Periksa perkembangan pesanan buku Anda secara real-time
              </p>
            </div>
          </div>

          <button
            onClick={closeTracking}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 space-y-6">
          {/* Tracking Form */}
          <form onSubmit={handleTrack} className="flex gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="Masukkan Kode Pesanan (INV-...) atau No. HP Anda"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3.5" />
            </div>
            <button
              type="submit"
              disabled={isLoading || !query.trim()}
              className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:bg-slate-300 text-white font-semibold text-xs sm:text-sm shadow-md shadow-blue-600/20"
            >
              {isLoading ? 'Mencari...' : 'Cari'}
            </button>
          </form>

          {/* Error */}
          {error && (
            <div className="p-4 rounded-xl bg-rose-50 text-rose-800 text-xs sm:text-sm border border-rose-200 flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-rose-500 mt-0.5 shrink-0" />
              <div>
                <p className="font-semibold">Data Tidak Ditemukan</p>
                <p className="text-slate-600 text-xs mt-0.5">{error}</p>
              </div>
            </div>
          )}

          {/* Results List */}
          {orders && orders.length > 0 && (
            <div className="space-y-6 max-h-[60vh] overflow-y-auto pr-1">
              {orders.map((order) => {
                const currentStep = getTimelineStep(order.status);
                const isCancelled = order.status === 'Dibatalkan';

                return (
                  <div
                    key={order.id}
                    className="p-5 rounded-2xl border border-slate-200 bg-slate-50/70 space-y-4"
                  >
                    {/* Top bar */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-200">
                      <div>
                        <span className="font-mono text-xs sm:text-sm font-extrabold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                          {order.orderCode}
                        </span>
                        <p className="text-[11px] text-slate-500 mt-1">
                          Waktu Pesan: {formatDateIndonesia(order.createdAt)}
                        </p>
                      </div>

                      <div>
                        <span
                          className={`px-3 py-1 text-xs font-bold rounded-full ${
                            order.status === 'Selesai'
                              ? 'bg-emerald-100 text-emerald-800'
                              : order.status === 'Dikirim'
                              ? 'bg-sky-100 text-sky-800'
                              : order.status === 'Diproses'
                              ? 'bg-blue-100 text-blue-800'
                              : order.status === 'Dibatalkan'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {order.status}
                        </span>
                      </div>
                    </div>

                    {/* Timeline visualization */}
                    {!isCancelled ? (
                      <div className="py-2">
                        <div className="grid grid-cols-4 gap-1 text-center text-[10px] sm:text-xs">
                          <div className="flex flex-col items-center">
                            <div
                              className={`w-7 h-7 rounded-full flex items-center justify-center font-bold mb-1 ${
                                currentStep >= 1
                                  ? 'bg-blue-600 text-white'
                                  : 'bg-slate-200 text-slate-500'
                              }`}
                            >
                              <Clock className="w-3.5 h-3.5" />
                            </div>
                            <span className="font-semibold text-slate-800">Diterima</span>
                          </div>

                          <div className="flex flex-col items-center">
                            <div
                              className={`w-7 h-7 rounded-full flex items-center justify-center font-bold mb-1 ${
                                currentStep >= 3
                                  ? 'bg-blue-600 text-white'
                                  : 'bg-slate-200 text-slate-500'
                              }`}
                            >
                              <Package className="w-3.5 h-3.5" />
                            </div>
                            <span className="font-semibold text-slate-800">Diproses</span>
                          </div>

                          <div className="flex flex-col items-center">
                            <div
                              className={`w-7 h-7 rounded-full flex items-center justify-center font-bold mb-1 ${
                                currentStep >= 4
                                  ? 'bg-blue-600 text-white'
                                  : 'bg-slate-200 text-slate-500'
                              }`}
                            >
                              <Truck className="w-3.5 h-3.5" />
                            </div>
                            <span className="font-semibold text-slate-800">Dikirim</span>
                          </div>

                          <div className="flex flex-col items-center">
                            <div
                              className={`w-7 h-7 rounded-full flex items-center justify-center font-bold mb-1 ${
                                currentStep >= 5
                                  ? 'bg-emerald-600 text-white'
                                  : 'bg-slate-200 text-slate-500'
                              }`}
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                            </div>
                            <span className="font-semibold text-slate-800">Selesai</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="p-3 rounded-xl bg-rose-50 text-rose-700 text-xs font-semibold text-center">
                        Pesanan ini telah dibatalkan.
                      </div>
                    )}

                    {/* Resi Tracking if shipped */}
                    {order.trackingNumber && (
                      <div className="p-3 bg-sky-50 rounded-xl border border-sky-200 flex items-center justify-between text-xs">
                        <div>
                          <span className="text-slate-600">Nomor Resi Pengiriman:</span>
                          <span className="ml-2 font-mono font-bold text-sky-800">
                            {order.trackingNumber}
                          </span>
                        </div>
                        <button
                          onClick={() => handleCopyResi(order.trackingNumber!)}
                          className="px-2 py-1 rounded-md bg-white text-sky-700 font-semibold border border-sky-300 flex items-center gap-1 hover:bg-sky-100"
                        >
                          {copiedResi === order.trackingNumber ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-600" />
                              <span>Disalin</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Salin Resi</span>
                            </>
                          )}
                        </button>
                      </div>
                    )}

                    {/* Items List */}
                    <div className="divide-y divide-slate-200 bg-white p-3 rounded-xl border border-slate-200/80">
                      {order.items.map((item, idx) => (
                        <div key={idx} className="py-2 first:pt-0 last:pb-0 flex items-center justify-between text-xs">
                          <div>
                            <p className="font-bold text-slate-900">{item.title}</p>
                            <p className="text-[11px] text-slate-500">{item.author} x {item.quantity}</p>
                          </div>
                          <span className="font-bold text-slate-800">{formatRupiah(item.subtotal)}</span>
                        </div>
                      ))}
                    </div>

                    {/* Total & Action */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-2">
                      <div className="text-xs">
                        <span className="text-slate-500">Total Transaksi: </span>
                        <strong className="text-blue-700 text-sm font-extrabold">
                          {formatRupiah(order.totalAmount)}
                        </strong>
                      </div>

                      {settings?.whatsappNumber && (
                        <a
                          href={buildWhatsAppUrl(
                            settings.whatsappNumber,
                            `Halo Admin E-Katalog, saya ingin menanyakan status pesanan saya dengan nomor ${order.orderCode}.`
                          )}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>Tanya Status via WA</span>
                        </a>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
