import React from 'react';
import { Eye, MessageCircle, Sparkles } from 'lucide-react';
import { Book, AppSettings } from '../../types.ts';
import { formatRupiah, buildWhatsAppUrl } from '../../utils/formatters.ts';

interface BookCardProps {
  book: Book;
  settings?: Partial<AppSettings> | null;
  onOpenDetail: (book: Book) => void;
}

export const BookCard: React.FC<BookCardProps> = ({ book, settings, onOpenDetail }) => {
  const isOutOfStock = book.stock <= 0;
  const isLowStock = book.stock > 0 && book.stock <= (book.minStockAlert || 5);
  const formattedCatalogNumber = book.catalogNumber ? `No. ${book.catalogNumber}` : 'PAUD';

  // WhatsApp automated message as specified by user:
  // "Halo, saya tertarik dengan buku katalog No. 002 — Mengenal Angka. Mohon informasi ketersediaan dan cara pemesanannya."
  const waPhone = settings?.whatsappNumber || '6281234567890';
  const waText = `Halo, saya tertarik dengan buku katalog ${formattedCatalogNumber} — ${book.title}. Mohon informasi ketersediaan dan cara pemesanannya.`;
  const waUrl = buildWhatsAppUrl(waPhone, waText);

  return (
    <div
      onClick={() => onOpenDetail(book)}
      className="group relative bg-white rounded-2xl border border-slate-200/90 shadow-xs hover:shadow-xl hover:border-blue-400 transition-all duration-300 flex flex-col overflow-hidden cursor-pointer"
    >
      {/* Cover Image Container */}
      <div className="relative aspect-[3/4] w-full bg-slate-100 overflow-hidden">
        <img
          src={book.coverUrl}
          alt={book.title}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          onError={(e) => {
            (e.target as HTMLImageElement).src =
              'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=600&q=80';
          }}
        />

        {/* Catalog Number Badge (Top Left) - Unique & Stable */}
        <div className="absolute top-2.5 left-2.5">
          <span className="px-2.5 py-1 text-xs font-black bg-blue-600 text-white rounded-lg shadow-md tracking-wider">
            {formattedCatalogNumber}
          </span>
        </div>

        {/* Stock / Availability Badge (Top Right) */}
        <div className="absolute top-2.5 right-2.5">
          {isOutOfStock ? (
            <span className="px-2.5 py-1 text-[11px] font-bold uppercase bg-rose-600/90 text-white rounded-lg backdrop-blur-xs shadow-xs">
              Stok Habis
            </span>
          ) : isLowStock ? (
            <span className="px-2.5 py-1 text-[11px] font-bold bg-amber-500/90 text-white rounded-lg backdrop-blur-xs shadow-xs animate-pulse">
              Sisa {book.stock}
            </span>
          ) : (
            <span className="px-2.5 py-1 text-[11px] font-semibold bg-emerald-600/90 text-white rounded-lg backdrop-blur-xs shadow-xs">
              Stok: {book.stock}
            </span>
          )}
        </div>

        {/* Age Group Tag if available */}
        {book.ageGroup && (
          <div className="absolute bottom-2.5 left-2.5">
            <span className="px-2 py-0.5 text-[10px] font-bold bg-slate-900/80 backdrop-blur-md text-amber-300 rounded-md">
              {book.ageGroup}
            </span>
          </div>
        )}
      </div>

      {/* Book Metadata */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <span className="text-[11px] font-bold text-blue-600 uppercase tracking-wider block mb-0.5">
            {book.categoryName}
          </span>
          <h3 className="font-extrabold text-slate-900 text-sm sm:text-base leading-snug line-clamp-2 group-hover:text-blue-600 transition-colors">
            {book.title}
          </h3>
          <p className="text-xs text-slate-500 mt-1 line-clamp-1">{book.author}</p>
        </div>

        <div className="mt-4 pt-3 border-t border-slate-100 space-y-3">
          {/* Price display */}
          <div className="flex items-baseline justify-between">
            <span className="text-[11px] text-slate-400 font-medium">Harga</span>
            <span className="text-base sm:text-lg font-black text-blue-700">
              {formatRupiah(book.sellPrice)}
            </span>
          </div>

          {/* Action Buttons matching reference mockup: Detail & WhatsApp */}
          <div className="grid grid-cols-2 gap-2">
            {/* Detail Button */}
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onOpenDetail(book);
              }}
              className="py-2 px-3 rounded-xl border border-blue-600 text-blue-600 hover:bg-blue-50 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Detail</span>
            </button>

            {/* WhatsApp Direct Inquiry Button */}
            <a
              href={waUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={(e) => e.stopPropagation()}
              className="py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm shadow-emerald-600/30 transition-all active:scale-95"
              title="Pesan langsung lewat WhatsApp"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>Pesan WA</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
