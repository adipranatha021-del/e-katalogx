import React from 'react';
import { MessageCircle } from 'lucide-react';
import { buildWhatsAppUrl } from '../../utils/formatters.ts';

interface FloatingWhatsAppProps {
  whatsappNumber?: string;
  storeName?: string;
}

export const FloatingWhatsApp: React.FC<FloatingWhatsAppProps> = ({
  whatsappNumber,
  storeName = 'E-Katalog',
}) => {
  if (!whatsappNumber) return null;

  const url = buildWhatsAppUrl(
    whatsappNumber,
    `Halo ${storeName}, saya sedang melihat katalog buku dan ingin berkonsultasi mengenai pemesanan buku.`
  );

  return (
    <div className="fixed bottom-6 right-6 z-40">
      <a
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat WhatsApp Penjual"
        className="group relative flex items-center justify-center w-14 h-14 rounded-full bg-emerald-500 hover:bg-emerald-600 text-white shadow-xl shadow-emerald-500/30 transition-all duration-300 hover:scale-110 active:scale-95"
      >
        {/* Pulse ring */}
        <span className="absolute -inset-1 rounded-full bg-emerald-400 opacity-30 group-hover:opacity-60 animate-ping pointer-events-none" />

        <MessageCircle className="w-7 h-7 relative z-10" />

        {/* Hover Tooltip */}
        <div className="absolute right-16 px-3 py-1.5 rounded-xl bg-slate-900 text-white text-xs font-semibold whitespace-nowrap shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
          Tanya Penjual via WhatsApp
        </div>
      </a>
    </div>
  );
};
