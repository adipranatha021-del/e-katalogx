import React, { useState } from 'react';
import {
  Sparkles,
  BookOpen,
  MapPin,
  Clock,
  Phone,
  User,
  MessageCircle,
  Palette,
  Binary,
  Type,
  Smile,
  Share2,
  Copy,
  Check,
} from 'lucide-react';
import { AppSettings } from '../../types.ts';
import { buildWhatsAppUrl } from '../../utils/formatters.ts';

interface HeroBannerProps {
  settings: Partial<AppSettings> | null;
  totalBooksCount: number;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ settings, totalBooksCount }) => {
  const [copiedLink, setCopiedLink] = useState(false);

  const waUrl = settings?.whatsappNumber
    ? buildWhatsAppUrl(
        settings.whatsappNumber,
        `Halo ${settings.storeName || 'Pustaka PAUD'}, saya ingin menanyakan koleksi buku PAUD yang tersedia.`
      )
    : '#';

  const storeTitle = settings?.storeName || 'Katalog Buku PAUD';
  const shareText = `Halo Ayah, Bunda & Pengajar PAUD! 📚\n\nYuk cek koleksi buku belajar anak usia dini, belajar huruf, berhitung, mewarnai, dan stimulasi motorik di link katalog resmi ${storeTitle}:\n\n${window.location.origin}\n\nPesan langsung ketersediaan buku lewat WhatsApp!`;
  const shareWaUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(shareText)}`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.origin);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-slate-950 via-slate-900 to-blue-950 text-white border-b border-slate-800">
      {/* Decorative background blurs */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/4 -mb-20 w-80 h-80 bg-sky-500/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Store Profile & Headline (7 cols) */}
          <div className="lg:col-span-7">
            {/* Store Profile Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/15 border border-blue-400/30 text-blue-300 text-xs font-bold mb-4 backdrop-blur-md">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>{settings?.storeName || 'Katalog Buku PAUD Ceria'}</span>
            </div>

            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight leading-tight">
              Katalog Buku Belajar <br className="hidden sm:inline" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-sky-300 to-amber-200">
                Pendidikan Anak Usia Dini
              </span>
            </h1>

            <p className="mt-3 sm:mt-4 text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl">
              {settings?.storeTagline ||
                'Pusat buku materi belajar PAUD & TK: pengenalan huruf abjad, angka ceria, mewarnai, serta stimulasi motorik anak.'}
            </p>

            {/* Store Information Cards (Address, Hours, Owner, WhatsApp) */}
            <div className="mt-6 p-4 rounded-2xl bg-slate-900/80 border border-slate-800 text-xs space-y-2 backdrop-blur-md">
              {settings?.ownerName && (
                <div className="flex items-center gap-2 text-slate-300">
                  <User className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                  <span>Pengelola: <strong className="text-white">{settings.ownerName}</strong></span>
                </div>
              )}

              {settings?.storeAddress && (
                <div className="flex items-start gap-2 text-slate-300">
                  <MapPin className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>{settings.storeAddress}</span>
                </div>
              )}

              <div className="flex flex-wrap items-center gap-4 text-slate-300 pt-1">
                {settings?.operatingHours && (
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-sky-400 shrink-0" />
                    <span>{settings.operatingHours}</span>
                  </div>
                )}

                {settings?.whatsappNumber && (
                  <a
                    href={waUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 font-bold text-emerald-400 hover:text-emerald-300"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>+{settings.whatsappNumber} (Klik untuk chat WA)</span>
                  </a>
                )}
              </div>
            </div>

            {/* WhatsApp Group Share & Copy Link Action Bar */}
            <div className="mt-4 flex flex-wrap items-center gap-2.5">
              <a
                href={shareWaUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-emerald-600/30 transition-all active:scale-95"
                title="Bagikan link katalog ke WhatsApp Grup Sekolah / Orang Tua"
              >
                <Share2 className="w-4 h-4" />
                <span>Bagikan Katalog ke Grup WhatsApp</span>
              </a>

              <button
                type="button"
                onClick={handleCopyLink}
                className="py-2.5 px-3.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition-all active:scale-95"
              >
                {copiedLink ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-300">Link Tersalin!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-300" />
                    <span>Salin Link</span>
                  </>
                )}
              </button>
            </div>

            {/* Quick PAUD Highlights */}
            <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-2.5 rounded-xl bg-blue-900/30 border border-blue-700/40 flex items-center gap-2">
                <Type className="w-4 h-4 text-sky-300 shrink-0" />
                <span className="text-[11px] font-bold text-slate-200">Huruf & Membaca</span>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-900/30 border border-blue-700/40 flex items-center gap-2">
                <Binary className="w-4 h-4 text-amber-300 shrink-0" />
                <span className="text-[11px] font-bold text-slate-200">Angka & Berhitung</span>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-900/30 border border-blue-700/40 flex items-center gap-2">
                <Palette className="w-4 h-4 text-rose-300 shrink-0" />
                <span className="text-[11px] font-bold text-slate-200">Mewarnai & Kreasi</span>
              </div>
              <div className="p-2.5 rounded-xl bg-blue-900/30 border border-blue-700/40 flex items-center gap-2">
                <Smile className="w-4 h-4 text-emerald-300 shrink-0" />
                <span className="text-[11px] font-bold text-slate-200">{totalBooksCount} Judul Ready</span>
              </div>
            </div>
          </div>

          {/* Right Column: Visual PAUD Banner Card (5 cols) */}
          <div className="lg:col-span-5 hidden sm:block">
            <div className="relative rounded-3xl overflow-hidden border-2 border-blue-500/30 shadow-2xl bg-gradient-to-tr from-blue-900 to-indigo-950 p-2 group">
              <img
                src={
                  settings?.bannerUrl ||
                  'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=800&q=80'
                }
                alt="Banner Buku PAUD"
                className="w-full h-72 sm:h-80 object-cover rounded-2xl group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-transparent to-transparent flex flex-col justify-end p-6">
                <span className="px-2.5 py-1 rounded-md bg-blue-600 text-white text-[11px] font-bold w-fit mb-1.5 shadow-md">
                  Katalog PAUD Pilihan
                </span>
                <h3 className="font-extrabold text-lg text-white">
                  Generasi Cerdas & Mandiri
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Mudah dipesan langsung via WhatsApp resmi toko
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
