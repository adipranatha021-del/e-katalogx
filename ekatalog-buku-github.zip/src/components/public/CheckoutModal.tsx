import React, { useState } from 'react';
import {
  X,
  CheckCircle,
  Copy,
  Check,
  CreditCard,
  Truck,
  MessageSquare,
  AlertCircle,
  Loader2,
  FileText,
  Compass,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useCart } from '../../context/CartContext.tsx';
import { api } from '../../services/api.ts';
import { formatRupiah, buildWhatsAppUrl } from '../../utils/formatters.ts';
import { AppSettings, Order, PaymentMethod } from '../../types.ts';

interface CheckoutModalProps {
  settings: Partial<AppSettings> | null;
  onOrderSuccess: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({ settings, onOrderSuccess }) => {
  const { cart, isCheckoutOpen, closeCheckout, clearCart, subtotal, openTracking } = useCart();

  // Form states
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [customerCity, setCustomerCity] = useState('Makassar');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('transfer_bank');
  const [selectedBank, setSelectedBank] = useState<string>('BCA');
  const [notes, setNotes] = useState('');

  // Submission state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!isCheckoutOpen) return null;

  const shippingCost = settings?.shippingFlatRate ?? 15000;
  const grandTotal = subtotal + shippingCost;

  const handleCopyAccount = (number: string, idx: number) => {
    navigator.clipboard.writeText(number);
    setCopiedIndex(idx);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    // Validation
    if (!customerName.trim() || !customerPhone.trim() || !customerAddress.trim() || !customerCity.trim()) {
      setErrorMessage('Mohon lengkapi Nama, Nomor HP/WA, Alamat, dan Kota.');
      return;
    }

    if (cart.length === 0) {
      setErrorMessage('Keranjang belanja kosong.');
      return;
    }

    setIsSubmitting(true);

    try {
      const orderPayload = {
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        customerAddress: customerAddress.trim(),
        customerCity: customerCity.trim(),
        paymentMethod,
        bankName: paymentMethod === 'transfer_bank' ? selectedBank : undefined,
        notes: notes.trim(),
        items: cart.map((item) => ({
          bookId: item.book.id,
          quantity: item.quantity,
        })),
      };

      const order = await api.createOrder(orderPayload);

      // Trigger Confetti Celebration
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });

      setCreatedOrder(order);
      clearCart();
      onOrderSuccess();
    } catch (err: any) {
      setErrorMessage(err.message || 'Gagal memproses pesanan. Periksa stok atau koneksi internet.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleClose = () => {
    setCreatedOrder(null);
    setErrorMessage(null);
    closeCheckout();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 animate-fadeIn">
      <div
        className="relative bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-200 animate-scaleUp my-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center text-white">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base sm:text-lg">
                {createdOrder ? 'Pesanan Berhasil Dibuat!' : 'Konfirmasi & Checkout'}
              </h3>
              <p className="text-xs text-slate-400">
                {createdOrder
                  ? `Kode Transaksi: ${createdOrder.orderCode}`
                  : 'Lengkapi data pemesan dan pilih metode pembayaran'}
              </p>
            </div>
          </div>

          <button
            onClick={handleClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        {createdOrder ? (
          /* SUCCESS STATE */
          <div className="p-6 sm:p-8 space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-3 shadow-sm">
                <CheckCircle className="w-10 h-10" />
              </div>
              <h4 className="text-xl font-extrabold text-slate-900">
                Terima Kasih, {createdOrder.customerName}!
              </h4>
              <p className="text-sm text-slate-600 mt-1 max-w-md mx-auto">
                Pesanan Anda telah dicatat oleh sistem dengan nomor invoice{' '}
                <strong className="text-blue-700 bg-blue-50 px-2 py-0.5 rounded font-mono">
                  {createdOrder.orderCode}
                </strong>
                .
              </p>
            </div>

            {/* Payment instructions */}
            <div className="bg-slate-50 rounded-2xl p-4 sm:p-5 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between text-sm font-semibold text-slate-800 pb-2 border-b border-slate-200">
                <span>Total yang Harus Dibayar:</span>
                <span className="text-lg font-extrabold text-blue-700">
                  {formatRupiah(createdOrder.totalAmount)}
                </span>
              </div>

              {createdOrder.paymentMethod === 'transfer_bank' ? (
                <div>
                  <p className="text-xs font-semibold text-slate-700 mb-2">
                    Silakan transfer tepat sesuai nominal ke salah satu rekening toko:
                  </p>
                  <div className="space-y-2">
                    {settings?.bankAccounts?.map((acc, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between bg-white p-2.5 rounded-xl border border-slate-200 text-xs"
                      >
                        <div>
                          <span className="font-bold text-slate-900">{acc.bank}</span>
                          <span className="mx-2 text-slate-400">|</span>
                          <span className="font-mono text-blue-700 font-semibold">{acc.number}</span>
                          <span className="text-slate-500 block text-[11px]">a.n. {acc.holder}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleCopyAccount(acc.number, idx)}
                          className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1 transition-colors"
                        >
                          {copiedIndex === idx ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-600" />
                              <span className="text-emerald-600">Disalin</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Salin</span>
                            </>
                          )}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-amber-50 rounded-xl text-amber-800 text-xs flex items-center gap-2">
                  <Truck className="w-4 h-4 text-amber-600 shrink-0" />
                  <span>
                    Metode COD (Bayar di Tempat). Siapkan uang pas sebesar{' '}
                    <strong>{formatRupiah(createdOrder.totalAmount)}</strong> saat kurir tiba.
                  </span>
                </div>
              )}
            </div>

            {/* Action buttons */}
            <div className="space-y-3 pt-2">
              {/* WhatsApp direct confirmation button */}
              {settings?.whatsappNumber && (
                <a
                  href={buildWhatsAppUrl(
                    settings.whatsappNumber,
                    `Halo Admin E-Katalog, saya telah membuat pesanan dengan nomor ${createdOrder.orderCode} atas nama ${createdOrder.customerName}. Mohon bantu konfirmasi dan proses pesanan saya. Terima kasih!`
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 transition-all"
                >
                  <MessageSquare className="w-4 h-4" />
                  <span>Konfirmasi Pembayaran via WhatsApp</span>
                </a>
              )}

              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => {
                    handleClose();
                    openTracking();
                  }}
                  className="py-2.5 px-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Compass className="w-4 h-4 text-blue-600" />
                  <span>Lacak Pesanan</span>
                </button>

                <button
                  onClick={handleClose}
                  className="py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs sm:text-sm flex items-center justify-center transition-colors shadow-sm"
                >
                  Selesai
                </button>
              </div>
            </div>
          </div>
        ) : (
          /* FORM CHECKOUT */
          <form onSubmit={handleSubmitOrder} className="p-6 sm:p-8 space-y-5">
            {errorMessage && (
              <div className="p-3.5 rounded-xl bg-rose-50 text-rose-800 text-xs sm:text-sm font-medium border border-rose-200 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Customer Information */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                1. Data Pengiriman Pemesan
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">
                    Nama Lengkap <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Muhammad Fajrin"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">
                    Nomor WhatsApp / HP <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="tel"
                    required
                    placeholder="Contoh: 081234567890"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="text-xs font-semibold text-slate-700 block mb-1">
                    Alamat Lengkap Pengiriman <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Nama jalan, nomor rumah, RT/RW, kelurahan, kecamatan"
                    value={customerAddress}
                    onChange={(e) => setCustomerAddress(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">
                    Kota / Kabupaten <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Makassar"
                    value={customerCity}
                    onChange={(e) => setCustomerCity(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">
                  Catatan untuk Penjual (Opsional)
                </label>
                <input
                  type="text"
                  placeholder="Contoh: Tolong bungkus bubble wrap tebal / kirim siang"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Payment Method */}
            <div className="space-y-3 pt-3 border-t border-slate-100">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                2. Metode Pembayaran
              </h4>

              <div className="grid grid-cols-2 gap-3">
                <label
                  className={`p-3 rounded-2xl border cursor-pointer flex flex-col gap-1 transition-all ${
                    paymentMethod === 'transfer_bank'
                      ? 'border-blue-600 bg-blue-50/50 ring-2 ring-blue-500/20'
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                      <CreditCard className="w-4 h-4 text-blue-600" />
                      <span>Transfer Bank</span>
                    </span>
                    <input
                      type="radio"
                      name="paymentMethod"
                      checked={paymentMethod === 'transfer_bank'}
                      onChange={() => setPaymentMethod('transfer_bank')}
                      className="text-blue-600 focus:ring-blue-500"
                    />
                  </div>
                  <span className="text-[11px] text-slate-500">
                    BCA, Mandiri, atau BRI resmi
                  </span>
                </label>

                {settings?.enableCod && (
                  <label
                    className={`p-3 rounded-2xl border cursor-pointer flex flex-col gap-1 transition-all ${
                      paymentMethod === 'cod'
                        ? 'border-blue-600 bg-blue-50/50 ring-2 ring-blue-500/20'
                        : 'border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                        <Truck className="w-4 h-4 text-blue-600" />
                        <span>Bayar di Tempat (COD)</span>
                      </span>
                      <input
                        type="radio"
                        name="paymentMethod"
                        checked={paymentMethod === 'cod'}
                        onChange={() => setPaymentMethod('cod')}
                        className="text-blue-600 focus:ring-blue-500"
                      />
                    </div>
                    <span className="text-[11px] text-slate-500">
                      Bayar tunai saat kurir tiba
                    </span>
                  </label>
                )}
              </div>

              {paymentMethod === 'transfer_bank' && (
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-2">
                  <label className="font-semibold text-slate-700 block">
                    Pilih Tujuan Bank Transfer:
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {settings?.bankAccounts?.map((b) => (
                      <button
                        key={b.bank}
                        type="button"
                        onClick={() => setSelectedBank(b.bank)}
                        className={`px-3 py-1.5 rounded-lg font-bold text-xs transition-all ${
                          selectedBank === b.bank
                            ? 'bg-blue-600 text-white shadow-xs'
                            : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {b.bank}
                      </button>
                    ))}
                  </div>
                  <p className="text-[11px] text-slate-500 italic">
                    * Nomor rekening dan instruksi pembayaran akan ditampilkan langsung setelah pesanan dikonfirmasi.
                  </p>
                </div>
              )}
            </div>

            {/* Order Items Summary */}
            <div className="space-y-2 pt-3 border-t border-slate-100">
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                3. Ringkasan Belanja ({cart.length} item)
              </h4>

              <div className="max-h-36 overflow-y-auto divide-y divide-slate-100 bg-slate-50 rounded-xl p-3 border border-slate-200/80">
                {cart.map(({ book, quantity }) => (
                  <div key={book.id} className="py-1.5 first:pt-0 last:pb-0 flex items-center justify-between text-xs">
                    <span className="font-medium text-slate-800 truncate max-w-[280px]">
                      {book.title} <span className="text-slate-400 font-normal">x{quantity}</span>
                    </span>
                    <span className="font-bold text-slate-900 shrink-0">
                      {formatRupiah(book.sellPrice * quantity)}
                    </span>
                  </div>
                ))}
              </div>

              <div className="pt-2 space-y-1 text-xs">
                <div className="flex items-center justify-between text-slate-600">
                  <span>Subtotal Buku:</span>
                  <span className="font-semibold">{formatRupiah(subtotal)}</span>
                </div>
                <div className="flex items-center justify-between text-slate-600">
                  <span>Ongkos Kirim (Flat):</span>
                  <span className="font-semibold">{formatRupiah(shippingCost)}</span>
                </div>
                <div className="flex items-center justify-between text-sm sm:text-base font-extrabold text-slate-900 pt-1 border-t border-slate-200">
                  <span>Total Tagihan:</span>
                  <span className="text-blue-700">{formatRupiah(grandTotal)}</span>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={isSubmitting || cart.length === 0}
                className="w-full py-3.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:bg-slate-300 text-white font-bold text-sm shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition-all active:scale-98"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Memproses & Mengamankan Stok...</span>
                  </>
                ) : (
                  <span>Konfirmasi & Buat Pesanan ({formatRupiah(grandTotal)})</span>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
