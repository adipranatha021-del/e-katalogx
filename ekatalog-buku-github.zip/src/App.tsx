import React, { useState, useEffect, useCallback } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { CartProvider, useCart } from './context/CartContext.tsx';
import { api } from './services/api.ts';
import {
  Book,
  Category,
  Order,
  Customer,
  StockMovement,
  AppSettings,
  SalesAnalytics,
} from './types.ts';

// Public Components
import { Navbar } from './components/public/Navbar.tsx';
import { HeroBanner } from './components/public/HeroBanner.tsx';
import { BookGrid } from './components/public/BookGrid.tsx';
import { BookDetailModal } from './components/public/BookDetailModal.tsx';
import { CartDrawer } from './components/public/CartDrawer.tsx';
import { CheckoutModal } from './components/public/CheckoutModal.tsx';
import { OrderTrackingModal } from './components/public/OrderTrackingModal.tsx';
import { FloatingWhatsApp } from './components/public/FloatingWhatsApp.tsx';
import { Footer } from './components/public/Footer.tsx';

// Admin Components
import { AdminLayout, AdminTab } from './components/admin/AdminLayout.tsx';
import { AdminDashboardView } from './components/admin/AdminDashboardView.tsx';
import { AdminBooksView } from './components/admin/AdminBooksView.tsx';
import { AdminCategoriesView } from './components/admin/AdminCategoriesView.tsx';
import { AdminStockView } from './components/admin/AdminStockView.tsx';
import { AdminOrdersView } from './components/admin/AdminOrdersView.tsx';
import { AdminCustomersView } from './components/admin/AdminCustomersView.tsx';
import { AdminSalesView } from './components/admin/AdminSalesView.tsx';
import { AdminReportsView } from './components/admin/AdminReportsView.tsx';
import { AdminSettingsView } from './components/admin/AdminSettingsView.tsx';
import { AdminBackupView } from './components/admin/AdminBackupView.tsx';
import { InvoiceModal } from './components/admin/InvoiceModal.tsx';
import { AdminLoginModal } from './components/admin/AdminLoginModal.tsx';

function MainApplication() {
  const { isAdminAuthenticated, isLoginModalOpen } = useAuth();
  const { selectedBookForDetail, closeBookDetail } = useCart();

  // Navigation mode ('public' or 'admin')
  const [viewMode, setViewMode] = useState<'public' | 'admin'>(() => {
    if (window.location.pathname.startsWith('/admin') || window.location.hash === '#admin') {
      return 'admin';
    }
    return 'public';
  });

  const [adminTab, setAdminTab] = useState<AdminTab>('dashboard');

  // Core Data States
  const [books, setBooks] = useState<Book[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [stockMovements, setStockMovements] = useState<StockMovement[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [analytics, setAnalytics] = useState<SalesAnalytics | null>(null);

  // Filters for public store
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategoryId, setSelectedCategoryId] = useState('all');

  // Modals for admin
  const [activeInvoiceOrder, setActiveInvoiceOrder] = useState<Order | null>(null);
  const [quickRestockBook, setQuickRestockBook] = useState<Book | null>(null);

  // Sync browser URL with view mode
  useEffect(() => {
    const handlePopState = () => {
      if (window.location.pathname.startsWith('/admin') || window.location.hash === '#admin') {
        setViewMode('admin');
      } else {
        setViewMode('public');
      }
    };
    window.addEventListener('popstate', handlePopState);
    window.addEventListener('hashchange', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
      window.removeEventListener('hashchange', handlePopState);
    };
  }, []);

  // 1. PUBLIC DATA FETCH (Runs for all visitors, requires zero auth, never fails with 403)
  const fetchPublicData = useCallback(async () => {
    try {
      const [fetchedBooks, fetchedCategories, fetchedConfig] = await Promise.all([
        api.getBooks({ include_archived: false }),
        api.getCategories(),
        api.getConfig(),
      ]);

      setBooks(fetchedBooks);
      setCategories(fetchedCategories);
      setSettings(fetchedConfig as AppSettings);
    } catch (err) {
      console.error('Error fetching public catalog data:', err);
    }
  }, []);

  // 2. ADMIN DATA FETCH (Runs only for authenticated admins)
  const fetchAdminData = useCallback(async () => {
    try {
      const [
        fetchedBooks,
        fetchedCategories,
        fetchedOrders,
        fetchedCustomers,
        fetchedStockMovements,
        fetchedSettings,
        fetchedAnalytics,
      ] = await Promise.all([
        api.getBooks({ include_archived: true }),
        api.getCategories(),
        api.getOrders(),
        api.getCustomers(),
        api.getStockMovements(),
        api.getSettings(),
        api.getAnalytics('daily'),
      ]);

      setBooks(fetchedBooks);
      setCategories(fetchedCategories);
      setOrders(fetchedOrders);
      setCustomers(fetchedCustomers);
      setStockMovements(fetchedStockMovements);
      setSettings(fetchedSettings);
      setAnalytics(fetchedAnalytics);
    } catch (err) {
      console.error('Error fetching admin dashboard data:', err);
    }
  }, []);

  // Initial and reactive data loader
  useEffect(() => {
    if (viewMode === 'admin' && isAdminAuthenticated) {
      fetchAdminData();
    } else {
      fetchPublicData();
    }
  }, [viewMode, isAdminAuthenticated, fetchAdminData, fetchPublicData]);

  // Navigate to Admin handler
  const handleNavigateToAdmin = () => {
    setViewMode('admin');
    window.location.hash = 'admin';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleExitToStore = () => {
    setViewMode('public');
    window.location.hash = '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
    fetchPublicData();
  };

  // Quick Restock shortcut
  const handleQuickRestock = (book: Book) => {
    setQuickRestockBook(book);
    setAdminTab('stock');
    setViewMode('admin');
  };

  // Quick order status change
  const handleUpdateOrderStatus = async (orderId: string, status: string) => {
    try {
      await api.updateOrderStatus(orderId, { status });
      fetchAdminData();
    } catch (err: any) {
      console.error('Gagal mengubah status pesanan:', err);
    }
  };

  // Badges for Admin Sidebar
  const newOrdersCount = orders.filter(
    (o) => o.status === 'Menunggu Konfirmasi' || o.status === 'Menunggu Pembayaran'
  ).length;

  const lowStockCount = books.filter(
    (b) => b.isActive && b.stock <= (b.minStockAlert || settings?.lowStockThreshold || 5)
  ).length;

  return (
    <div className="min-h-screen bg-slate-50 font-sans text-slate-800 flex flex-col selection:bg-blue-600 selection:text-white">
      {viewMode === 'public' ? (
        /* ========================================================= */
        /* 1. PUBLIC STOREFRONT (Dapat Diakses Bebas Oleh Siapa Saja)*/
        /* ========================================================= */
        <div className="flex-1 flex flex-col">
          {/* Top Navbar */}
          <Navbar
            settings={settings}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            onNavigateToAdmin={handleNavigateToAdmin}
          />

          {/* Hero Banner with Store Profile & Preschool Theme */}
          <HeroBanner
            settings={settings}
            totalBooksCount={books.filter((b) => b.isActive).length}
          />

          {/* Book Catalog Section with WhatsApp Buttons */}
          <main className="flex-1">
            <BookGrid
              books={books}
              categories={categories}
              selectedCategoryId={selectedCategoryId}
              onSelectCategory={setSelectedCategoryId}
              searchQuery={searchQuery}
              settings={settings}
              onOpenDetail={(book) => {
                const openDetail = (window as any).__openDetail;
                if (openDetail) openDetail(book);
              }}
            />
          </main>

          {/* Footer */}
          <Footer
            settings={settings}
            categories={categories}
            onSelectCategory={setSelectedCategoryId}
            onNavigateToAdmin={handleNavigateToAdmin}
          />

          {/* Floating WhatsApp Quick Contact Button */}
          <FloatingWhatsApp
            whatsappNumber={settings?.whatsappNumber}
            storeName={settings?.storeName}
          />
        </div>
      ) : !isAdminAuthenticated ? (
        /* ========================================================= */
        /* 2. ADMIN LOGIN PAGE                                      */
        /* ========================================================= */
        <AdminLoginModal
          isStandalonePage={true}
          onSuccess={() => {
            setViewMode('admin');
            fetchAdminData();
          }}
          onEnterAsGuest={handleExitToStore}
        />
      ) : (
        /* ========================================================= */
        /* 3. ADMIN DASHBOARD AREA (Dilindungi Autentikasi Admin)    */
        /* ========================================================= */
        <AdminLayout
          currentTab={adminTab}
          onSelectTab={setAdminTab}
          onExitToStore={handleExitToStore}
          newOrdersBadge={newOrdersCount}
          lowStockBadge={lowStockCount}
        >
          {adminTab === 'dashboard' && (
            <AdminDashboardView
              analytics={analytics}
              onSelectTab={setAdminTab}
              onOpenInvoice={(order) => setActiveInvoiceOrder(order)}
              onQuickRestock={handleQuickRestock}
              onUpdateOrderStatus={handleUpdateOrderStatus}
            />
          )}

          {adminTab === 'books' && (
            <AdminBooksView
              books={books}
              categories={categories}
              onRefresh={fetchAdminData}
              onQuickRestock={handleQuickRestock}
            />
          )}

          {adminTab === 'categories' && (
            <AdminCategoriesView
              categories={categories}
              onRefresh={fetchAdminData}
            />
          )}

          {adminTab === 'stock' && (
            <AdminStockView
              books={books}
              stockMovements={stockMovements}
              onRefresh={fetchAdminData}
              selectedBookForRestock={quickRestockBook}
              onClearSelectedBook={() => setQuickRestockBook(null)}
            />
          )}

          {adminTab === 'orders' && (
            <AdminOrdersView
              orders={orders}
              settings={settings}
              onRefresh={fetchAdminData}
              onOpenInvoice={(order) => setActiveInvoiceOrder(order)}
            />
          )}

          {adminTab === 'customers' && (
            <AdminCustomersView customers={customers} />
          )}

          {adminTab === 'sales' && (
            <AdminSalesView orders={orders} />
          )}

          {adminTab === 'reports' && (
            <AdminReportsView
              books={books}
              orders={orders}
              customers={customers}
            />
          )}

          {adminTab === 'settings' && (
            <AdminSettingsView
              settings={settings}
              onRefresh={fetchAdminData}
            />
          )}

          {adminTab === 'backup' && (
            <AdminBackupView onRefreshAll={fetchAdminData} />
          )}
        </AdminLayout>
      )}

      {/* ========================================================= */}
      {/* GLOBAL MODALS                                             */}
      {/* ========================================================= */}

      {/* Book Detail Modal */}
      <BookDetailConsumer settings={settings} />

      {/* Cart Drawer */}
      <CartDrawer />

      {/* Checkout Modal */}
      <CheckoutModal
        settings={settings}
        onOrderSuccess={() => {
          fetchPublicData();
        }}
      />

      {/* Order Tracking Modal */}
      <OrderTrackingModal settings={settings} />

      {/* Invoice Modal for Admin */}
      <InvoiceModal
        order={activeInvoiceOrder}
        settings={settings}
        onClose={() => setActiveInvoiceOrder(null)}
      />

      {/* Fallback Admin Login Modal (if opened via Navbar while on public view) */}
      {viewMode === 'public' && isLoginModalOpen && (
        <AdminLoginModal
          onSuccess={() => {
            setViewMode('admin');
            window.location.hash = 'admin';
            fetchAdminData();
          }}
          onEnterAsGuest={handleExitToStore}
        />
      )}
    </div>
  );
}

// Consumer for BookDetailModal using CartContext
function BookDetailConsumer({ settings }: { settings: Partial<AppSettings> | null }) {
  const { selectedBookForDetail, closeBookDetail, openBookDetail } = useCart();

  useEffect(() => {
    (window as any).__openDetail = openBookDetail;
    return () => {
      delete (window as any).__openDetail;
    };
  }, [openBookDetail]);

  return (
    <BookDetailModal
      book={selectedBookForDetail}
      settings={settings}
      onClose={closeBookDetail}
    />
  );
}

export default function App() {
  return (
    <AuthProvider>
      <CartProvider>
        <MainApplication />
      </CartProvider>
    </AuthProvider>
  );
}
