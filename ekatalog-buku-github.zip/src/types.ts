export interface Book {
  id: string;
  catalogNumber: string; // Nomor urut unik stabil, misal: "001", "002"
  isbn?: string;
  title: string;
  author: string;
  publisher: string;
  year: number;
  categoryId: string;
  categoryName: string;
  description: string;
  costPrice?: number; // Harga modal
  sellPrice: number;  // Harga jual
  stock: number;      // Jumlah stok
  minStockAlert?: number; // Peringatan stok menipis (default 5)
  coverUrl: string;   // Foto sampul
  isActive: boolean;  // Status aktif atau arsip
  rating?: number;    // Rating bintang (misal 4.8)
  reviewCount?: number; // Jumlah ulasan pembaca
  ageGroup?: string;  // Kelompok usia PAUD (misal "Usia 3-6 Tahun")
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description?: string;
  bookCount?: number;
}

export interface CartItem {
  book: Book;
  quantity: number;
}

export type OrderStatus =
  | 'Menunggu Konfirmasi'
  | 'Menunggu Pembayaran'
  | 'Diproses'
  | 'Dikirim'
  | 'Selesai'
  | 'Dibatalkan';

export type PaymentMethod = 'transfer_bank' | 'cod' | 'manual_confirm';

export interface OrderItem {
  bookId: string;
  catalogNumber?: string;
  title: string;
  author: string;
  price: number;
  costPrice?: number;
  quantity: number;
  subtotal: number;
  coverUrl: string;
}

export interface Order {
  id: string;
  orderCode: string; // e.g. INV-20261020-001
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  customerCity: string;
  paymentMethod: PaymentMethod;
  bankName?: string;
  status: OrderStatus;
  trackingNumber?: string; // Nomor resi kurir
  notes?: string;
  subtotal: number;
  shippingCost: number;
  totalAmount: number;
  items: OrderItem[];
  createdAt: string;
  updatedAt: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address: string;
  city: string;
  totalOrders: number;
  totalSpent: number;
  lastOrderAt: string;
  createdAt: string;
}

export type StockMovementType = 'in' | 'out' | 'adjustment' | 'cancel_return';

export interface StockMovement {
  id: string;
  bookId: string;
  bookTitle: string;
  type: StockMovementType;
  quantity: number; // Positif untuk penambahan, negatif untuk pengurangan
  previousStock: number;
  currentStock: number;
  reason: string;
  createdAt: string;
}

export interface BankAccount {
  bank: string;
  number: string;
  holder: string;
}

export interface AppSettings {
  storeName: string;
  storeTagline: string;
  logoUrl?: string;
  bannerUrl?: string;
  ownerName?: string;
  whatsappNumber: string;
  storeAddress: string;
  storeEmail: string;
  operatingHours?: string;
  bankAccounts: BankAccount[];
  enableCod: boolean;
  lowStockThreshold: number;
  shippingFlatRate: number;
  adminUsername: string; // Default 'admin'
  adminPin: string; // Default admin password 'admin123'
  updatedAt: string;
}

export interface SalesAnalytics {
  totalTitles: number;
  totalStockUnits: number;
  newOrdersCount: number;
  totalRevenue: number;
  totalProfit: number;
  topSellingBooks: {
    bookId: string;
    catalogNumber?: string;
    title: string;
    author: string;
    coverUrl: string;
    soldUnits: number;
    totalRevenue: number;
  }[];
  lowStockBooks: Book[];
  recentOrders: Order[];
  revenueChart: {
    period: 'daily' | 'weekly' | 'monthly';
    labels: string[];
    values: number[];
  };
}
