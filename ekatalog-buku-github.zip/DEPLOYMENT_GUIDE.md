# PANDUAN PENYELESAIAN ERROR 403 & PUBLIKASI ONLINE E-KATALOG

Dokumen ini memuat analisis teknis mendalam mengenai penyebab **Error 403 Google ("We're sorry, but you do not have access to this page")**, perbaikan arsitektur keamanan yang telah diimplementasikan di kode, serta langkah publikasi ke hosting publik agar katalog dapat dibuka oleh siapa saja tanpa akun Google.

---

## 1. Mengapa Muncul Error 403 Google Saat Membagikan Link?

Pesan error berikut:
```text
403. That's an error.
We're sorry, but you do not have access to this page.
```
Bukan berasal dari kode aplikasi E-Katalog Anda, melainkan **halaman pemblokiran resmi dari Google Cloud Identity-Aware Proxy (IAP) / Google Accounts**. Hal ini terjadi karena:

1. **Link yang dibagikan adalah URL Sandbox Internal AI Studio**:
   - URL berformat `https://ais-dev-...run.app` atau `https://ais-pre-...run.app` adalah kontainer Cloud Run internal untuk sesi pengembangan (preview editor).
   - Layanan ini diproteksi secara otomatis oleh sistem keamanan Google Cloud IAM. Hanya akun Google pemilik proyek (`adipranatha021@gmail.com`) yang memiliki izin akses (authorized).
   - Pengunjung publik, pelanggan di WhatsApp, atau siapa pun yang membuka link tersebut di mode incognito / browser HP akan dihadang oleh sistem autentikasi Google Cloud dan menerima **Error 403**.
2. **URL Workspace AI Studio**:
   - Membagikan link dari address bar `https://aistudio.google.com/app/build/...` akan meminta pengunjung untuk login ke akun Google developer dan meminta akses workspace proyek.

**Kesimpulan**: Link preview AI Studio tidak dirancang sebagai URL website produksi untuk konsumen akhir. Untuk melayani pelanggan umum, aplikasi harus dijalankan pada hosting publik atau domain tersendiri.

---

## 2. Perbaikan yang Telah Dilakukan pada Kode Aplikasi

Kami telah mengaudit dan memperkuat seluruh arsitektur aplikasi agar:
1. **Pemisahan Jalur Publik & Jalur Admin**:
   - Halaman publik (`/`) kini **hanya memanggil endpoint publik** (`/api/config`, `/api/books`, `/api/categories`).
   - Halaman publik **tidak pernah** memanggil endpoint sensitif admin (`/api/orders`, `/api/customers`, `/api/analytics`, `/api/settings` mentah), sehingga loading lebih cepat, aman, dan tidak pernah memicu error 401/403 pada pengunjung umum.
2. **Perlindungan Data Admin (Role-Based Authorization)**:
   - Endpoint admin di `server.ts` telah diproteksi dengan verifikasi token admin (`requireAdminAuth`).
   - Token dibuat secara aman saat admin login via `/api/admin/login` menggunakan username & PIN admin (`admin / admin123`).
   - Password/PIN admin **tidak pernah bocor** ke pengunjung publik (endpoint `/api/config` membuang field `adminPin`).
3. **CORS & Preflight Handling**:
   - Menambahkan header CORS (`Access-Control-Allow-Origin: *`) dan respons preflight HTTP `OPTIONS` di `server.ts` agar API tidak diblokir browser saat diakses dari domain atau perangkat berbeda.
4. **Fallback Aman Rute Single Page App (SPA)**:
   - Penanganan rute wildcard Express `*` untuk melayani `dist/index.html` pada mode produksi, serta respon 404 JSON khusus untuk rute `/api/*` yang tidak dikenal.
5. **Verifikasi Build**:
   - `npm run build` dan `tsc --noEmit` berhasil 100% tanpa error kompilasi.

---

## 3. Langkah Mendapatkan URL Publik HTTPS Tanpa Login Google

Untuk membuat toko online Anda memiliki link publik resmi (contoh: `https://katalog-buku-paud.onrender.com` atau `https://tokobukuanda.com`):

### Cara 1: Deployment Gratis di Render.com (Direkomendasikan - Full-Stack Express)
1. Buka [https://render.com](https://render.com) dan daftar akun gratis (bisa menggunakan akun GitHub atau Email).
2. Simpan/Push kode proyek ini ke repository GitHub Anda (misal: `ekatalog-buku`).
3. Di dashboard Render, klik tombol **New +** lalu pilih **Web Service**.
4. Sambungkan ke repository GitHub Anda.
5. Isi konfigurasi berikut:
   - **Name**: `katalog-buku-paud` (atau nama toko Anda)
   - **Region**: Singapore (terdekat dengan Indonesia untuk performa maksimal)
   - **Branch**: `main`
   - **Environment**: `Node`
   - **Build Command**: `npm install && npm run build`
   - **Start Command**: `node server.ts` (atau `npm run start`)
   - **Instance Type**: `Free`
6. Klik **Create Web Service**.
7. Render akan mem-build aplikasi dan memberikan URL HTTPS publik resmi seperti:
   `https://katalog-buku-paud.onrender.com`
8. **Uji URL tersebut**: Siapa pun di seluruh dunia sekarang dapat langsung membuka katalog tanpa login akun Google sama sekali!

### Cara 2: Deployment Cepat di Railway.app
1. Buka [https://railway.app](https://railway.app).
2. Klik **New Project** > **Deploy from GitHub repo**.
3. Pilih repository Anda.
4. Masuk ke menu **Settings** > **Networking** > klik **Generate Domain**.
5. Anda akan mendapatkan URL HTTPS gratis (misal: `https://ekatalog-production.up.railway.app`).

### Cara 3: Menggunakan Domain Kustom Sendiri (Opsional)
Jika Anda memiliki domain seperti `katalogbuku.id` atau `tokopaud.com`:
- Masuk ke dashboard Render atau Railway Anda > menu **Custom Domains**.
- Tambahkan CNAME record di panel DNS domain Anda.

---

## 4. Akses Admin & Kredensial

- **Link Publik Toko**: Buka URL utama (misal: `https://katalog-buku-paud.onrender.com`).
- **Masuk ke Halaman Admin**:
  1. Klik tombol **"Masuk Admin"** di bagian atas kanan navbar atau footer.
  2. Atau akses URL dengan hash `#admin` (misal: `https://katalog-buku-paud.onrender.com/#admin`).
- **Kredensial Default**:
  - **Username**: `admin`
  - **Password / PIN**: `admin123`
- Anda dapat mengubah nama toko, nomor WhatsApp penjual, daftar nomor rekening bank, dan password/PIN kapan saja melalui menu **Pengaturan** di Dashboard Admin.
- Data tersimpan secara persisten di file `data/db.json` dan Anda dapat mengunduh backup lengkap kapan saja melalui menu **Backup & Pemulihan Data**.
