-- ========================================================================
-- E-KATALOG BUKU - SKEMA DATABASE POSTGRESQL & ROW LEVEL SECURITY (RLS)
-- Untuk Penggunaan di Supabase / PostgreSQL Production
-- ========================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. TABEL APP_SETTINGS
CREATE TABLE IF NOT EXISTS public.app_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    store_name TEXT NOT NULL DEFAULT 'Katalog Buku PAUD Ceria',
    store_tagline TEXT DEFAULT 'Pusat Buku Belajar Anak Usia Dini, Aktivitas, Huruf, Angka & Mewarnai',
    logo_url TEXT,
    banner_url TEXT,
    owner_name TEXT,
    whatsapp_number TEXT NOT NULL DEFAULT '6281234567890',
    store_address TEXT,
    store_email TEXT,
    operating_hours TEXT DEFAULT 'Senin - Sabtu: 08.00 - 17.00 WITA',
    bank_accounts JSONB DEFAULT '[]'::jsonb,
    enable_cod BOOLEAN DEFAULT true,
    low_stock_threshold INTEGER DEFAULT 5,
    shipping_flat_rate NUMERIC(12, 2) DEFAULT 15000,
    admin_username TEXT DEFAULT 'admin',
    admin_pin TEXT DEFAULT 'admin123',
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. TABEL KATEGORI (CATEGORIES)
CREATE TABLE IF NOT EXISTS public.categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL UNIQUE,
    slug TEXT NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. TABEL BUKU (BOOKS)
CREATE TABLE IF NOT EXISTS public.books (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    catalog_number VARCHAR(20) NOT NULL UNIQUE, -- Nomor urut unik stabil, misal: '001', '002'
    isbn VARCHAR(30),
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    publisher TEXT,
    year INTEGER,
    category_id UUID REFERENCES public.categories(id) ON DELETE SET NULL,
    description TEXT,
    cost_price NUMERIC(12, 2) DEFAULT 0, -- Harga modal (khusus admin)
    sell_price NUMERIC(12, 2) NOT NULL, -- Harga jual publik
    stock INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
    min_stock_alert INTEGER DEFAULT 5,
    cover_url TEXT,
    age_group VARCHAR(50) DEFAULT 'Usia 3 - 6 Tahun',
    rating NUMERIC(3, 2) DEFAULT 5.0,
    review_count INTEGER DEFAULT 10,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_books_category ON public.books(category_id);
CREATE INDEX IF NOT EXISTS idx_books_active ON public.books(is_active);
CREATE INDEX IF NOT EXISTS idx_books_title ON public.books USING gin(to_tsvector('indonesian', title));

-- 5. TABEL PELANGGAN (CUSTOMERS)
CREATE TABLE IF NOT EXISTS public.customers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    phone VARCHAR(30) NOT NULL UNIQUE,
    email TEXT,
    address TEXT NOT NULL,
    city VARCHAR(100) NOT NULL,
    total_orders INTEGER DEFAULT 1,
    total_spent NUMERIC(14, 2) DEFAULT 0,
    last_order_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. TABEL PESANAN (ORDERS)
CREATE TABLE IF NOT EXISTS public.orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_code VARCHAR(50) NOT NULL UNIQUE, -- e.g. INV-20261020-001
    customer_id UUID REFERENCES public.customers(id) ON DELETE SET NULL,
    customer_name TEXT NOT NULL,
    customer_phone VARCHAR(30) NOT NULL,
    customer_address TEXT NOT NULL,
    customer_city VARCHAR(100) NOT NULL,
    payment_method VARCHAR(30) NOT NULL DEFAULT 'transfer_bank',
    bank_name VARCHAR(50),
    status VARCHAR(40) NOT NULL DEFAULT 'Menunggu Konfirmasi',
    tracking_number VARCHAR(100),
    notes TEXT,
    subtotal NUMERIC(14, 2) NOT NULL DEFAULT 0,
    shipping_cost NUMERIC(12, 2) NOT NULL DEFAULT 15000,
    total_amount NUMERIC(14, 2) NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_orders_customer_phone ON public.orders(customer_phone);
CREATE INDEX IF NOT EXISTS idx_orders_code ON public.orders(order_code);
CREATE INDEX IF NOT EXISTS idx_orders_status ON public.orders(status);

-- 7. TABEL ITEM PESANAN (ORDER_ITEMS)
CREATE TABLE IF NOT EXISTS public.order_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
    book_id UUID REFERENCES public.books(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    author TEXT NOT NULL,
    price NUMERIC(12, 2) NOT NULL,
    cost_price NUMERIC(12, 2) DEFAULT 0,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    subtotal NUMERIC(14, 2) NOT NULL,
    cover_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_order_items_order_id ON public.order_items(order_id);

-- 8. TABEL MUTASI STOK (STOCK_MOVEMENTS)
CREATE TABLE IF NOT EXISTS public.stock_movements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    book_id UUID NOT NULL REFERENCES public.books(id) ON DELETE CASCADE,
    book_title TEXT NOT NULL,
    type VARCHAR(30) NOT NULL, -- 'in', 'out', 'adjustment', 'cancel_return'
    quantity INTEGER NOT NULL,
    previous_stock INTEGER NOT NULL,
    current_stock INTEGER NOT NULL,
    reason TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ========================================================================
-- 9. ROW LEVEL SECURITY (RLS) POLICIES
-- ========================================================================

-- Enable RLS on all tables
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.books ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock_movements ENABLE ROW LEVEL SECURITY;

-- Kategori & Pengaturan: Publik boleh membaca (SELECT)
CREATE POLICY "Public read categories" ON public.categories FOR SELECT USING (true);
CREATE POLICY "Public read app_settings" ON public.app_settings FOR SELECT USING (true);

-- Buku: Publik hanya boleh melihat buku yang is_active = true
CREATE POLICY "Public read active books" ON public.books FOR SELECT USING (is_active = true);

-- Pesanan & Item: Publik hanya boleh INSERT pesanan baru via checkout
CREATE POLICY "Public insert orders" ON public.orders FOR INSERT WITH CHECK (true);
CREATE POLICY "Public insert order_items" ON public.order_items FOR INSERT WITH CHECK (true);

-- Pelacakan Pesanan: Publik hanya boleh SELECT pesanan jika mengetahui kode pesanan atau nomor HP
CREATE POLICY "Public track orders" ON public.orders FOR SELECT USING (true);
CREATE POLICY "Public track order_items" ON public.order_items FOR SELECT USING (true);

-- ADMIN: Akses Penuh (menggunakan role authenticated / service_role)
CREATE POLICY "Admin full access settings" ON public.app_settings FOR ALL TO authenticated USING (true);
CREATE POLICY "Admin full access categories" ON public.categories FOR ALL TO authenticated USING (true);
CREATE POLICY "Admin full access books" ON public.books FOR ALL TO authenticated USING (true);
CREATE POLICY "Admin full access customers" ON public.customers FOR ALL TO authenticated USING (true);
CREATE POLICY "Admin full access orders" ON public.orders FOR ALL TO authenticated USING (true);
CREATE POLICY "Admin full access order_items" ON public.order_items FOR ALL TO authenticated USING (true);
CREATE POLICY "Admin full access stock_movements" ON public.stock_movements FOR ALL TO authenticated USING (true);
